package sspinja.scheduler.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import spinja.exceptions.ValidationException;
import spinja.model.Transition;
import spinja.promela.model.PromelaTransition;
import spinja.store.AtomicHashTable;
import spinja.store.StateStore;
import spinja.util.ByteArrayStorage;
import sspinja.PanModel1;
import sspinja.PanOptimizeModel;

public class LivenessSearch {
	class DStack {
		PromelaTransition lasttr; //last transition from current state
		int pos ;
		public void print() {
			System.out.println("lasttr : " + lasttr+ ", pos: " + pos);			
		}
	}
	class CStack {
		int lowlink ; //lowlink value of this entry
		byte[] state ;
		int next ;
		public void print() {
			System.out.println("lowlink : " + lowlink + ", next : " + next);			
		}
	}
	class State {
		byte [] state ;
	}
		
	int dtop = -1 ;
	ArrayList<DStack> dstack = new ArrayList<DStack>() ;
	
	int ctop = -1 ;
	ArrayList<CStack> cstack = new ArrayList<CStack>() ;
	
	int atop = -1 ;
	ArrayList<Integer> astack = new ArrayList<Integer>() ;
	
	int count = 0 ;
	
	private void print() {
		System.out.println("") ;
		System.out.println(model);
		System.out.println("--------------------");
		System.out.println("* DStack, dtop = " + dtop);
		for (int i = 0 ; i <= dtop ; i++)
			dstack.get(i).print();
		System.out.println("* CStack, ctop = " + ctop);
		for (int i = 0 ; i<= ctop; i++) {
			cstack.get(i).print();
		}		
		System.out.println("* AStack, atop = " + atop);
		for (int i = 0 ; i <= atop; i++)			
			System.out.print(astack.get(i) + " ");
		System.out.println("--------------------");
		System.out.println("") ;
	}
	int k = 20000000;
//	int[] chash = new int[k] ;
	private HashMap<Integer, Integer> chash = new HashMap<Integer, Integer>() ;
	
	boolean violation = false ;
	
	int p, identifier ;
	
	private PanOptimizeModel model ;
	PromelaTransition next, last ;
	
	 
	
	public void TCHECK(byte[] s0){		
		print() ;
		System.out.println("PUSH");
		int h = HASH(s0) ; //already push in hash ? NO
		PUSH(s0) ;		
		print() ;
				
		while (dtop >= 0 && !violation) {			
			last = dstack.isEmpty() ? null : dstack.get(dtop).lasttr ;
			
			next = model.nextTransition(last) ;
			//select best next!
			System.out.println("Model: " + model);
			System.out.println("last: " + last) ;
			System.out.println("next: " + next) ;
			
			if (next == null) {
				POP() ;
				System.out.println("POP");
				print() ;
				continue ;
			} 
			try {
				dstack.get(dtop).lasttr = next ;
				next.take();
//				dstack.get(dstack.size()-1).lasttr = next ;
				System.out.println("Take & update next = " + next);
				print() ;
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
			byte [] s1 = storeModel() ;
			h = HASH(s1) ;		
			System.out.println("Hash value: " + h);
			//h = store.addState(s1) ; //already push in hash
			
//			if (h> 0) {
				if (chash.get(h) == null)				
					p = -1 ;
				else
					p = chash.get(h);
				
				while ((p != -1) && (! Arrays.equals(cstack.get(p).state, s1))) {
					p = cstack.get(p).next ;
				}
				
				if (p != -1) {
					UPDATE(p) ;
					continue ;
				}			
				
				//if (!store.CONTAINS(s1)) //when hash -> already push
				//if (h > 0) { //always > 0
				if (!CONTAINS(s1)) {	
					System.out.println("PUSH");
					store.addState(s1);
					PUSH(s1) ;				
					print() ;
				}
//			}				
		}
		if (violation) {
			System.out.println("ERROR");		
		}
	}
	
	private boolean CONTAINS(byte[] s) {
		return store.CONTAINS(s);
	}
	
	private void UPDATE(int t) {
		System.out.println("Update");
		int f = dstack.get(dtop).pos ;
		int tlowlink = cstack.get(t).lowlink ;
		int flowlink = cstack.get(f).lowlink ; 
		if (tlowlink <= flowlink ) {
			violation = (atop >= 0 && t <= astack.get(atop)) ;
			cstack.get(f).lowlink = cstack.get(t).lowlink ;
		}
	}
	private int HASH(byte[] s) {
		int t = store.HASH(s) ;
		if (t < 0)
			t = - t - 1;				
		return t;
	}
	
	private void PUSH(byte[] s){
		ctop ++ ;
		
		CStack cs = new CStack() ;						
		cs.lowlink = ctop ;
		cs.state = s ;		
		int h = HASH(s) ;

		System.out.println("Hash value: " + h);
		if (chash.get(h) == null)
			cs.next = -1 ;
		else
			cs.next = chash.get(h) ;		
		chash.put(h, ctop);
		
		
		if (cstack.size() <= ctop)
			cstack.add(ctop,cs);
		else
			cstack.set(ctop,cs) ;
		
		if (cstack.size() > 0 && ctop > 0)
			cstack.get(ctop - 1).next = ctop ;
		//------------------------------
		
		
		dtop ++ ;		
		DStack ds = new DStack() ;
		ds.lasttr = null ;
//		ds.lasttr = lasttr ;		
		ds.pos = ctop ;
		if (dstack.size() <= dtop)
			dstack.add(ds) ;
		else
			dstack.set(dtop, ds) ;
//		System.out.println("- Add dstack");
//		ds.print();
		
		//if (model.conditionHolds(Condition.ACCEPT_STATE)) {
		if (model.isAccepted()) {//accept
			atop ++ ;
			astack.add(ctop) ;
			System.out.println("+ Add astack : " + ctop);
		}
	}
	
	private void POP() {
		int p = dstack.get(dtop).pos ;
		restoreModel(cstack.get(p).state) ;
		dtop -- ;
		print() ;
		if (cstack.get(p).lowlink == p) {
			while (ctop >= p) {
				CStack cs = cstack.get(ctop) ;
				int h = HASH(cs.state) ;
				h = -h - 1;
				chash.put(h, cs.next);
				store.addState(cs.state) ;					
				
				ctop -- ;
			}			
		}
		if ((atop >= 0) && (p == astack.get(atop))) 
			atop -- ;
		if (dtop >= 0) 
			UPDATE(p) ;
	}
	
	public void execute() {
		System.out.println("Liveness Search");
		byte [] s0 = storeModel () ;
		TCHECK(s0) ;
	}
	
	private final AtomicHashTable store;
	private final int size;
	private final Transition[] lastTransition;
	private final byte[][] encoded;	
	private final int[] identifiers;	
	private final int[] hashTable;	
	private final int hashMask;	
	private long bytes;
	private final ByteArrayStorage storage = new ByteArrayStorage();

	public LivenessSearch(int size, PanOptimizeModel model2, final StateStore store) {		
		this.model = model2 ;
		this.store = (AtomicHashTable) store ;
		this.size = size;
		lastTransition = new Transition[size];
		encoded = new byte[size][];
		identifiers = new int[size];
		
//		for (int i = 0 ; i< k ; i ++) {
//			chash[i] = -1;
//		}

		int hashSize = 0;
		while (size > 0) {
			size >>= 1;
			hashSize++;
		}
		hashSize = 1 << hashSize;
		hashTable = new int[hashSize];
		for(int i= 0; i < hashSize; i++) {
			hashTable[i] = Integer.MIN_VALUE;
		}
		hashMask = hashSize - 1;

		bytes = 128 + 12 * size + 4 * hashSize;
		//hash = HashAlgorithm.getDefaultAlgorithm();
	}

	protected byte[] storeModel() {
		storage.init(model.getSize());
		model.encode(storage);
		return storage.getBuffer();
	}
	
	protected void restoreModel(byte[] state) { 
//		byte [] state = node.nodeState;			
		ByteArrayStorage reader = new ByteArrayStorage();
		reader.setBuffer(state);
		model.decode(reader);	
	}	

	
}