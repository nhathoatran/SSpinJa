// Copyright 2010, University of Twente, Formal Methods and Tools group
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package sspinja.scheduler.search;

import static spinja.search.Message.DEADLOCK;
import static spinja.search.Message.DUPLICATE_STATE;
import static spinja.search.Message.EXCEED_DEPTH_ERROR;
import static spinja.search.Message.EXCEED_DEPTH_WARNING;
import static spinja.search.Message.LIVELOCK;
import static spinja.search.Message.TRANS_ERROR;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import spinja.exceptions.SpinJaException;
import spinja.exceptions.ValidationException;
import spinja.model.Condition;
import spinja.model.Model;
import spinja.model.SchedulerTransition;
import spinja.model.Transition;
import spinja.promela.model.PromelaTransition;
import spinja.promela.model.PromelaTransitionFactory.NonAtomicTransition;
import spinja.search.TransitionCalculator;
import spinja.store.StateStore;
import spinja.util.Log;
import spinja.util.Util;
import sspinja.CTLFormula;
import sspinja.Config;
import sspinja.Generate;
import sspinja.GenerateCode;
import sspinja.SchedulerObject;
import sspinja.SchedulerPanModel;
import sspinja.SchedulerState;
import sspinja.scheduler.promela.model.SchedulerPromelaModel;

public class SchedulerCTLGenSearch_2<M extends Model<T>, T extends Transition> extends SchedulerSearchAlgorithm<M, T> {	
	private static final long serialVersionUID = 1L;
	
	HashMap<Integer, SchedulerState> schedulerstatehashmap ;	
	
	private int state_count = 0 ;
	private SchedulerState startSchedulerState = null ;
	private SchedulerState currentSchedulerState = null ;
	private ArrayList<SchedulerState> verifyStatesList ;
	private CTLFormula formula;
	private ArrayList<Integer> cyclicSchedulerStateIDList;
	ArrayList<Transition> starttrace;	
	HashSet<SchedulerState> visitedStates ;
	ArrayList<Transition> trace ;
	
	public static GenerateCode generatecode ;
//	private ArrayList<GenerateCode> codelist = new ArrayList<GenerateCode> () ;
	private GenerateCode [] codeArr = new GenerateCode[10000] ;
	private int codelisttop = -1 ;
	HashMap<String, ArrayList<Transition>> testcase = new HashMap<String, ArrayList<Transition>>() ;
	ArrayList<String> testprogramlist = new ArrayList<String>() ;
	
	public SchedulerCTLGenSearch_2(M model, StateStore store, int stackSize, boolean errorExceedDepth,
			boolean checkForDeadlocks, int maxErrors, TransitionCalculator<M, T> nextTransition) {
		super(model, store, stackSize, errorExceedDepth, checkForDeadlocks, maxErrors, nextTransition);
		
		schedulerstatehashmap = new HashMap<Integer, SchedulerState>();
		cyclicSchedulerStateIDList = new ArrayList<Integer>() ;
		verifyStatesList = new ArrayList<SchedulerState>() ;
		formula = new CTLFormula() ;
		starttrace = new ArrayList<Transition> ();
		Log.initLog(SchedulerPanModel.scheduler.getSchedulerName());
	}

	@Override
	protected Transition nextTransition() {		
		return model.nextTransition(null) ;
	}

	@Override
	protected Transition nextTransition(Transition last) {	
		return model.nextTransition((T) last) ;
	}	
	
	@Override
	protected void takeTransition(final Transition next) throws SpinJaException {		
		stack.takeTransition(next);
	}
	
	/*
	private void add_exist_child(int identifier, Transition trans) {
		if (trans == null) return ;
		boolean isExist = false ;
		for (SchedulerState node : currentSchedulerState.next) {
			if (node.identifier == identifier) isExist = true ;
		}
		SchedulerState child = schedulerstatehashmap.get(identifier) ;
		if (! isExist) {
			currentSchedulerState.next.add(child) ;
			currentSchedulerState.trans.add(trans);
		}
	}
	*/
	
	private void add_exist_child(int identifier, Transition trans, GenerateCode generatecode) {
		if (trans == null) return ;
		boolean isExist = false ;
		for (SchedulerState node : currentSchedulerState.next) {
			if (node.identifier == identifier) isExist = true ;
		}
		SchedulerState child = schedulerstatehashmap.get(identifier) ;
		if (! isExist) {
			currentSchedulerState.next.add(child) ;
			currentSchedulerState.trans.add(trans);
			GenerateCode code = generatecode.clone() ;
			code.pcnt.addAll(SchedulerPromelaModel.scheduler.pcnt);
			currentSchedulerState.generatecodes.add(code);
//			System.out.println(generatecode.gencode.code);
//			System.out.println(code.pcnt);
//			System.out.println(generatecode.pcnt);
			return ;
		}
	}
	
	/*
	private void put_schedulerState(int identifier, int depth, int runInstance) {
		SchedulerState schState = new SchedulerState() ;
		if (SchedulerPanModel.panmodel.modelCheck()) {
			schState.results = SchedulerPanModel.panmodel.init_atomicf() ;
			schState.checked = SchedulerPanModel.panmodel.init_sf() ;
		} else {
			SchedulerPromelaModel.scheduler.initSchedulerState(schState, depth);
		}	
		schState.identifier = identifier ;		
		schState.runinstance = runInstance ;
		
		if (currentSchedulerState != null) {
			currentSchedulerState.next.add(schState) ;
			currentSchedulerState.trans.add(stack.getLastTransition()) ;
		}
		schedulerstatehashmap.put(identifier, schState); 
		state_count ++ ;
		if (SchedulerPanModel.panmodel.stateCheck() || SchedulerPanModel.scheduler.stateCheck()) {
			verifyStatesList.add(schState);
		}		
	}
	*/
	
	private void put_schedulerState(int identifier, int depth, int runInstance, GenerateCode generatecode) {
		SchedulerState schState = new SchedulerState() ;
		if (SchedulerPanModel.panmodel.modelCheck()) {
			schState.results = SchedulerPanModel.panmodel.init_atomicf() ;
			schState.checked = SchedulerPanModel.panmodel.init_sf() ;
		} else {
			SchedulerPromelaModel.scheduler.initSchedulerState(schState, depth);
		}	
		schState.identifier = identifier ;		
		schState.runinstance = runInstance ;
		
		if (currentSchedulerState != null) {
			currentSchedulerState.next.add(schState) ;
			currentSchedulerState.trans.add(stack.getLastTransition()) ;
			GenerateCode code = generatecode.clone() ;
			code.pcnt.addAll(SchedulerPromelaModel.scheduler.pcnt);
			currentSchedulerState.generatecodes.add(code);
//			System.out.println(generatecode.gencode.code);
//			System.out.println(generatecode.pcnt);
//			System.out.println(code.pcnt);
		}
		schedulerstatehashmap.put(identifier, schState); 
		state_count ++ ;
		if (SchedulerPanModel.panmodel.stateCheck() || SchedulerPanModel.scheduler.stateCheck()) {
			verifyStatesList.add(schState);
		}		
	}
	
	public void execute() {		
		InitGraph() ; //+ generate test case following the search and error
//		PrintGraph() ;
			
		if (SchedulerPanModel.panmodel.modelCheck() || SchedulerPromelaModel.scheduler.schedulerCheck()) {
			if (verifyStatesList.size() == 0) {
				System.out.println("No state to be verified");
			} else {
//			PrintGraph() ;
//			if (verifyStatesList.size() == 0 &&
//				(SchedulerPanModel.panmodel.stateCheck() || SchedulerPanModel.scheduler.stateCheck()))
//				verifyStatesList.add(startSchedulerState);
				if (!Config.processLimit) {
					LabelGraph() ;
//					PrintGraph() ;
					visitedStates = new HashSet<SchedulerState>() ;
					trace = new ArrayList<Transition>() ;
					ArrayList<GenerateCode> gencodelist = new ArrayList<GenerateCode>() ;
					for (SchedulerState schedulerstate : verifyStatesList) {
						PrintTrace(true,trace, gencodelist, schedulerstate, 0, formula.length - 1, formula.sn[0]);
					}
					
					SchedulerPromelaModel.scheduler.printAnalysisResult(Log.out);
				} else {
					Log.out.println(formula.toString() + " : Not determined") ;
					Log.out.println("Search incomplete") ;
					System.out.println("Search incomplete") ;
					System.out.println(formula.toString() + " : Not determined") ;
					Log.analysisresult = true ;
				}
			}
		} else {
			Util.print("Not found CTL formula");
		}
//		flushOutputTest(model.getName());
//		flushOutputTest(SchedulerPanModel.scheduler.getSchedulerName());
		
		final File userDir = new File(System.getProperty("user.dir"));
		try{
			new File(userDir + "/" + Generate.getGenerateDirectory()).mkdir();
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
		//exportTestData();
		writeTestCase();
		freeMemory();
	}	
	
	private void addGenCode() {		
		int oldcodelisttop = codelisttop ;
		codelisttop = stack.top();
				
		if (codeArr[codelisttop] == null)  {	//new gen code		
			generatecode = new GenerateCode() ;			
			codeArr[codelisttop] = generatecode ;
		} else {		
			generatecode = codeArr[codelisttop] ;
			generatecode.clearCode();
		}
		//System.out.println("Step = " + codelisttop + " code: " + generatecode.gencode.code);		
		 
				
		if (oldcodelisttop < codelisttop && oldcodelisttop >= 0) {
			generatecode.pcnt = (ArrayList<Byte>) codeArr[oldcodelisttop].getPcnt().clone() ; //copy pcnt
			SchedulerObject.setPcnt(generatecode.pcnt) ;
		} else {
			generatecode.pcnt.clear();
			generatecode.pcnt.addAll(SchedulerObject.getPcnt()) ;
		}
	}
	
	
	private void setProcessID(int pid) {
		generatecode.pid = pid ;
//		generatecode.pcnt = (ArrayList<Byte>) pcnt.clone() ;
	}
	private void recordNewProcessID() {
		//schedulerObject.newid = -1;
	}
	private void updateGenCode(String code, String part) { //update generated code
		if (code == null) return ;
		generatecode.gencode.setcode(part, code);			
		generatecode.pcnt.clear();
		generatecode.pcnt.addAll(SchedulerObject.getPcnt()) ;
		Generate.out.clear();
	}
	
	
	
		
	private void InitGraph() {
		Util.print("Begin execute");
		Util.print(SchedulerPromelaModel.scheduler.getSchedulerName());
		Config.processInit = false ;		
				
		try {
			SchedulerPromelaModel.scheduler.init_order();
		} catch (final SpinJaException ex) {
			report(TRANS_ERROR, ex.getMessage());
		}
		
		//SchedulerPromelaModel.scheduler.print_all();
		
		if (SchedulerPromelaModel.scheduler.running_process == null) {		
			try {
				SchedulerPromelaModel.scheduler.init() ;
				running_processID = SchedulerPromelaModel.scheduler.select_process(-1) ;				
			} catch (final SpinJaException ex) {
				report(TRANS_ERROR, ex.getMessage());
			}
//			if (running_processID < 0) {
//				Util.print("Can not select process to run");
//			}
		}
						
		byte[] state  = storeModel();				
		int identifier ;
		

		if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
			identifier = store.addState(state);
		} else {
			identifier = hash.hash(state, 0);			
			atomicSteps++;
		}
		
		if (!addState(state, identifier)) {
			throw new RuntimeException("Could not even add the first state.");
		}
		addGenCode();
		updateGenCode(Generate.out.toString(), "select_process");
		
		//int runInstance = SchedulerPromelaModel.scheduler.getRunningInstance() ;
//		int runInstance = SchedulerPromelaModel.scheduler.getRunningID() ;
		int runid = SchedulerPromelaModel.scheduler.getRunningID() ;
//		put_schedulerState(identifier, 0, runid) ;
		put_schedulerState(identifier, 0, runid, generatecode) ;
		
		startSchedulerState = schedulerstatehashmap.get(identifier) ;
		if (! SchedulerPromelaModel.scheduler.collectState())
			verifyStatesList.add(startSchedulerState);
			
		
		addRunningSetState();		
		
		Transition last = null ;
		Transition next = null;
		Transition clockTrans = new SchedulerTransition(0) ;
		Transition swcoreTrans = new SchedulerTransition(1) ;
		
		int lastschopt = 0 ;
		int nextschopt = 0 ;
		int livelockCount = 0 ;
		
		boolean startCheckLiveLock = false ;
//		Generate.out.clear();
		
//		boolean print = false ;
		while ((nrErrors < maxErrors) && !Thread.currentThread().isInterrupted() && restoreState() && !Config.processLimit) {
			currentSchedulerState = stack.getTopIdentifer() < 0 ? null : schedulerstatehashmap.get(stack.getTopIdentifer()) ;

			boolean isTimer = SchedulerPromelaModel.scheduler.isTimer();
			if (outOfMemory) {				
				throw new OutOfMemoryError();
			}
		
			assert checkModelState();
		
			if (state.length > maxSize) {
				maxSize = state.length;
			}
					
			if (getDepth() - 1 > maxDepth) {
				maxDepth = getDepth() - 1;
			}
			
//			stack.clearGenCode();			
//			Generate.out.clear();
//			stack.pushGenCode("-> " + next);			
//			Util.print("**** Model: " + model);
//			SchedulerPromelaModel.scheduler.print_all();
			print_trace() ;
			
			
			last = stack.getLastTransition() ;
			lastschopt = stack.getLastSchOption();
//			addGenCode();
			
			
			/*
			 * for each process
			 * 		for each sch_opt
			 * 			for each trans
			 */
			if (last == null) {// && lastschopt == 0) {	//new state
				nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
				next = nextTransition(last) ;				
			} else {				
				nextschopt = SchedulerPromelaModel.scheduler.nextSchedulerOption(lastschopt);
				if (nextschopt == -1) { //no more scheduler option	
//					lastschopt = 0 ;
//					nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
					if (last == clockTrans || last == swcoreTrans)
						next = nextTransition(null) ;
					else {
						next = nextTransition(last) ;
						nextschopt = 0 ;
					}
				} else {
					next = last ;
				}
			}	
			
			System.out.println("==> Last: " + last);
			System.out.println("==> Next: " + next);
//			System.out.println(SchedulerPromelaModel.scheduler.pcnt);
//			System.out.println(generatecode.pcnt);
			
			if (next == null)
				SchedulerPromelaModel.scheduler.setAction("null") ;
			else 
				SchedulerPromelaModel.scheduler.setAction(next.toString()) ;
			
	
			
			
			if (next == null) {			
				if (isTimer && last == null) {	//check last = clock action
					try {	
						if (nextschopt == 0 && lastschopt == 0) //new state
							nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
						
						SchedulerPromelaModel.scheduler.clock();
						stack.pushSchTrans(clockTrans);
						//System.out.println("take clock action ---> Wrong!!!!");
						//Util.print("------------------------------------");
						//SchedulerPromelaModel.scheduler.print_all();
						//print_trace() ;
						
						updateGenCode(Generate.out.toString(), "clock");
						
						Generate.out.clear();						
						if (SchedulerPromelaModel.scheduler.running_process == null) {							
							SchedulerPromelaModel.scheduler.select_process(-1);
							updateGenCode(Generate.out.toString(), "select_process");	
//							Generate.out.clear();
						}
					} catch (ValidationException e) {
						Log.out.println(e.toString()) ;
						continue; //break ;
					}
					if (Config.isCheckLiveLock) if (!startCheckLiveLock) startCheckLiveLock = true ;
					if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {							
						state = storeModel() ;
						identifier = store.addState(state);		
						stack.pushSchOpt(nextschopt);
						
						Generate.setBehavior(generatecode);
						codeArr[stack.top()] = generatecode ;
						
						if (identifier < 0) { //visited state
							//generate the trail
							genTestCaseFollowingSearch();
							
//							currentSchedulerState.print();
//							add_exist_child(-(identifier + 1), next);
							add_exist_child(-(identifier + 1), next, generatecode);
							
							getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ; //if exist the identifier in stack
							if (cyclicSchedulerStateIDList.size() > 0)
								for (int id : cyclicSchedulerStateIDList)
									updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
							else 
								updateSchedulerState(-(identifier + 1),stack.top(),false, true);
							
							report(DUPLICATE_STATE.withState(state));
							nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
							statesMatched++;											
							if (startCheckLiveLock) { 
								if (SchedulerPromelaModel.scheduler.running_process != null) {
									report(LIVELOCK) ; //turn around
									livelockCount ++ ;
									if (!(nrErrors < maxErrors)) { //check all errors
										break ; //too many errors
									}							
								}
							} 
							//duplicate with no more scheduler option -> get other process?
							if (nextschopt == 0) {
								
//								if (getOtherProcessfromRunningSet()) { //get other process
//									if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
//										state = storeModel() ;
//										identifier = store.addState(state);		
//										stack.pushSchOpt(nextschopt);
//										
//										if (identifier < 0) {
//											if (stack.top() == 0) {
//												verifyStatesList.add(schedulerstatehashmap.get(-(identifier + 1)));
//											}
//											genTestCaseFollowingSearch(); 
//											
//											add_exist_child(-(identifier + 1), next);
//											getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ;
//											if (cyclicSchedulerStateIDList.size() > 0)
//												for (int id : cyclicSchedulerStateIDList)
//													updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
//											else 
//												updateSchedulerState(-(identifier + 1),stack.top() - 1,false, true);
//											
//											report(DUPLICATE_STATE.withState(state));
//											nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
//											statesMatched++;
//											if (nextschopt == 0)
//												stateDone() ;
//										} else {
//											replaceState(state, identifier) ;
//											//runInstance = SchedulerPromelaModel.scheduler.getRunningInstance();
//											runid = SchedulerPromelaModel.scheduler.getRunningID();
//											if (runid < 0)
//												put_schedulerState(identifier, stack.top() + 1,-1) ; //new scheduler state
//											else
//												put_schedulerState(identifier, stack.top() + 1,runid) ; //new scheduler state
//											//put_schedulerState(identifier, stack.top() + 1,SchedulerPromelaModel.scheduler.getRunningID()) ;
//											if (stack.top() == 0) {
//												verifyStatesList.add(schedulerstatehashmap.get(identifier));
//											}
//											continue;
//										}
//									}
//								} else 
								
								
								stateDone() ;
							}
							
							
							
							
							
							
							else
								stack.pushSchOpt(nextschopt);							
							if (stack.getSize() == 1) { //???
								generatecode.clearCode();
							}
						} else {							
							//add process state into stack & check the depth					
							if (!addState(state, identifier) ){	//identifier >0			
								if (errorExceedDepth) {
									report(EXCEED_DEPTH_ERROR);
								} else { 
									if (!printedDepthWarning) {
										report(EXCEED_DEPTH_WARNING);
										printedDepthWarning = true;
									}
								}
								undoTransition();								
							}
							addGenCode();
							//checkAddGenCode();
							//put_schedulerState(identifier, stack.top() + 1,SchedulerPromelaModel.scheduler.getRunningID()) ; //new scheduler state
							//runInstance = SchedulerPromelaModel.scheduler.getRunningInstance();
							runid = SchedulerPromelaModel.scheduler.getRunningID();
							if (runid < 0)
//								put_schedulerState(identifier, stack.top() + 1,-1) ; //new scheduler state
								put_schedulerState(identifier, stack.top() + 1,-1, generatecode) ; //new scheduler state
							else
//								put_schedulerState(identifier, stack.top() + 1,runid) ; //new scheduler state
								put_schedulerState(identifier, stack.top() + 1,runid, generatecode) ; //new scheduler state
						}
						continue ;
					}										
				} 				
				
				if (last == null && !isTimer 
						&& SchedulerPromelaModel.scheduler.running_process != null) { //new state with deadlock
					report(DEADLOCK) ; //next = null
					genTestCaseFollowingError();
					try {
						outputTest("Deadlock", Log.out);
					} catch (IOException e) {
						e.printStackTrace();
					}
				} 
				
				//stack.clearGenCode();
//				generatecode.clearCode();
				generatecode = codeArr[stack.top()] ;
				generatecode.gencode.clearcode("select_process");
//				if (getOtherProcessfromRunningSet(stack.getGenCode())) { //get other process				
				//next == null && last can be null when timer is considered as an action 
				if (getOtherProcessfromRunningSet()) { //get other process
					//updateGenCode(Generate.out.toString(), "select_process");	
					if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
						state = storeModel() ;
						identifier = store.addState(state);		
						stack.pushSchOpt(nextschopt);
						
						if (identifier < 0) {
							if (stack.top() == 0) {
								verifyStatesList.add(schedulerstatehashmap.get(-(identifier + 1)));
							}
							genTestCaseFollowingSearch(); 
							
//							add_exist_child(-(identifier + 1), next);
							add_exist_child(-(identifier + 1), next, generatecode);
							getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ;
							if (cyclicSchedulerStateIDList.size() > 0)
								for (int id : cyclicSchedulerStateIDList)
									updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
							else 
								updateSchedulerState(-(identifier + 1),stack.top() - 1,false, true);
							
							report(DUPLICATE_STATE.withState(state));
							nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
							statesMatched++;
							if (nextschopt == 0)
								stateDone() ;
						} else {
							replaceState(state, identifier) ; //in the stack
							//runInstance = SchedulerPromelaModel.scheduler.getRunningInstance();
							runid = SchedulerPromelaModel.scheduler.getRunningID();
							if (runid < 0)
//								put_schedulerState(identifier, stack.top() + 1,-1) ; //new scheduler state
								put_schedulerState(identifier, stack.top() + 1,-1, generatecode) ; //new scheduler state
							else
//								put_schedulerState(identifier, stack.top() + 1,runid) ; //new scheduler state
								put_schedulerState(identifier, stack.top() + 1,runid,generatecode) ; //new scheduler state
							//put_schedulerState(identifier, stack.top() + 1,SchedulerPromelaModel.scheduler.getRunningID()) ;
							if (stack.top() == 0) {
								verifyStatesList.add(schedulerstatehashmap.get(identifier));
							}
							continue;
						}
					}
				} else {					
					if (nextschopt == 0)
						stateDone() ;	
					else
						stack.pushSchOpt(nextschopt);
					continue ;
				}	
			} else  {
//				runInstance = SchedulerPromelaModel.scheduler.getRunningInstance();
//				runInstance = SchedulerPromelaModel.scheduler.getRunningID();
				runid = SchedulerPromelaModel.scheduler.getRunningID() ;
				//System.out.println("++Pid = " + runid);					
				//stack.pushGenCode(Generate.out.toString());
				//Generate.out.clear();
				try {
					SchedulerPromelaModel.scheduler.preTake();
					updateGenCode(Generate.out.toString(), "pre_take");
					
					if (nextschopt == 0)
						nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
					takeTransition(next);		
					//updateGenCode( Generate.out.toString(), "Take");
					updateGenCode(Generate.out.toString(),"new_process");
					String takeaction = next.toString();
					takeaction = "\t" + takeaction.substring(takeaction.indexOf(":")+1) + ";\n";					
					updateGenCode(takeaction,"take");					
					
					SchedulerPromelaModel.scheduler._runningSet.dataSet.clear();
					startCheckLiveLock = false ;
					SchedulerPromelaModel.scheduler.postTake();
					updateGenCode(Generate.out.toString(), "post_take");
					
					
					setProcessID(runid) ;//, SchedulerPromelaModel.scheduler.pcnt);
					recordNewProcessID() ;
					
					//stack.pushPcount(SchedulerPromelaModel._pcount);
					//stack.updateGenCode(SchedulerPromelaModel.scheduler.getGenerateCode(stack.getGenCode()));
				} catch (SpinJaException e) {					
					e.printStackTrace();
					report(TRANS_ERROR, e.getMessage());
					genTestCaseFollowingError();
					try {
						outputTest(e.getMessage(), Log.out);
					} catch (IOException ex) {
						ex.printStackTrace();
					}
					continue ;
				}
				
				if (isTimer) {
					try {
						SchedulerPromelaModel.scheduler.clock();
						updateGenCode(Generate.out.toString(), "clock");
//						Generate.out.clear();
						if (SchedulerPromelaModel.scheduler.running_process == null) {
							SchedulerPromelaModel.scheduler.select_process(-1) ;
							updateGenCode(Generate.out.toString(), "select_process");							
						}
					} catch (ValidationException e) {
						e.printStackTrace();
						report(TRANS_ERROR, e.getMessage());
						genTestCaseFollowingError();
						try {
							outputTest(e.getMessage(), Log.out);
						} catch (IOException ex) {
							ex.printStackTrace();
						}
						continue; //break ; -> don't stop
					}
				} else {				
					if (SchedulerPromelaModel.scheduler.running_process == null) {
						try {
							running_processID = SchedulerPromelaModel.scheduler.select_process(-1);
							updateGenCode(Generate.out.toString(), "select_process") ;							
						} catch (ValidationException e) {
							e.printStackTrace();
						}
					}
				}
				
				
//				print_trace() ;
				
				// If the state should be stored, try to store it
				if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
					state = storeModel() ;
					identifier = store.addState(state);
					stack.pushSchOpt(nextschopt);
					//SchedulerPanModel.scheduler.setGenCode(stack.getGenCode());					
					Generate.setBehavior(generatecode);
					//codelist.set(stack.top(),generatecode) ;
					//codeArr[codelisttop] = generatecode ; redundant
					
					if (identifier < 0) {
//						System.out.println("Duplicated ==> Undo");
						genTestCaseFollowingSearch(); 
						
//						currentSchedulerState.print();
//						add_exist_child(-(identifier + 1), next);
						add_exist_child(-(identifier + 1), next, generatecode);
						getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ; //if exist the identifier in stack
						if (cyclicSchedulerStateIDList.size() > 0)
							for (int id : cyclicSchedulerStateIDList)
								updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
						else 
							updateSchedulerState(-(identifier + 1),stack.top() - 1,false, true);
						
						nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
						statesMatched++;
						if ( Config.isCheckAcceptionCycle) { 				
							continue;
						}			
						System.out.println("**** Duplicate: " + -(identifier + 1));
						undoTransition();
						continue;
					} else {
						//put_schedulerState(identifier, stack.getSize(),next) ;											
						if ((store.getStored() & 0xfffff) == 0) {
						}
					}						
				} else { // otherwise count it
					atomicSteps++;
					identifier = hash.hash(state, 0);
				}
				//runInstance = SchedulerPromelaModel.scheduler.getRunningInstance();
				runid = SchedulerPromelaModel.scheduler.getRunningID();
				if (runid < 0)
//					put_schedulerState(identifier, stack.top() + 1,-1) ; //new scheduler state
					put_schedulerState(identifier, stack.top() + 1,-1, generatecode) ; //new scheduler state
				else
//					put_schedulerState(identifier, stack.top() + 1,runid) ; //new scheduler state
					put_schedulerState(identifier, stack.top() + 1,runid,generatecode) ; //new scheduler state
				//put_schedulerState(identifier, stack.top() + 1, SchedulerPromelaModel.scheduler.getRunningInstance()) ; //new scheduler state
				//add process state into stack & check the depth	
				
				if (!addState(state, identifier) ){			//identifier >0			
					if (errorExceedDepth) {
						report(EXCEED_DEPTH_ERROR);
					} else if (!printedDepthWarning) {
						report(EXCEED_DEPTH_WARNING);
						printedDepthWarning = true;
					}
					
					undoTransition();
					continue;
				}
				addGenCode();
				//checkAddGenCode();
				addRunningSetState();
			} //else next == null
		}		
	}
	
	private void genTestCaseFollowingSearch() {
		if (Generate.getSearchingGenerateOption()) {
			System.out.println("Start test case ##########################################");
			print_trace();
			System.out.println("End test case ##########################################");
			genTestCase() ;
		}
	}
	private void genTestCaseFollowingError() { 
		if (Generate.getErrorGenerateOption()) {
			genTestCase() ;
		}
	}
	private void genTestCase(){
		//visited states exported from stack
		if (codelisttop!=0) {	
			ArrayList<Transition> listtrans = stack.exportTrans() ;
			String processes = exportTestCasefromCodeArr(stack.top()+1) ;
			if (processes == "" || testcase.containsKey(processes)) return ;			
			processes = processes.replace("getTotalStep()", listtrans.size()+"");
			testcase.put(processes, listtrans) ;
			testprogramlist.add(processes);
		}
	}
	private void genTestCaseFollowingProperty(ArrayList<Transition> trace, ArrayList<GenerateCode> gencodelist) { //states from searching trace
		if (trace.size()==0) return ;
		if (Generate.getPropertyGenerateOption()) {		
			//record the test code
			int top = trace.size();			
			for (int i = 0 ; i < top ; i++) {
				codeArr[i] = gencodelist.get(i) ;
			}
			
			String testprogram = exportTestCasefromCodeArr(top) ;				
			if (testprogram == "" || testcase.containsKey(testprogram)) return ;		
			testprogram = testprogram.replace("getTotalStep()", trace.size()+"");
			testcase.put(testprogram, trace) ;
			testprogramlist.add(testprogram);
		}
	}
	private String exportTestCasefromCodeArr(int top) {
		int codepartsize = Generate.getPartSize() ;		
		if (codepartsize < 0) return null ;
		int processbehaviorcodeposition = Generate.getProcessBehaviorCodePosition();
		
		ArrayList<String> result = new ArrayList<String>();
		String codepart[] = new String[codepartsize];
		int pid, pinstance, assigncnt ;
		
		assigncnt = 1 ;
		ArrayList<String> codeList = new ArrayList<String>() ;
		for (int i = 0 ; i < top ; i++) {
			//collect behaviors
			codeList.add(codeArr[i].gencode.code.replace("getStep()", i+1+"")
					.replace("getTotalStep()", top + "")) ;
			//collect code part
			for (int j=0; j < codepartsize; j++) {
				if (j!=processbehaviorcodeposition) {
					if (codepart[j] != null) {
						codepart[j] += codeArr[i].gencode.part[j];
					} else {
						codepart[j] = codeArr[i].gencode.part[j];
					}
				}
			}			
		}
		//combine with initial part
		for (int j=0; j < codepartsize; j++) {
			if (j!= processbehaviorcodeposition) {
				if (Generate.part[j] != null) {
					if (codepart[j] != null)
						codepart[j] = Generate.part[j] + codepart[j] ;
					else
						codepart[j] = Generate.part[j] ;
				}				
			}
		}
		
		//re-index the process instance		
		for (int i = 0 ; i < top ; i++) {			
			if (codeArr[i].pinstance == 0) {
				assigncnt = 1;
				codeArr[i].pinstance = assigncnt;
			} else {
				assigncnt = codeArr[i].pinstance;
			}
						
			pid = codeArr[i].pid;			
			if (pid < 0) continue ;
			pinstance = codeArr[i].pcnt.get(pid);
			for (int j = i+1 ; j < top ; j++) {				
				if (codeArr[j].pid == pid) {
					if(codeArr[j].pcnt.get(pid) > pinstance)					
						codeArr[j].pinstance = ++assigncnt;
					else 
						codeArr[j].pinstance = assigncnt;
				}
			}
		}				
		
		//export test case
		String codebehavior= "";
		String actionList = "" ;
				
		boolean checked [] = new boolean[top+1];
		
		for (int i = 0 ; i < top ; i++) {		
			if (checked[i]) continue;
			checked[i] = true ;
			pid = codeArr[i].pid;			
			
			if (pid < 0) continue ;
			pinstance = codeArr[i].pinstance;	
			actionList = codeList.get(i);
			
			for (int j=i+1; j<top; j++) {	
				if (checked[j]) continue;
				if (codeArr[j].pid == pid && codeArr[j].pinstance == pinstance) { //same process
					actionList += codeList.get(j);
					checked[j] = true;
				}
			}
			codebehavior += Generate.generateProcess(pid, pinstance, actionList) + "\n";
		}	
		
		//create code (as an arraylist)
		for (int i=0; i<codepartsize; i++) {
			if (i !=processbehaviorcodeposition) {
				result.add(codepart[i]) ;
			} else {
				result.add(codebehavior) ;
			}
		}
		return Generate.genFileFollowingStructure(result);		
	}
/*		
	private String stack_exportTestCase() {   
		if (codelisttop==0)	return "";
		
		//re-index the process instance
		int top = stack.top() ;
		
		
		int pid, pinstance, assigncnt ;
		
		assigncnt = 1 ;
		for (int i = 0 ; i < top ; i++) {
			if (codeArr[i].pinstance == 0) {
				assigncnt = 1;
				codeArr[i].pinstance = assigncnt;
			} else {
				assigncnt = codeArr[i].pinstance;
			}
			
			
			pid = codeArr[i].pid;			
			if (pid < 0) continue ;
			pinstance = codeArr[i].pcnt.get(pid);
			for (int j = i+1 ; j <= top ; j++) {				
				if (codeArr[j].pid == pid) {
					if(codeArr[j].pcnt.get(pid) > pinstance)					
						codeArr[j].pinstance = ++assigncnt;
					else 
						codeArr[j].pinstance = assigncnt;
				}
			}
		}
		
		
		
		//export test case
		String result = "";
		String actionList = "" ;
		
		//for (int i = 0 ; i <= codelisttop ; i++) {		
		GenerateCode gcode ;		
		boolean checked [] = new boolean[top+1];
		
		for (int i = 0 ; i < top ; i++) {
			//gcode = codelist.get(i);
			if (checked[i]) continue;
			checked[i] = true ;
			
			gcode = codeArr[i];
			pid = gcode.pid;			
			
			if (pid < 0) continue ;
			pinstance = gcode.pinstance;
			
			actionList =  gcode.gencode.code;
			
			for (int j=i+1; j<=top; j++) {	
				if (checked[j]) continue;
				gcode = codeArr[j];
				if (gcode.pid == pid && gcode.pinstance == pinstance) { //same process				
					actionList +=  gcode.gencode.code;
					checked[j] = true;
				}
			}
			result += SchedulerPanModel.scheduler.generateProcess(pid, pinstance, actionList) + "\n";
		}		
		
		return result;
	}
*/
	
	private int count(String text, String find) {
        int index = 0, count = 0, length = find.length();
        while( (index = text.indexOf(find, index)) != -1 ) {                
                index += length; count++;
        }
        return count;
	}
	
	protected void exportTestData() {
		int testcnt = 0 ;
//			int totalOrder = 0 ;
		for (String testprogram : testprogramlist) { //testcase.keySet()) {
			PrintWriter out  ;
			//System.out.println(testprogram);
			String filename = "testgenerate/" + SchedulerPanModel.scheduler.getSchedulerName() + "_" + testcnt++;
			try {
				out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".in")));
				int num = count(testprogram, "TAKE") ;
				String pcode = testprogram ;
														
				pcode = pcode.replace("TAKE_NEWP", "1");
				pcode = pcode.replace("TAKE_NEWQ", "2");
				pcode = pcode.replace("TAKE_END", "3");
				pcode = pcode.replace("TAKE_", "0");					
				pcode += " 4" ; //FINISH
				
				//out.append(Gen.header  + num + "\n" + pcode + "\n" + testprogram + " FINISH") ;
				out.append(num + "\n" + pcode + "\n" + testprogram + " FINISH") ;
				out.flush();
				out.close();
				System.out.println("------------------");
				System.out.println("sspinja: wrote testcase to " + filename);
//					Log.out.printf("sspinja: wrote testcase to " + filename);
//					System.out.println(pcode) ;
//					System.out.println(num + " : " + testprogram);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
//				try {
//					out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".out")));
//					executionTrans = testcase.get(testprogram);
////					int i = 0 ;
////					for (Transition t : executionTrans) 
////						System.out.println((i++) + t.toString());
////					System.out.println("------------------");
//										
////					if (testcnt == 9)
////						System.out.print("Stop to view");
//					
//					String tp = testprogram ;
//					
//					int index = 0 ;
//					actlist.clear();
//					while (index != -1) {
//						index = tp.indexOf(" TAKE_") ;
//						tp = tp.substring(index + 1) ;
//						index = tp.indexOf(" TAKE_") ;
//						if (index != -1)
//							actlist.add(tp.substring(0, index)) ;
//						else
//							actlist.add(tp) ;												
//					}
//					
////					executionOrder.clear();
//					realExec.clear();
//					for (SchedulerState stSchedulerState : verifyStatesList) {
//						order.clear(); //used as stack
//						//getExecutionOrder(stSchedulerState, 0, executionTrans.size());
//						getExecutionOrder(stSchedulerState,executionTrans);
//					}					
//					
//					HashSet<String> order = new HashSet<String>() ;
//					String pOrder ;
//					for (ArrayList<Integer> exec : realExec) {
//						//System.out.println(exec);						
//						pOrder = resetProcessID(exec) ;
//						//System.out.println(pOrder);
//						order.add(pOrder);						
//					}
//					for (String exec : order)
//						out.append(exec + "\n") ;
//					out.flush();
//					out.close();	
//					totalOrder += order.size();
//					System.out.println("sspinja: wrote test output to " + filename + ", number of execution order: " + order.size());
//					Log.out.printf("sspinja: wrote test output to " + filename + ", number of execution order: " + order.size() + "\n");
//				} catch (IOException e) {
//					e.printStackTrace();
//				}				
		}
		//Log.out.printf("total running order: " + totalOrder + "\n");
	}
	
	ArrayList<String> actlist = new ArrayList<String>() ;	
//	ArrayList<String> executionOrder = new ArrayList<String>() ;
	ArrayList<ArrayList<Integer>> realExec = new ArrayList<ArrayList<Integer>>() ;
	
	ArrayList<Transition> executionTrans  = new ArrayList<Transition>() ;
	ArrayList<Integer> order = new ArrayList<Integer>();
	
	private void addExecutionOrder(ArrayList<Integer> newExec){
		//only add the different execution
		ArrayList<Integer> oldExec ;
		
		if (realExec.size()==0) {
			realExec.add((ArrayList<Integer>) newExec.clone()) ;			
		}	else {
			boolean diff = true ; //newExec differ from all of realExec
			boolean perdiff ;			
			for (int i = 0; i < realExec.size() ; i++) {
				oldExec = realExec.get(i);
				if (newExec.size() != oldExec.size()) continue ;
				perdiff = false ;
				 
				for (int j = 0 ; j < oldExec.size(); j++) {					
					if (newExec.get(j) != oldExec.get(j)) {
						perdiff = true ;
						break ;
					} 
				}
				if (!perdiff) {
					diff = false ;
					break ;
				}
			}
			if (diff)
				realExec.add((ArrayList<Integer>) newExec.clone()) ;
		}		
	}
	
	private void getExecutionOrder(SchedulerState state, ArrayList<Transition> executionTrans){
		ArrayList<SchedulerState> listState = new ArrayList<SchedulerState> () ;
		ArrayList<Integer> listID = new ArrayList<Integer>() ;
		ArrayList<Integer> listtransID = new ArrayList<Integer>() ;
		
		
		int total = executionTrans.size();
		int tstep = 0 ;
		int transid = 0 ;		
					
		Transition execnext ;
		Transition curtrans = null ;
		int transize ;
		
		String s_curtrans, s_execnext;
//		int k = 0 ;
//		for (Transition t : executionTrans) 
//			System.out.println((k++) + t.toString());
//		System.out.println("------------------");
		
		boolean foundtrans;		
		while (true) {
			//exploring the graph?
			if (tstep == total) {
				for(int i = 0 ; i < total;i++) {
					order.add(listID.get(i)) ;
				}				
				addExecutionOrder(order) ;
				//System.out.println("Add: " + order);
				order.clear();
				tstep--;				
				if (tstep < 0)
					break ;
				else
					state = listState.get(tstep);
			} else {
				if (listState.size() < tstep + 1) {
					listState.add(state) ;
					listID.add(state.runinstance) ;
				}
				execnext = executionTrans.get(tstep) ; //tstep same as top of the stack?
				
				if (listtransID.size() <= tstep) {
					transid = 0 ;
					foundtrans = false ; //start with the beginning transition
				} else {
					transid = listtransID.get(tstep) + 1;
					foundtrans = true ; //already found a suitable transition
				}
				transize = state.trans.size() ;
				
				s_execnext = execnext.toString().trim() ;
				s_execnext = s_execnext.substring(s_execnext.indexOf("):")) ;
				
				while (transid < transize){
					curtrans = state.trans.get(transid) ;
					if (curtrans == null) 
						break ; //can not find suitable transition
					//if(curtrans.getId() != execnext.getId())
					s_curtrans = curtrans.toString().trim() ;
					s_curtrans = s_curtrans.substring(s_curtrans.indexOf("):")) ;
					
					//System.out.println(s_curtrans + " ? " + s_execnext);
					if(!s_curtrans.equals(s_execnext))
						transid++;
					else {
						foundtrans = true ;
						break ; //found suitable transition
					}
				}
				
				if (!foundtrans) {
					//System.out.println("Can not find suitable transition");
					//record the steps until the current one
					for(int i = 0 ; i < tstep;i++) {
						order.add(listID.get(i)) ;
					}			
					if (order.size() > 0) {
						addExecutionOrder(order) ;
						//System.out.println("Add: " + order + " partial");
						order.clear();
					}
//					tstep--;				
//					if (tstep < 0)
//						break ; //finish
//					else
//						state = listState.get(tstep);
					
					listState.remove(tstep) ;
					if (listtransID.size() > tstep )
						listtransID.remove(tstep) ;
					
					listID.remove(tstep);
					tstep-- ;
					if (tstep < 0) break ; 
					else state = listState.get(tstep) ;
				} else {				
					if (transid == transize) {
						//search all transitions done
						listState.remove(tstep) ;
						if (listtransID.size() > tstep )
							listtransID.remove(tstep) ;
						
						listID.remove(tstep);
						tstep-- ;
						if (tstep < 0) break ;
						else state = listState.get(tstep) ;
					} else {
						//found transition
						if (listtransID.size() < tstep + 1) {
							listtransID.add(transid) ; //addnew
						} else {
							listtransID.set(tstep, transid) ; //replace
						}
						if (transid < state.next.size() ) { 
							state = state.next.get(transid) ;
						}
						tstep++ ;
						//else tstep--;
					}	
				}
			}
		}
	}
	
	protected void getExecutionOrder( SchedulerState state, int num, int total) {
		if (num == total) {
			addExecutionOrder(order) ;
			
//			String pOrder = resetProcessID(order) ;
//			//String pOrder = order ;
//			if (!executionOrder.contains(pOrder)) {
//				executionOrder.add(pOrder) ;
//				System.out.println(pOrder);
//			}
		} else {
			Transition t = executionTrans.get(num) ;
		
			int index = 0 ;
			for (Transition tr : state.trans) {
				if (tr != null) {
					if (checkTrans(tr, t)) {	
						SchedulerState next = state.next.get(index) ;
						order.add(state.runinstance) ;
						getExecutionOrder(next,num+1,total) ;
						order.remove(order.size()-1) ;
						//order.remove(state.runinstance) ;
					}
				}
				index++;
			}
		}			
	}
	
	int pinstance [] = new int [128] ;
	private String resetProcessID(ArrayList<Integer> order) {		
		String result = "" ;
		
		for (int i = 0 ; i < 128 ; i ++) pinstance[i] = -2 ;
		
//		ArrayList<Integer> pidlist = new ArrayList<Integer>() ;
		//int index = order.indexOf(" ") ;
		
		//System.out.println("Actlist: " + actlist);
		
//		String tp = order ;		
//		int pid ;
//		while (index != -1) {
//			pid = Integer.parseInt(tp.substring(0, index)) ;
//			//if (pid > max) max = pid;
//			pidlist.add(pid) ;
//			tp = tp.substring(index + 1) ;
//			index = tp.indexOf(" ") ;
//		}
		
		for (int i = 0; i < SchedulerPanModel.scheduler.get_init_process_count(); i++)
			pinstance[order.get(i)] = order.get(i);
		//pinstance[order.get(1)] = order.get(1); //for 2nd process at starting time
			
		int instance = 0 ;		
		int pid ;		
		for (int i = 0 ; i < order.size(); i ++) {
			String act = actlist.get(i) ;
			pid = order.get(i) ;
			if (instance < pid) instance = pid ;
			switch (act) {
				case "TAKE_END" :
					if (pinstance[pid] == -1) {
						result += pid + " ";
					} else {
						result += pinstance[pid] + " ";
						pinstance[pid] = -1 ;
					}						
					
					break ;					
				case "TAKE_NEWP" :
				case "TAKE_NEWQ" :
					if (pinstance[pid] == -1) {
						result += pid + " ";						
					} else {
						result += pinstance[pid] + " ";						
					}			
					int j = 0 ;
					while (pinstance[j] >= 0) j++ ; //always stop?
					pinstance[j] = ++instance ; //wrong
					break ;
				default:
					if (pinstance[pid] == -1) {
						result += pid + " ";
					} else {
						result += pinstance[pid] + " ";					
					}
			}
		}		
	
		return result ;
	}
	private boolean checkTrans(Transition trans1, Transition trans2) {	
		if (trans1.getId() == trans2.getId())
			return true ;
		
//		int pos = trans1.toString().indexOf(":");
//		String t1 = trans1.toString().substring(pos + 1).trim() ;
//		pos = trans2.toString().indexOf(":");
//		String t2 = trans2.toString().substring(pos + 1).trim() ;
//				
//		if (t1.equals(t2))
//			return true ;
		return false ;
	}
		
	
	protected void writeTestCase() { //write test case
		int testcnt = 0 ;
		for (String testprogram : testcase.keySet()) {			
			PrintWriter out  ;
			try {
				String filename = Generate.getGenerateDirectory() + "/"
						+ Generate.getGenerateFileName() 
						+ "_" + (testcnt++) + "." + Generate.getGenerateFileExtension();
				out = new PrintWriter(new BufferedWriter(new FileWriter(filename)));					
//					out.append(Gen.header.replace("getTotalStep()", stack.top() + "")  + testcode) ;
					out.append(testprogram) ;
				out.flush();
				out.close();		
				System.out.println("sspinja: wrote testcase to " + filename);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
//	private void relocateGenCode(int top) {
//		codelisttop = top ; //~ stack.getSize()-1
//		if (codelisttop >= 0) { 
//			//generatecode = codelist.get(codelisttop) ;
//			generatecode = codeArr[codelisttop] ;
//			SchedulerObject.setPcnt(generatecode.pcnt) ;
//			generatecode.clearCode();
//		}
//	}
	protected void stateDone() {
		super.stateDone();
//		relocateGenCode(stack.top()) ;
//		if (stack.getSize() > 0) {
//			codelisttop = stack.top() ;
//			generatecode.pcnt = 
//			SchedulerPanModel.scheduler.pcnt = stack.pcnt[stack.top()].clone() ;
////			SchedulerPromelaModel._pcount = stack.pcount[stack.top()-1];
//			stack.clearGenCode();
//		}		
	}
	protected void undoTransition() {	
		System.out.println("------------undo transition");
		super.undoTransition();
		generatecode.clearCode();
		int top = stack.top();
		if (top > 0)
			SchedulerObject.setPcnt(codeArr[top -1].pcnt) ;
//		if (stack.getSize() > 0) {
//			SchedulerPanModel.scheduler.pcnt = stack.pcnt[stack.top()].clone() ;
////			SchedulerPromelaModel._pcount = stack.pcount[stack.top()-1];
//			stack.clearGenCode();
//		}		
	}

 	protected void put_schedulerState(int identifier, int depth, Transition trans) {
		SchedulerState schState = new SchedulerState() ;
		schState.results = ((SchedulerPromelaModel) model).init_atomicf() ;
		schState.checked = ((SchedulerPromelaModel) model).init_sf() ;
		
		schState.identifier = identifier ;
		//schState.father = currentSchedulerState ;
		
		if (currentSchedulerState != null) {
			currentSchedulerState.next.add(schState) ;
			currentSchedulerState.trans.add(trans) ;
		}
		schedulerstatehashmap.put(identifier, schState); //if hash table is over
		state_count ++ ;
		if (((SchedulerPromelaModel) model).stateCheck()) {
			verifyStatesList.add(schState);
		}
	}	
	private void getCyclicSchedulerStateID(ArrayList<Integer> listID) {
		for (int i = 0 ; i < listID.size(); i++)
			if (!cyclicSchedulerStateIDList.contains(listID.get(i))){
				cyclicSchedulerStateIDList.add(listID.get(i)) ;
			}
	}
	private void updateSchedulerState(int stateid, int depth, boolean isCycle, boolean isCurrentState) {
		SchedulerState schState = schedulerstatehashmap.get(stateid) ;
		schState.duplicate = isCycle ; //????
		schState.update(depth, isCycle, isCurrentState) ;
	}
	
	
	protected void outputTest(final String text, PrintWriter out) throws IOException {
		out.println(text);
		for (int i = 0; i < stack.getSize(); i++) {
			if (stack.getTransition(i) != null) {
				out.println(i + "." + stack.getTransition(i).toString());
			} else {
				break;
			}
		}		
		out.println("------------------------------------------------");
	}
	private void PrintGraph() {		
		ArrayList<SchedulerState> schStateList = new ArrayList<SchedulerState>() ;
		for (SchedulerState stSchedulerState : verifyStatesList) {
			System.out.println("+");
			stSchedulerState.print(schStateList, "",false);			
		}
	}
	private void LabelGraph() {		
//		System.out.println("Graph before label");
//		PrintGraph();

		for (SchedulerState s : verifyStatesList) {
			for (int fi=formula.length-1; fi >= 0; fi --) {	
//				System.out.println(formula.opcode[fi]);
				if (formula.opcode[fi] != "atomic") {
					int n = formula.sn[fi] ;
					labelgraph(fi, s, n) ;
//					PrintGraph();
				}
			}
//			System.out.println("Graph result");
//			PrintGraph();

			if (s.results[0]) {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Satisfied") ;
				Log.out.println(formula.toString() + " : Satisfied");
				Log.analysisresult = true ;
			} else {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Unsatisfied") ;
				Log.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Unsatisfied");
				Log.analysisresult = false ;
			}
		}
//		System.out.println("Graph result");
//		PrintGraph();
	}
	private void labelgraph(int fi, SchedulerState s, int n){
//		System.out.println("--------------------------------") ;
//		System.out.println("label [" + fi + "]:" +  formula.opcode[fi] + " for " + s.identifier); s.print(); s.printchildlist();
		switch (formula.opcode[fi]) {
			case "atomic" :
				break ; //already labeled	
			case "not" :
				label_not(fi,s);
				break ;	
			case "or" :
				label_or(fi,s) ;
				break;
			case "implies" :
				label_implies(fi,s) ;
				break;
				
			case "AX" :
				label_ax(fi,s);
				break ;
			case "AF" :				
				label_af(fi,s,n);
				break ;
			case "AG" :
				label_ag(fi,s, n);
				break ;
				
			case "EX" :
				label_ex(fi,s);
				break ;
			case "EF" :
				label_ef(fi,s,n);
				break ;
			case "EG" :
				label_eg(fi,s, n);
				break ;			
			case "AU" :
				label_au(fi,s, n);
				break ;				
			case "EU" :
				label_eu(fi,s, n);
				break ;
		}
//		System.out.println("-> result labeled [" + fi + "] " + formula.opcode[fi] + " for " + s.identifier); s.print(); s.printchildlist();
	}
	
	private void label_not(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		s.results[fi] = !s.results[s1];
		s.checked[fi] = true ;
	}
	private void label_or(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		byte s2 = formula.sf[fi][1] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		if (!s.checked[s2]) labelgraph(s2,s,-1);
		s.results[fi] = s.results[s1] || s.results[s2];
		s.checked[fi] = true ;
//		for (SchedulerState child : s.next) { //check all
//			label_or(fi,child) ;					
//		}
	}
	private void label_implies(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		
		byte s1 = formula.sf[fi][0] ;
		byte s2 = formula.sf[fi][1] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		if (!s.checked[s2]) labelgraph(s2,s,-1);
		s.results[fi] = ! s.results[s1] || s.results[s2];		
		s.checked[fi] = true ;
//		for (SchedulerState child : s.next) { //check all
//			label_implies(fi,child) ;					
//		}
	}
	
	private void label_ax(int fi, SchedulerState s) {
		//for all path starting at s, next time fi -> s1 (fi == AX s1)
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		boolean result = true ;
		for (SchedulerState child : s.next) {
			if (!child.checked[s1])
				labelgraph(s1, child, -1) ;
			if (! child.results[s1]) {
				result = false ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	private void label_af(int fi, SchedulerState s, int n) {
		//for all paths starting at s, eventually fi	
//		s.print();
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula -> s1
		s.checked[fi] = true ;
					
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;		
		
		if (s.results[s1]) {	//check node		
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ;
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop ????????????????????
						if (child.results[fi]) {
						} else {							
							noderesult = false ;							
							break ;
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (!child.results[fi]) {
							noderesult = false ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}
//		s.print();
	}
	private void label_ag(int fi, SchedulerState s, int n) {
		//for all paths starting at s, always fi
		if (s.checked[fi]) return ;
		s.checked[fi] = true ;
		
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1	
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
//		System.out.println("Before:");
//		s.print() ;
		
		if (!s.results[s1]) {	//check node			
			s.results[fi] = false ;
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop																			
						if (child.results[s1]) {
						} else {		
							child.results[fi] = false ;
							noderesult = false ;
							break ;
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (!child.results[s1]) {
							noderesult = false ;
							break ;
						}
					}
					 
				}
				s.results[fi] = noderesult ;			
			}
		}
//		System.out.println("After:");
//		s.print() ;
	}

	private void label_ex(int fi, SchedulerState s) {
		//exist path starting at s, next time fi -> s1
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		boolean result = false ;
		for (SchedulerState child : s.next) {
			if (!child.checked[s1])
				labelgraph(s1, child, -1) ;
			if (child.results[s1]) {
				result = true ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	private void label_ef(int fi, SchedulerState s, int n) {
		//exist a path starting at s, eventually fi
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula -> s1
		s.checked[fi] = true ;
					
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		
		if (s.results[s1]) {	//check node		
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ; //s1 = false
			else {
				boolean noderesult = false ; //exist true -> true
				
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[fi]) {				
							noderesult = true ;
							break ;
						} else {				
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}		
	}
	private void label_eg(int fi, SchedulerState s, int n) {
		//exists a path starting at s, always fi		
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1
		s.checked[fi] = true ;
			
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		
		s.checked[fi] = true ;
		if (!s.results[s1]) {	//check node		
			s.results[fi] = false ;
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = false ; //exist true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[s1]) {
							child.results[fi] = true ; //update
							noderesult = true ;
							break ;
						} else {							
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;			
			}
		}
	}
	
	private void label_au(int fi, SchedulerState s, int n) {
		//all path starting at s, s1 until s2
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		if (!s.checked[s2])
			labelgraph(s2, s, n) ;
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = true ; //exist path false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (!child.results[s1] && !child.results[s2]) {							
							noderesult = false ;
							break ;
						} else {
							child.results[fi] = true ;
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (!child.results[fi]) {						
						noderesult = false ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}			
	}
	private void label_eu(int fi, SchedulerState s, int n) {
		//exist path starting at s, s1 until s2
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		if (!s.checked[s2])
			labelgraph(s1, s, n) ;
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = false ; //exist path true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (!child.results[s1] && !child.results[s2]) {
							//false -> ignore
							child.results[fi] = false ;
						} else {
							child.results[fi] = true ;
							noderesult = true ;
							break ;
						} 
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0								
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (child.results[fi]) {						
						noderesult = true ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}
	}


	
	
	protected void outputTrace(final String text, ArrayList<Transition> trace, PrintWriter out) throws IOException {					
		if (trace.size() == 0) {
			out.println(". No trace");
			System.out.println(". No trace");
		} else {
			out.println("------------------------------------------------");
			System.out.println("------------------------------------------------");
			out.println(text);
			System.out.println(text);
			for (int i=0; i<trace.size();i++) {
				out.println(i + ". " + trace.get(i));
				System.out.println(i + ". " + trace.get(i));
			}				
			out.println("------------------------------------------------");
			System.out.println("------------------------------------------------");
		}
	}
	protected void PrintTrace(boolean expectedValue, ArrayList<Transition> trace, ArrayList<GenerateCode> gencodelist, SchedulerState s, int fi, int length, int n) {
		//PrintTrace(true,0,visitedStates, trace, schedulerstate, 0 (fi) , formula.length - 1, formula.sn[0]);
		int index;
		byte s1, s2 ;
		Transition trans ;
		
		if (s.results[fi] != expectedValue) return ;
		if (!s.checked[fi]) {
			try {
				outputTrace(formula.toString(),trace,Log.out) ;
				genTestCaseFollowingProperty(trace,gencodelist);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return ;
		}
		
		switch (formula.opcode[fi]) {
			case "atomic" :
				try {
					outputTrace(formula.toString(),trace,Log.out) ;
					genTestCaseFollowingProperty(trace,gencodelist);
				} catch (IOException e) {
					e.printStackTrace();
				}
				break ;
			
			case "not" :
				s1 = formula.sf[fi][0];											
				PrintTrace(!expectedValue, trace, gencodelist, s, s1, length, n); //do not care super script n	
				break ;
			
			case "implies" :
				s1 = formula.sf[fi][0];
				s2 = formula.sf[fi][1];
				
				if (expectedValue) { //true: F -> (T,F) & T -> T
					if (s.results[s1]) { //s1 true, must s.checked[s1]
						PrintTrace(true, trace,gencodelist, s, s2, length, n); //follow s2
					} else { //s1 false or true (don't care)
						PrintTrace(false,trace,gencodelist, s, s1, s2, n);
					}
				} else { //false: T(s1)->F(s2)
					PrintTrace(false, trace, gencodelist,s, s1, s2, n);
				}
				break ;
				
			case "or" :
				s1 = formula.sf[fi][0];
				s2 = formula.sf[fi][1];
				
				if (expectedValue) { //expected true					
					if (s.results[s1]) { //s1 true (checked)
						PrintTrace(true, trace, gencodelist,s, s1, s2, n);					
					} else { //s2 true
						PrintTrace(true, trace,gencodelist, s, s2, length, n); //follow s2
					}			
				} else { //expected false s1 & s2 -> false					
					if (formula.opcode[s1] == "atomic") {
						PrintTrace(false, trace, gencodelist,s, s2, length, -1) ;
					} else {
						if (formula.opcode[s2] == "atomic") {
							PrintTrace(false, trace,gencodelist, s, s1, s2, -1) ;
						} else {
							if (!visitedStates.contains(s)) {
								visitedStates.add(s) ;	//for first adding
							}
							index = 0 ;
							for  (SchedulerState child : s.next) {
								trace.add(s.trans.get(index)) ;
								gencodelist.add(s.generatecodes.get(index));
								if (child.checked[s1] && child.checked[s2]) {
									if (!visitedStates.contains(child)) {
										visitedStates.add(child);
										PrintTrace(expectedValue, trace,gencodelist, child, fi, length, -1) ;											
										//visitedStates.remove(visitedStates.size()-1) ;
									} else { //loop found -> print out
										try {
											outputTrace(formula.toString(),trace,Log.out) ;
											genTestCaseFollowingProperty(trace,gencodelist);
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
									index ++ ;
									trace.remove(trace.size()-1) ;
									gencodelist.remove(gencodelist.size()-1);
								}
							}
						}
					}
				}
				break ;					
				
			case "AX" : //all (next node) children must be true
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;		
					gencodelist.add(s.generatecodes.get(index));
					PrintTrace(expectedValue,trace,gencodelist, child, s1, length, n); //do not care super script n
					trace.remove(trace.size()-1) ;	
					gencodelist.remove(gencodelist.size()-1);
					index ++ ;
				}
				break ;
			
				
				
			case "AF" : //all children future true (with supper script)				
				s1 = formula.sf[fi][0];
								
				if (s.results[s1] == expectedValue) { //ok current state has expectedValue				
					if (n == -1) { //no superscript
						PrintTrace(expectedValue, trace,gencodelist, s, s1, length, -1) ;					
					} else { 
						if (n > 1) {
							PrintTrace(expectedValue, trace,gencodelist, s, s1, length, n-1);
						} else {//n == 0
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestCaseFollowingProperty(trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}							
					}
				} else { //consider next state
					if (!visitedStates.contains(s)) {
						visitedStates.add(s) ;	//for first adding
					}
					index = 0 ;
					for  (SchedulerState child : s.next) {
						trace.add(s.trans.get(index)) ;
						gencodelist.add(s.generatecodes.get(index));
						if (!visitedStates.contains(child)) {
							visitedStates.add(child);							
							if (n == -1) { //no superscript
								PrintTrace(expectedValue,trace,gencodelist, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(expectedValue,trace,gencodelist, child, fi, length, n-1);
								} else {//n == 0
									try {
										outputTrace(formula.toString(),trace,Log.out) ;
										genTestCaseFollowingProperty(trace,gencodelist);
									} catch (IOException e) {
										e.printStackTrace();
									}
								}							
							}								
							//visitedStates.remove(visitedStates.size()-1) ;
						} else { //loop found -> print out
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestCaseFollowingProperty(trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						index ++ ;
						trace.remove(trace.size()-1) ;
						gencodelist.remove(gencodelist.size()-1);
					}
				}
				break ;
				
			case "AG" :				
				s1 = formula.sf[fi][0];
								
				//consider every state
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;
					gencodelist.add(s.generatecodes.get(index));
					if (!visitedStates.contains(child)) {
						visitedStates.add(child);						
						if (n == -1) { //no superscript
							PrintTrace(expectedValue,trace, gencodelist,child, fi, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(expectedValue,trace,gencodelist, child, fi, length, n-1);
							} else {//n == 0
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestCaseFollowingProperty(trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}							
						}							
						//visitedStates.remove(visitedStates.size()-1) ;
					} else { //already visited -> print out (detect a loop)
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestCaseFollowingProperty(trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					trace.remove(trace.size()-1) ;
					gencodelist.remove(gencodelist.size()-1);
					index ++ ;
				}				
				break ;
				
			case "EX" :		
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					if (s.checked[fi] && s.results[fi]== expectedValue) {
						trace.add(s.trans.get(index)) ;			
						gencodelist.add(s.generatecodes.get(index));
						PrintTrace(expectedValue,trace,gencodelist, child, s1, length, n); //do not care super script n
						trace.remove(trace.size()-1) ;
						gencodelist.remove(gencodelist.size()-1);
//						break;
					}									
					index ++ ;
				}
				break ;				
				
			case "EF" :				
				s1 = formula.sf[fi][0];
				
				if (s.results[s1] == expectedValue) { //ok current state has expectedValue				
					if (n == -1) { //no superscript
						PrintTrace(expectedValue, trace,gencodelist, s, s1, length, -1) ;					
					} else { 
						if (n > 1) {
							PrintTrace(expectedValue, trace,gencodelist, s, s1, length, n-1);
						} else {//n == 0
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestCaseFollowingProperty(trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}							
					}
				} else { //consider next state
					if (!visitedStates.contains(s)) {
						visitedStates.add(s) ;	//for first adding
					}
					index = 0 ;
					for  (SchedulerState child : s.next) {
						if (child.checked[fi] && child.results[fi] == expectedValue) {
							trace.add(s.trans.get(index)) ;
							gencodelist.add(s.generatecodes.get(index));
							if (!visitedStates.contains(child)) {
								visitedStates.add(child);							
								if (n == -1) { //no superscript
									PrintTrace(expectedValue,trace,gencodelist, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(expectedValue,trace, gencodelist,child, fi, length, n-1);
									} else {//n == 0
										try {
											outputTrace(formula.toString(),trace,Log.out) ;
											genTestCaseFollowingProperty(trace,gencodelist);
										} catch (IOException e) {
											e.printStackTrace();
										}
									}							
								}
							} else { //loop found -> print out
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestCaseFollowingProperty(trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
							trace.remove(trace.size()-1) ;
							gencodelist.remove(gencodelist.size()-1);
						}
						index ++ ;						
					}
				}
				break ;
				
				
				
			case "EG" :				
				s1 = formula.sf[fi][0];
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				index = 0 ;	
				for  (SchedulerState child : s.next) {
					if (child.checked[fi] && child.results[fi] == expectedValue) {
						trace.add(s.trans.get(index)) ;
						gencodelist.add(s.generatecodes.get(index));
						if (!visitedStates.contains(child)) {
							visitedStates.add(child);						
							if (n == -1) { //no superscript
								PrintTrace(expectedValue,trace,gencodelist, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(expectedValue,trace,gencodelist, child, fi, length, n-1);
								} else {//n == 0
									try {
										outputTrace(formula.toString(),trace,Log.out) ;
										genTestCaseFollowingProperty(trace,gencodelist);
									} catch (IOException e) {
										e.printStackTrace();
									}
								}							
							}
						} else { //already visited -> print out (detect a loop)
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestCaseFollowingProperty(trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						trace.remove(trace.size()-1) ;
						gencodelist.remove(gencodelist.size()-1);
					}
					index ++ ;
				}				
				break ;
			
			case "AU" :				
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				
				index = 0 ;
				for  (SchedulerState child : s.next) { //check all children					
					trace.add( s.trans.get(index) ) ;			
					gencodelist.add(s.generatecodes.get(index));
					if (! visitedStates.contains(child)) { //loop
						visitedStates.add(child) ;
						if (n == -1) { //no superscript
							PrintTrace(expectedValue,  trace,gencodelist, child, fi, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(expectedValue,  trace,gencodelist, child, fi, length, n-1);
							} else {//n == 0
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestCaseFollowingProperty(trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}							
						}
					} else {						
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestCaseFollowingProperty(trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}					
					trace.remove(trace.size()-1) ;
					gencodelist.remove(gencodelist.size()-1);
					index ++ ;
				}
				break ;
				
				
			case "EU" :
				if (s.results[fi] != expectedValue) return ;
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				
				if (s.results[s2]) { //s2 = true -> ok
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestCaseFollowingProperty(trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
					break ;
				}
					
				if (s.next.size() == 0) { //no child
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestCaseFollowingProperty(trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
				} else {
					index = 0 ;
					for  (SchedulerState child : s.next) { //check all children
						if (child.results[fi]) {
							trans = s.trans.get(index) ;
							gencodelist.add(s.generatecodes.get(index));
							if (visitedStates.contains(child)) { //loop
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestCaseFollowingProperty(trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							} else {
								trace.add(trans) ;	
								visitedStates.add(child) ;
								if (n == -1) { //no superscript
									PrintTrace(expectedValue,  trace,gencodelist, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(expectedValue,  trace,gencodelist, child, fi, length, n-1);
									} else {//n == 0
										if (trace.size() > 0)
											try {
												outputTrace(formula.toString(),trace,Log.out) ;
												genTestCaseFollowingProperty(trace,gencodelist);
											} catch (IOException e) {
												e.printStackTrace();
											}
										else
											s.print();
									}							
								}
								trace.remove(trace.size()-1) ;
								gencodelist.remove(gencodelist.size()-1);
								//visitedStates.remove(visitedStates.size()-1) ;
							}
							break ;
						}
						index ++ ;
					}
				}
				break ;
			
		}
	}
}