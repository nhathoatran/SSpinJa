// Copyright 2010, University of Twente, Formal Methods and Tools group
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package sspinja.scheduler.search;

import static spinja.search.Message.DEADLOCK;
import static spinja.search.Message.DUPLICATE_STATE;
import static spinja.search.Message.EXCEED_DEPTH_ERROR;
import static spinja.search.Message.EXCEED_DEPTH_WARNING;
import static spinja.search.Message.LIVELOCK;
import static spinja.search.Message.TRANS_ERROR;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import spinja.exceptions.SpinJaException;
import spinja.exceptions.ValidationException;
import spinja.model.Condition;
import spinja.model.Model;
import spinja.model.SchedulerTransition;
import spinja.model.Transition;
import spinja.promela.model.PromelaTransition;
import spinja.promela.model.PromelaTransitionFactory.NonAtomicTransition;
import spinja.search.TransitionCalculator;
import spinja.store.StateStore;
import spinja.util.Log;
import spinja.util.Util;
import sspinja.CTLFormula;
import sspinja.Config;
import sspinja.Generate;
import sspinja.GenerateCode;
import sspinja.SchedulerObject;
import sspinja.SchedulerPanModel;
import sspinja.SchedulerState;
import sspinja.scheduler.promela.model.SchedulerPromelaModel;

public class SchedulerCTLGenSearch<M extends Model<T>, T extends Transition> extends SchedulerSearchAlgorithm<M, T> {	
	private static final long serialVersionUID = 1L;
	
	HashMap<Integer, SchedulerState> schedulerstatehashmap ;	
	
	private int state_count = 0 ;
	private SchedulerState startSchedulerState = null ;
	private SchedulerState currentSchedulerState = null ;
	private ArrayList<SchedulerState> verifyStatesList ;
	private CTLFormula formula;
	private ArrayList<Integer> cyclicSchedulerStateIDList;
	ArrayList<Transition> starttrace;	
	HashSet<SchedulerState> visitedStates ;
	ArrayList<Transition> trace ;
	
	public static GenerateCode generatecode ;
	private GenerateCode initCode ;
	private GenerateCode [] codeArr = new GenerateCode[10000] ;
	private int codelisttop = -1 ;
	HashMap<String, ArrayList<Transition>> testcase = new HashMap<String, ArrayList<Transition>>() ;
	ArrayList<String> testprogramlist = new ArrayList<String>() ;
	
	public SchedulerCTLGenSearch(M model, StateStore store, int stackSize, boolean errorExceedDepth,
			boolean checkForDeadlocks, int maxErrors, TransitionCalculator<M, T> nextTransition) {
		super(model, store, stackSize, errorExceedDepth, checkForDeadlocks, maxErrors, nextTransition);
		
		schedulerstatehashmap = new HashMap<Integer, SchedulerState>();
		cyclicSchedulerStateIDList = new ArrayList<Integer>() ;
		verifyStatesList = new ArrayList<SchedulerState>() ;
		formula = new CTLFormula() ;
		starttrace = new ArrayList<Transition> ();
		Log.initLog(SchedulerPanModel.scheduler.getSchedulerName());
	}

	@Override
	protected Transition nextTransition() {		
		return model.nextTransition(null) ;
	}

	@Override
	protected Transition nextTransition(Transition last) {	
		return model.nextTransition((T) last) ;
	}	
	
	protected int getRunID() {
		return model.getRunID();
	}
	protected int getExecID() {
		return model.getExecID();
	}
	protected void takeTransition(final Transition next) throws SpinJaException {		
		stack.takeTransition(next);
	}
	
	/*
	private void add_exist_child_state(int identifier, Transition trans) {
		if (trans == null) return ;
		boolean isExist = false ;
		for (SchedulerState node : currentSchedulerState.next) {
			if (node.identifier == identifier) isExist = true ;
		}
		SchedulerState child = schedulerstatehashmap.get(identifier) ;
		if (! isExist) {
			currentSchedulerState.next.add(child) ;
			currentSchedulerState.trans.add(trans);
		}
	}
	*/
	
	private void add_exist_child_state(int identifier, Transition trans, GenerateCode generatecode) {
		SchedulerState child = schedulerstatehashmap.get(identifier) ;
		if (stack.top()==0) {
			if (!startSchedulerState.next.contains(child)) {
				startSchedulerState.next.add(child) ;			
				GenerateCode code = generatecode.clone() ;			
				startSchedulerState.generatecodes.add(code);
				verifyStatesList.add(child);
			}
		} else {
			if (trans == null) return ;
			boolean isExist = false ;
			for (SchedulerState node : currentSchedulerState.next) {
				if (node.identifier == identifier) isExist = true ;
			}
			
			if (! isExist) {
				currentSchedulerState.next.add(child) ;
				currentSchedulerState.trans.add(trans);
				GenerateCode code = generatecode.clone() ;
				code.pcnt.clear();
				code.stateid = currentSchedulerState.identifier ;
				code.pcnt.addAll(SchedulerPromelaModel.scheduler.pcnt);
				currentSchedulerState.generatecodes.add(code);
	//			System.out.println(generatecode.gencode.code);
	//			System.out.println(code.pcnt);
	//			System.out.println(generatecode.pcnt);		
			}
		}
	}
	
	private void put_schedulerState(int identifier, int depth, int prunid, int execid, GenerateCode generatecode) {
		SchedulerState schState = new SchedulerState() ;		
		if (SchedulerPanModel.panmodel.modelCheck()) {
			schState.results = SchedulerPanModel.panmodel.init_atomicf() ;
			schState.checked = SchedulerPanModel.panmodel.init_sf() ;
		} else {
			SchedulerPromelaModel.scheduler.initSchedulerState(schState, depth);
		}	
		schState.identifier = generatecode.stateid = identifier ;		
		schState.prunid = generatecode.pid = prunid ;
		schState.execid = generatecode.execid = execid ;
		
		if (depth==0) {
			startSchedulerState.next.add(schState) ;
			verifyStatesList.add(schState);
		}
		if (currentSchedulerState != null) { //= father
			currentSchedulerState.next.add(schState) ;
			currentSchedulerState.trans.add(stack.getLastTransition()) ;
			generatecode.stateid = currentSchedulerState.identifier; 
			GenerateCode code = generatecode.clone() ;
			code.pcnt.clear();
			code.pcnt.addAll(SchedulerPromelaModel.scheduler.pcnt);			
			currentSchedulerState.generatecodes.add(code);
		}
		schedulerstatehashmap.put(identifier, schState); 
		state_count ++ ;
		if (SchedulerPanModel.panmodel.stateCheck() || SchedulerPanModel.scheduler.stateCheck()) {
			verifyStatesList.add(schState);
		}		
	}
	
	public void execute() {		
		InitGraph() ; 
//		PrintGraph() ;
//		if (1 > 0) return ;
		if (Generate.getPropertyGenerateOption()) {
			if (SchedulerPanModel.panmodel.modelCheck() || SchedulerPromelaModel.scheduler.schedulerCheck()) {
				if (verifyStatesList.size() == 0) {
					System.out.println("No state to be verified");
				} else {
	//			PrintGraph() ;
	//			if (verifyStatesList.size() == 0 &&
	//				(SchedulerPanModel.panmodel.stateCheck() || SchedulerPanModel.scheduler.stateCheck()))
	//				verifyStatesList.add(startSchedulerState);
					if (!Config.processLimit) {
						LabelGraph() ;
	//					PrintGraph() ;
						visitedStates = new HashSet<SchedulerState>() ;
						trace = new ArrayList<Transition>() ;
						ArrayList<GenerateCode> gencodelist = new ArrayList<GenerateCode>() ;
						for (SchedulerState schedulerstate : verifyStatesList) {
							PrintTrace(schedulerstate.identifier, true,trace, gencodelist, schedulerstate, 0, formula.length - 1, formula.sn[0]);
						}
						
						SchedulerPromelaModel.scheduler.printAnalysisResult(Log.out);
					} else {
						Log.out.println(formula.toString() + " : Not determined") ;
						Log.out.println("Search incomplete") ;
						System.out.println("Search incomplete") ;
						System.out.println(formula.toString() + " : Not determined") ;
						Log.analysisresult = true ;
					}
				}
			} else {
				Util.print("Not found CTL formula");
			}
		}
//		flushOutputTest(model.getName());
//		flushOutputTest(SchedulerPanModel.scheduler.getSchedulerName());
		
		if (Generate.getNDBehaviorGenerateOption()) {
			//explore the graph
			//genTestFollowingNDBeahvior() ;
			
			ArrayList<ArrayList<SchedulerState>> executepaths = getExecutionPaths(verifyStatesList.get(0));
//			for (ArrayList<SchedulerState> path : executepaths){
//				for (SchedulerState s : path) {
//					System.out.println(s.identifier + ", runid: " + s.prunid);
//					System.out.println(s.generatecodes.get(0).gencode.code);
//				}
//				System.out.println("");
//			}
			
			ArrayList<ArrayList<GenerateCode>> genpaths = getGenerateCodePaths(verifyStatesList.get(0), 1, 0);
			int branchid = -1 ;
			boolean checked = false, replaced = false ;
			for (ArrayList<GenerateCode> path : genpaths){
				branchid = path.get(0).branchid;
				for (GenerateCode code : path) {
					code.gencode.code = code.gencode.code.replace("<StateID>", code.stateid + "") ;
					System.out.println(code.stateid + ", Exec : " + code.execid + ", Run : " + code.pid);
					System.out.println(code.gencode.code);
					
//					if (!replaced) {
//						if (code.branchid != branchid) checked = true ;
//						if (checked) {
//							if (code.gencode.code.contains("execute")) {
//								code.gencode.clearCode();
//								replaced = true ;
//								System.out.println("***** Replaced **********");
//								System.out.println(code.gencode.code);
//							}
//						}
//					}
				}
				
				System.out.println("---------------------");
				
				int top = path.size();			
				for (int i = 0 ; i < top ; i++) {
					codeArr[i] = path.get(i) ;
//					codeArr[i].gencode.code = codeArr[i].gencode.code.replace("getStep()", i + "") ; 
				}
				
				String testprogram = exportTestfromCodeArr(top, verifyStatesList.get(0).prunid) ;				
				if (testprogram == "" || testcase.containsKey(testprogram)) return ;		
//				testprogram = testprogram.replace("getTotalStep()", trace.size()+"");
				testcase.put(testprogram, trace) ;
				testprogramlist.add(testprogram);
			}
			
			//record the test code
			
			
			//genTestFollowingNDBehavior(verifyStatesList.get(0).runid, translist, gencodelist);
		}
		
		final File userDir = new File(System.getProperty("user.dir"));
		try{
			new File(userDir + "/" + Generate.getGenerateDirectory()).mkdir();
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
		//exportTestData();
		writeTest();
		freeMemory();
	}	
	
	private void addNewGenCode2CodeArr() {		
		int oldcodelisttop = codelisttop ;
		codelisttop = stack.top();				
		if (codeArr[codelisttop] == null)  {	//new gen code		
			generatecode = new GenerateCode() ;			
			codeArr[codelisttop] = generatecode ;
		} else {		
			generatecode = codeArr[codelisttop] ;
			generatecode.clearCode();
		}
		//System.out.println("Step = " + codelisttop + " code: " + generatecode.gencode.code);		
		 
				
		if (oldcodelisttop < codelisttop && oldcodelisttop >= 0) {
			generatecode.pcnt = (ArrayList<Byte>) codeArr[oldcodelisttop].getPcnt().clone() ; //copy pcnt
			SchedulerObject.setPcnt(generatecode.pcnt) ;
		} else {
			generatecode.pcnt.clear();
			generatecode.pcnt.addAll(SchedulerObject.getPcnt()) ;
		}
	}
	
	
	private void updateGenCode(String code, String part) {
		if (code == null) return ;
		generatecode.gencode.setcode(part, code);			
		generatecode.pcnt.clear();
		generatecode.pcnt.addAll(SchedulerObject.getPcnt()) ;
		Generate.out.clear();
	}
	
	//temp
	private void printGencode(GenerateCode code) {
		code.gencode.code = code.gencode.code.replace("<StateID>", code.stateid + "") ;
		System.out.println(code.stateid + ", Exec : " + code.execid + ", Run : " + code.pid);
		System.out.println(code.gencode.code);
	}
	
		
	private void InitGraph() {
		Util.print("Begin execute");
		Util.print(SchedulerPromelaModel.scheduler.getSchedulerName());
		Config.processInit = false ;		
		
		generatecode = new GenerateCode() ;		
		
		try {
			SchedulerPromelaModel.scheduler.init_order();
		} catch (final SpinJaException ex) {
			report(TRANS_ERROR, ex.getMessage());
		}
		updateGenCode(Generate.out.toString(), "new_process");
		
		startSchedulerState = new SchedulerState() ;
		startSchedulerState.generatecodes.add(generatecode.clone())	;
		
		initCode = generatecode.clone() ; //at first state		
		generatecode.clearCode();
		
		//select first process for execution
		try {
			SchedulerPromelaModel.scheduler.init() ;
			running_processID = SchedulerPromelaModel.scheduler.select_process(-1) ;				
		} catch (final SpinJaException ex) {
			report(TRANS_ERROR, ex.getMessage());
		}
		byte[] state  = storeModel();
		int identifier ;
		if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
			identifier = store.addState(state);
		} else {
			identifier = hash.hash(state, 0);			
			atomicSteps++;
		}
		if (!addState(state, identifier)) { //to stack
			throw new RuntimeException("Could not even add the first state.");
		}
		addNewGenCode2CodeArr();
		updateGenCode(Generate.out.toString(), "select_process");		
		
		int execid = getExecID();
		int prunid = getRunID() ;
		put_schedulerState(identifier, 0, prunid, execid, generatecode) ;		
		addRunningSetState();		
		
		Transition last = null ;
		Transition next = null;
		Transition clockTrans = new SchedulerTransition(0) ;
		Transition swcoreTrans = new SchedulerTransition(1) ;
		
		int lastschopt = 0 ;
		int nextschopt = 0 ;
		int livelockCount = 0 ;
		
		boolean startCheckLiveLock = false ;
		int cnt = 0 ;

		while ((nrErrors < maxErrors) && !Thread.currentThread().isInterrupted() && restoreState() && !Config.processLimit) {
			currentSchedulerState = stack.getTopIdentifer() < 0 ? null : schedulerstatehashmap.get(stack.getTopIdentifer()) ;
//		System.out.println(cnt++);
//		if (cnt == 1034)
//			System.out.println("Stop");
			boolean isTimer = SchedulerPromelaModel.scheduler.isTimer();
			if (outOfMemory) {				
				throw new OutOfMemoryError();
			}
		
			assert checkModelState();
		
			if (state.length > maxSize) {
				maxSize = state.length;
			}
					
			if (getDepth() - 1 > maxDepth) {
				maxDepth = getDepth() - 1;
			}
			
			
			last = stack.getLastTransition() ;
			lastschopt = stack.getLastSchOption();
			
			
			/*
			 * for each process
			 * 		for each sch_opt
			 * 			for each trans
			 */

			if (last == null) {// && lastschopt == 0) {	//new state
				nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
				next = nextTransition(last) ;				
			} else {				
				nextschopt = SchedulerPromelaModel.scheduler.nextSchedulerOption(lastschopt);
				if (nextschopt == -1) { //no more scheduler option	
					if (last == clockTrans || last == swcoreTrans)
						next = nextTransition(null) ;
					else {
						next = nextTransition(last) ;
						nextschopt = 0 ;
					}
				} else {
					next = last ;
				}
			}	
			
			//print
//			Util.print("**** Model: " + model);
//			SchedulerPromelaModel.scheduler.print_all();			
//			print_trace() ;
//			System.out.println("==> Last: " + last);
			System.out.println(cnt++ + "==> Next: " + next);
//			System.out.println(SchedulerPromelaModel.scheduler.pcnt);
//			System.out.println(generatecode.pcnt);
//			printGencode(generatecode);
			
			
			if (next == null)
				SchedulerPromelaModel.scheduler.setAction("null") ;
			else 
				SchedulerPromelaModel.scheduler.setAction(next.toString()) ;
			
			
			if (next == null) {			
				if (isTimer && last == null) {	//check last = clock action
					try {	
						if (nextschopt == 0 && lastschopt == 0) //new state
							nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
						
						SchedulerPromelaModel.scheduler.clock();
						stack.pushSchTrans(clockTrans);
						updateGenCode(Generate.out.toString(), "clock");
						
						Generate.out.clear();						
						if (SchedulerPromelaModel.scheduler.running_process == null) {							
							SchedulerPromelaModel.scheduler.select_process(-1);
							updateGenCode(Generate.out.toString(), "select_process");
						}
					} catch (ValidationException e) {
						Log.out.println(e.toString()) ;
						continue; //break ;
					}
					if (Config.isCheckLiveLock) if (!startCheckLiveLock) startCheckLiveLock = true ;
					if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {							
						state = storeModel() ;
						identifier = store.addState(state);		
						stack.pushSchOpt(nextschopt);
						
						Generate.setBehavior(generatecode);
						
						if (identifier < 0) { //visited state
							genTestFollowingSearch();
							add_exist_child_state(-(identifier + 1), next, generatecode);
							
							getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ; //if exist the identifier in stack
							if (cyclicSchedulerStateIDList.size() > 0)
								for (int id : cyclicSchedulerStateIDList)
									updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
							else 
								updateSchedulerState(-(identifier + 1),stack.top(),false, true);
							
							report(DUPLICATE_STATE.withState(state));
							nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
							statesMatched++;											
							if (startCheckLiveLock) { 
								if (SchedulerPromelaModel.scheduler.running_process != null) {
									report(LIVELOCK) ; //turn around
									livelockCount ++ ;
									if (!(nrErrors < maxErrors)) { //check all errors
										break ; //too many errors
									}							
								}
							} 
							//duplicate with no more scheduler option -> get other process?
							if (nextschopt == 0) {
								stateDone() ;
								execid = getExecID();
								prunid = getRunID() ;
							} else
								stack.pushSchOpt(nextschopt);							
							if (stack.getSize() == 1) { //???
								generatecode.clearCode();								
							}
						} else {							
							//add process state into stack & check the depth					
							if (!addState(state, identifier) ){	//identifier >0			
								if (errorExceedDepth) {
									report(EXCEED_DEPTH_ERROR);
								} else { 
									if (!printedDepthWarning) {
										report(EXCEED_DEPTH_WARNING);
										printedDepthWarning = true;
									}
								}
								undoTransition();		//change running process						
							}
							addNewGenCode2CodeArr();							
							put_schedulerState(identifier, stack.top() + 1, prunid, execid, generatecode) ; //new scheduler state
							execid = getExecID();
							prunid = getRunID() ;
						}
						continue ;
					}										
				} 				
				
				if (((last == null && !isTimer) ||(last == clockTrans)) &&
					SchedulerPromelaModel.scheduler.running_process != null){ //new state with deadlock
						report(DEADLOCK) ; //next = null
						Generate.setBehavior(generatecode);
						genTestFollowingError("Deadlock");
						try {
							outputTest("Deadlock", Log.out);
						} catch (IOException e) {
							e.printStackTrace();
						}
				} 

				generatecode = codeArr[stack.top()] ;
				generatecode.gencode.clearcode("select_process"); 
				if (getOtherProcessfromRunningSet()) { //get other process					
					updateGenCode(Generate.out.toString(), "select_process");	
					
					if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
						state = storeModel() ;
						identifier = store.addState(state);		
						stack.pushSchOpt(nextschopt);
						
						if (identifier < 0) {
							add_exist_child_state(-(identifier + 1), next, generatecode);
							getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ;
							if (cyclicSchedulerStateIDList.size() > 0)
								for (int id : cyclicSchedulerStateIDList)
									updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
							else 
								updateSchedulerState(-(identifier + 1),stack.top() - 1,false, true);
							
							report(DUPLICATE_STATE.withState(state));
							nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
							statesMatched++;
							genTestFollowingSearch(); 
							if (nextschopt == 0) {
								stateDone() ;
								execid = getExecID();
								prunid = getRunID() ;
							}
						} else {
							replaceState(state, identifier) ; //in the stack	
							execid = getExecID();
							prunid = getRunID() ;
							put_schedulerState(identifier, stack.top() + 1, prunid, execid, generatecode) ; //new scheduler state
							if (stack.top() == 0) {
								verifyStatesList.add(schedulerstatehashmap.get(identifier));
							}	
							continue;
						}
					}
				} else {					
					if (nextschopt <= 0) {
						stateDone() ;	
						execid = getExecID();
						prunid = getRunID() ;
					} else
						stack.pushSchOpt(nextschopt);
					continue ;
				}	
			} else  {
				try {
					//run ID before taking action?
					SchedulerPromelaModel.scheduler.preTake();
					updateGenCode(Generate.out.toString(), "pre_take");
					
					if (next.toString().contains("sch_exec_comp")) {
						SchedulerPromelaModel.scheduler.print_all();
					}
					
					if (nextschopt == 0)
						nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
					takeTransition(next);		
					
					
					updateGenCode( Generate.out.toString(), "scheduling_action");
					String takeaction = next.toString();
					takeaction = takeaction.substring(takeaction.indexOf(":")+1);					
					updateGenCode(takeaction,"process_action");					
					
					SchedulerPromelaModel.scheduler._runningSet.dataSet.clear(); 
					startCheckLiveLock = false ;
					SchedulerPromelaModel.scheduler.postTake();
					updateGenCode(Generate.out.toString(), "post_take");			
				} catch (SpinJaException e) {				
					updateGenCode(Generate.out.toString(),"new_process");
					String takeaction = next.toString();
					takeaction = "\t" + takeaction.substring(takeaction.indexOf(":")+1);					
					updateGenCode(takeaction,"process_action");
					try {
						SchedulerPromelaModel.scheduler.postTake();
					} catch (ValidationException er) {
						er.printStackTrace();
						report(TRANS_ERROR, er.getMessage());
					}
					updateGenCode(Generate.out.toString(), "post_take");
					
					e.printStackTrace();					
					report(TRANS_ERROR, e.getMessage());
					Generate.setBehavior(generatecode);
					genTestFollowingError(e.getMessage());
					try {
						outputTest(e.getMessage(), Log.out);
					} catch (IOException ex) {
						ex.printStackTrace();
					}
					continue ;
				}
				
				if (isTimer) {
					try {
						SchedulerPromelaModel.scheduler.clock();
						updateGenCode(Generate.out.toString(), "clock");
						if (SchedulerPromelaModel.scheduler.running_process == null) {
							SchedulerPromelaModel.scheduler.select_process(-1) ;
							updateGenCode(Generate.out.toString(), "select_process");							
						}
					} catch (ValidationException e) {
						e.printStackTrace();
						report(TRANS_ERROR, e.getMessage());
						Generate.setBehavior(generatecode);
						genTestFollowingError(e.getMessage());
						try {
							outputTest(e.getMessage(), Log.out);
						} catch (IOException ex) {
							ex.printStackTrace();
						}
						continue; //break ; -> don't stop
					}
				} else {				
					if (SchedulerPromelaModel.scheduler.running_process == null) {
						try {
							running_processID = SchedulerPromelaModel.scheduler.select_process(-1);
							updateGenCode(Generate.out.toString(), "select_process") ;							
						} catch (ValidationException e) {
							e.printStackTrace();
						}
					}
				}
		

				// If the state should be stored, try to store it
				if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
					state = storeModel() ;
					identifier = store.addState(state);
					stack.pushSchOpt(nextschopt);					
					Generate.setBehavior(generatecode);
					
					if (identifier < 0) {
						genTestFollowingSearch();
						add_exist_child_state(-(identifier + 1), next, generatecode);
						getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ; //if exist the identifier in stack
						if (cyclicSchedulerStateIDList.size() > 0)
							for (int id : cyclicSchedulerStateIDList)
								updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
						else 
							updateSchedulerState(-(identifier + 1),stack.top() - 1,false, true);
						
						nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
						statesMatched++;
						if ( Config.isCheckAcceptionCycle) { 				
							continue;
						}			
						
						undoTransition();
						continue;
					} else {											
						if ((store.getStored() & 0xfffff) == 0) {
						}
					}						
				} else { // otherwise count it
					atomicSteps++;
					identifier = hash.hash(state, 0);
				}
				put_schedulerState(identifier, stack.top() + 1,prunid, execid, generatecode) ; //new scheduler state
				execid = getExecID();
				prunid = getRunID() ;	
				
				if (!addState(state, identifier) ){			//identifier >0			
					if (errorExceedDepth) {
						report(EXCEED_DEPTH_ERROR);
					} else if (!printedDepthWarning) {
						report(EXCEED_DEPTH_WARNING);
						printedDepthWarning = true;
					}
					
					undoTransition();
					continue;
				}
				addNewGenCode2CodeArr();
				addRunningSetState();
			} //else next == null
		}		
	}
	
	private void genTestFollowingSearch() {
		if (Generate.getSearchingGenerateOption()) {			
//			System.out.println("Start genTestFollowingSearch  ##########################################");
//			print_trace();
//			System.out.println("End genTestFollowingSearch ##########################################");
			genTest("") ;
		}
	}
	private void genTestFollowingError(String errMsg) { 
		if (Generate.getErrorGenerateOption()) {
//			System.out.println("Start genTestFollowingError  ##########################################");
//			print_trace();
//			System.out.println("End genTestFollowingError ##########################################");
			
			genTest(errMsg) ;
		}
	}
//	int hitcount = 0 ;
	private void genTest(String errMsg){
		//visited states exported from stack
		if (codelisttop!=0) {	
			ArrayList<Transition> listtrans = stack.exportTrans() ;			
			Generate.setErrorMsg(errMsg);
			String processes = exportTestfromCodeArr(stack.top(),stack.identifiers[0]) ;
//			System.out.println("Hit count: " + (++hitcount));
			if (processes == "" || testcase.containsKey(processes)) return ;			
			processes = processes.replace("getTotalStep()", listtrans.size()+"");
			testcase.put(processes, listtrans) ;
			testprogramlist.add(processes);
		}
	}
	private void genTestFollowingProperty(int id, ArrayList<Transition> trace, ArrayList<GenerateCode> gencodelist) { //states from searching trace
		if (trace.size()==0) return ;
		if (Generate.getPropertyGenerateOption()) {		
			//record the test code
			int top = trace.size();			
			for (int i = 0 ; i < top ; i++) {
				codeArr[i] = gencodelist.get(i) ;
			}
			
			String testprogram = exportTestfromCodeArr(top - 1, id) ;				
			if (testprogram == "" || testcase.containsKey(testprogram)) return ;		
			testprogram = testprogram.replace("getTotalStep()", trace.size()+"");
			testcase.put(testprogram, trace) ;
			testprogramlist.add(testprogram);
		}
	}
	
//	private void genTestFollowingNDBehavior(int depth, boolean ndBehavior, boolean storetrace, 
//			SchedulerState schedulerstate, 
//			ArrayList<SchedulerState> statelist, HashSet<SchedulerState> statestore,
//			ArrayList<Transition> translist, ArrayList<GenerateCode> gencodelist) {
//				
//		int index = 0 ;
//		SchedulerState nextstate ;
//		GenerateCode gencode ;
//		
//		statestore.add(schedulerstate);
//		statelist.add(schedulerstate);
//		
//		if (schedulerstate.ndpoint && schedulerstate.next.size()>1) {
//			//non-deterministic behavior
//			for (Transition trans : schedulerstate.trans) {
//				nextstate = schedulerstate.next.get(index);
//				
//				if (!statestore.contains(nextstate)) {
//					translist.add(trans);
//					gencode = schedulerstate.generatecodes.get(index);
//					Generate.setNDBehavior(gencode);
////					gencode.gencode.code = '{' + gencode.gencode.code ;
////					gencode.gencode.code = gencode.gencode.code.replace("getStep()", depth + "");
//					gencodelist.add(gencode);		
//					if (gencode.pid <0 || gencode.pid == 255)
//					//store trace for each nd behavior
//						genTestFollowingNDBehavior(depth, true, true, nextstate, statelist, statestore, translist, gencodelist);
//					else
//						genTestFollowingNDBehavior(depth + 1, true, true, nextstate, statelist, statestore, translist, gencodelist);
//					gencodelist.get(gencodelist.size()-1).gencode.code += '}' ; 
//				}
//				index++;
//			}
//			genTestFollowingNDBehavior(verifyStatesList.get(0).prunid, translist, gencodelist);			
//		} else {
//			if (schedulerstate.next.size() > 0) {
//				for (Transition trans : schedulerstate.trans) {					
//					nextstate = schedulerstate.next.get(index);
//					
//					if (!statestore.contains(nextstate)) { //not NDpoint
//						translist.add(trans);											
//						gencode = schedulerstate.generatecodes.get(index);						
////						gencode.gencode.code = gencode.gencode.code.replace("getStep()", depth + "");
////						gencode.gencode.code = '{' + gencode.gencode.code ;
//						gencodelist.add(gencode);
//						if (gencode.pid <0 || gencode.pid == 255)
//							genTestFollowingNDBehavior(depth,ndBehavior, storetrace, nextstate, statelist, statestore, translist, gencodelist);
//						else
//							genTestFollowingNDBehavior(depth + 1,ndBehavior, storetrace, nextstate, statelist, statestore, translist, gencodelist);
////						gencodelist.get(gencodelist.size()-1).gencode.code += '}' ;
//						if (!storetrace) {
//							translist.remove(translist.size()-1);				
//							gencodelist.remove(gencodelist.size()-1);
//						}
//					} else {
//						genTestFollowingNDBehavior(verifyStatesList.get(0).prunid, translist, gencodelist);
//					}
//					index++;
//				}
//			} else {
//				
//			}
//		}
//	}
//	
	private ArrayList<ArrayList<GenerateCode>> getGenerateCodePaths(SchedulerState state, int branchID, int step) {
		ArrayList<ArrayList<GenerateCode>> result = new ArrayList<ArrayList<GenerateCode>>();
		ArrayList<GenerateCode> newpath;
		ArrayList<ArrayList<GenerateCode>> executionpaths ;
		GenerateCode gencode ;
		int nextsize = state.next.size();
				
		if (nextsize != 0) {
			if (nextsize == 1) {				
				SchedulerState nextstate = state.next.get(0) ;
//				if (state.generatecodes.get(0).pid < 0 || state.generatecodes.get(0).execid == 255)
//					executionpaths = getGenerateCodePaths(nextstate, branchID, step) ;
//				else
					executionpaths = getGenerateCodePaths(nextstate, branchID, step+1) ;
				for (ArrayList<GenerateCode> path : executionpaths) {
					newpath = new ArrayList<GenerateCode>();
					gencode = state.generatecodes.get(0);
//					System.out.println(gencode.stateid);
					gencode.branchid = branchID ;
					gencode.gencode.code = gencode.gencode.code
							.replace("<BranchID>" , branchID + "") ;
//							.replace("getStep()", step+"");
					newpath.add(gencode);
					newpath.addAll(path);															
					result.add(newpath) ;					
				}
			} else {
				int index = 0 ;
				if (state.ndpoint) {	
					ArrayList<ArrayList<GenerateCode>> pathset = new ArrayList<ArrayList<GenerateCode>>();
					ArrayList<ArrayList<GenerateCode>> newpathset = new ArrayList<ArrayList<GenerateCode>>();
					
					for (GenerateCode code : state.generatecodes) {
						Generate.setNDBehavior(code);
						code.branchid = branchID ;
						code.gencode.code = '{' + code.gencode.code ;
					}
					//int branchsize = state.next.size() ;
					
					int bid = -1 ;
					for (SchedulerState nextstate : state.next) {
						bid++;
//						if (state.generatecodes.get(0).pid < 0 || state.generatecodes.get(0).execid == 255)
//							executionpaths = getGenerateCodePaths(nextstate, branchID * num + bid, step) ;
//						else
							executionpaths = getGenerateCodePaths(nextstate, branchID * 10 + bid, step + 1) ;
//						executionpaths = getGenerateCodePaths(nextstate, step + 1) ;
						for (ArrayList<GenerateCode> oldpath : executionpaths) {
							ArrayList<GenerateCode> temppath = new ArrayList<GenerateCode>() ;
							newpath = new ArrayList<GenerateCode>();
//							newpath.add(state);							
							newpath.addAll(oldpath);
							
							if (index==0){
								gencode = state.generatecodes.get(0);
								gencode.gencode.code = gencode.gencode.code
//										.replace("getStep()", step+"")
										.replace("<BranchID>", branchID * 10 + bid+"");
								temppath.add(gencode);
								temppath.addAll(newpath);
								temppath.get(temppath.size()-1).gencode.code = temppath.get(temppath.size()-1).gencode.code + '}' ;
								pathset.add(temppath);
							} else { //other paths
								for (ArrayList<GenerateCode> path : pathset) {
									temppath.addAll(path);
									gencode = state.generatecodes.get(index);
									gencode.gencode.code = '|' + gencode.gencode.code
//											.replace("getStep()", step+"")
											.replace("<BranchID>", branchID * 10 + bid+"");
									temppath.add(gencode);																		
									temppath.addAll(newpath);
									newpathset.add(temppath) ;
								}								
							}
						}
						index++;
					}
					result.addAll(newpathset);
				} else {// not nd point
					for (SchedulerState nextstate : state.next) {
//						if (state.generatecodes.get(0).pid < 0 || state.generatecodes.get(0).execid == 255)
//							executionpaths = getGenerateCodePaths(nextstate, branchID, step) ;
//						else
							executionpaths = getGenerateCodePaths(nextstate, branchID, step + 1) ;
//						executionpaths = getGenerateCodePaths(nextstate, step + 1) ;
						for (ArrayList<GenerateCode> codelist : executionpaths) {
							newpath = new ArrayList<GenerateCode>();
							gencode = state.generatecodes.get(index);
							gencode.branchid = branchID ;
							gencode.gencode.code = gencode.gencode.code
//									.replace("getStep()", step+"")
									.replace("<BranchID>", branchID +"");;
							newpath.add(gencode);							
							newpath.addAll(codelist);
							result.add(newpath) ;
						}
						index++;
					}
				}
			}
		} else {
			result.add(new ArrayList<GenerateCode>());
		}
		return result ; //result contains all execution paths at state "state"
	}
	private ArrayList<ArrayList<SchedulerState>> getExecutionPaths(SchedulerState state) {
		ArrayList<ArrayList<SchedulerState>> result = new ArrayList<ArrayList<SchedulerState>>();
		ArrayList<SchedulerState> newpath;
		ArrayList<ArrayList<SchedulerState>> executionpaths ;
		int nextsize = state.next.size();
				
		if (nextsize != 0) {
			if (nextsize == 1) {				
				SchedulerState nextstate = state.next.get(0) ;
				executionpaths = getExecutionPaths(nextstate) ;
				for (ArrayList<SchedulerState> path : executionpaths) {
					newpath = new ArrayList<SchedulerState>();
					newpath.add(state);
					newpath.addAll(path);					
					result.add(newpath) ;					
				}
			} else {
				int index = 0 ;
				if (state.ndpoint) {	
					ArrayList<ArrayList<SchedulerState>> pathset = new ArrayList<ArrayList<SchedulerState>>();
					ArrayList<ArrayList<SchedulerState>> newpathset = new ArrayList<ArrayList<SchedulerState>>();
					
					for (SchedulerState nextstate : state.next) {
						executionpaths = getExecutionPaths(nextstate) ;
						for (ArrayList<SchedulerState> oldpath : executionpaths) {
							newpath = new ArrayList<SchedulerState>();
//							newpath.add(state);							
							newpath.addAll(oldpath);
							
							if (index==0)
								pathset.add(newpath);
							else { //other paths
								for (ArrayList<SchedulerState> path : pathset) {
									ArrayList<SchedulerState> temppath = new ArrayList<SchedulerState>() ;
									temppath.add(state);
									temppath.addAll(path);
									temppath.addAll(newpath);
									newpathset.add(temppath) ;
								}								
							}
						}
						index++;
					}
					result.addAll(newpathset);
				} else {// not nd point
					for (SchedulerState nextstate : state.next) {
						executionpaths = getExecutionPaths(nextstate) ;
						for (ArrayList<SchedulerState> codelist : executionpaths) {
							newpath = new ArrayList<SchedulerState>();
							newpath.add(state);							
							newpath.addAll(codelist);
							result.add(newpath) ;
						}
						index++;
					}
				}
			}
		} else {
			result.add(new ArrayList<SchedulerState>());
		}
		return result ; //result contains all execution paths at state "state"
	}
	
//	private void genTestFollowingNDBeahvior(){
//		SchedulerState schedulerstate = verifyStatesList.get(0);
//		ArrayList<SchedulerState> statelist = new ArrayList<SchedulerState>() ;
//		ArrayList<Transition> translist = new ArrayList<Transition>() ;
//		ArrayList<GenerateCode> gencodelist = new ArrayList<GenerateCode>() ;
//		HashSet<SchedulerState> statestore = new HashSet<SchedulerState>() ; //to check visited states
//		
//		genTestFollowingNDBehavior(0,schedulerstate.ndpoint, true, schedulerstate, statelist,statestore, translist, gencodelist);
//
///*
//		ArrayList<SchedulerState> statelist = new ArrayList<SchedulerState> () ;
//		ArrayList<Integer> transidlist = new ArrayList<Integer> () ;
//		
//		HashSet<SchedulerState> statestore = new HashSet<SchedulerState>() ;
//		ArrayList<Integer> NDPoints = new ArrayList<Integer>() ;
//		ArrayList<Integer> NDCheckPoints = new ArrayList<Integer>() ;
//		
//		statelist.add(verifyStatesList.get(0));
//		statestore.add(verifyStatesList.get(0));
//		transidlist.add(-1) ;
//		int top = 0;
//		
//		int transid, transsize;
//		SchedulerState state, nextstate;
//		GenerateCode gencode ;
//		int lastNDPoint = -1 ;
//		
//		while (!statelist.isEmpty()) {
//			state = statelist.get(top) ;
//			transid = transidlist.get(top) ;
//			transsize = state.trans.size() ;
//						
//			if (transid < transsize -1) {
//				transid++;
//				transidlist.set(top, transid) ;
//				translist.add(state.trans.get(transid));
//				
//				gencode = state.generatecodes.get(transid);				
//				if (transsize > 1) {
//					if (gencode.ndpoint) {
//						//check non-deterministic behavior
//						Generate.setNDBehavior(gencode);
//						NDCheckPoints.add(top) ;
//					}
//					NDPoints.add(top) ;
//				} 
//
//				gencode.gencode.code = gencode.gencode.code.replace("getStep()", top+1+"");				
//				gencodelist.add(gencode);
//				nextstate = state.next.get(transid) ;
//				
//				if (statestore.contains(nextstate)) {
//					//duplicate, backtrack
//					for (GenerateCode code : gencodelist)
//						code.gencode.code = code.gencode.code.replace("getTotalStep()", top+"");
//					statelist.remove(top);
//					transidlist.remove(top);
//					top--;
//				} else {
//					statelist.add(nextstate) ;
//					transidlist.add(-1) ;
//					top++;
//				}
//			} else { //backtrack
//				if (NDCheckPoints.size()>0) {
//					if (NDPoints.size() > 0) {
//						lastNDPoint = NDPoints.remove(NDPoints.size()-1) ;
//						if (NDCheckPoints.contains(lastNDPoint)) {
//							NDCheckPoints.remove(lastNDPoint);
//						}
//						for (GenerateCode code : gencodelist) {
//							code.gencode.code = code.gencode.code.replace("getTotalStep()", top+"");
//						}
//						while (top > lastNDPoint) {
//							statelist.remove(top);
//							transidlist.remove(top);
////							gencodelist.remove(gencodelist.size()-1);
////							translist.remove(translist.size()-1);
//							top--;
//						}
//					} 	
//				} else {
////					gencodelist.clear();
//					break ;
//				}
//			}
//		}
//		if (gencodelist.size()>0)
//			genTestFollowingNDBehavior(verifyStatesList.get(0).runid, translist, gencodelist);
//*/
//	}
	
	private void genTestFollowingNDBehavior(int id, ArrayList<Transition> trace, ArrayList<GenerateCode> gencodelist) { //states from searching trace
		if (trace.size()==0) return ;
		if (Generate.getNDBehaviorGenerateOption()) {		
			//record the test code
			int top = trace.size();			
			for (int i = 0 ; i < top ; i++) {
				codeArr[i] = gencodelist.get(i) ;
//				codeArr[i].gencode.code  =  codeArr[i].gencode.code.replace("getStep()", i + "") ;
			}
			
			String testprogram = exportTestfromCodeArr(top, id) ;				
			if (testprogram == "" || testcase.containsKey(testprogram)) return ;		
//			testprogram = testprogram.replace("getTotalStep()", trace.size()+"");
			testcase.put(testprogram, trace) ;
			testprogramlist.add(testprogram);
		}
	}
	
	private String exportTestfromCodeArr(int top, int firststateID) {
		int codeTempSize = Generate.getTemplateSize() ;
		int codeCompSize = Generate.getCompSize() ;	
		
		if (codeTempSize < 0) return null ;
		String codeComp[] = new String[codeTempSize];
		
		//combine with starting state
		if (initCode != null) {
			for (int j=0; j < codeCompSize; j++) {
				if (initCode.gencode.component[j] != null) {
					codeComp[j] = initCode.gencode.component[j]
								.replace("getStep()", 0 + "")
								.replace("getTotalStep()", top + "") ;
				}
			}
		}
		
		//combine with initial component
		for (int j=0; j < codeCompSize; j++) {
			if (Generate.component[j] != null) {
				codeComp[j] += Generate.component[j] ;
			}
		}
				
		//init the process instance		
		int pid, pinstance, assigncnt ;		
		assigncnt = 1 ;
		for (int i = 0 ; i < top ; i++) 			
			codeArr[i].pinstance = 0 ;
		
		//initialize the process instance		
		for (int i = 0 ; i <= top ; i++) {	
			if (codeArr[i] == null) 
				continue ;
			if (codeArr[i].pinstance == 0) {
				assigncnt = 1;
				codeArr[i].pinstance = assigncnt;
			} else {
				assigncnt = codeArr[i].pinstance;
			}
						
			pid = codeArr[i].pid;			
			if (pid < 0 || pid == 255) continue ; //Ignore scheduler & sporadic task with pid=255
			if (pid < codeArr[i].pcnt.size()) { 
				pinstance = codeArr[i].pcnt.get(pid);
				for (int j = i+1 ; j <= top ; j++) {
					if (codeArr[j] == null) 
						continue ;
					if (codeArr[j].pid == pid) {						
						if(codeArr[j].pcnt.get(pid) > pinstance)					
							codeArr[j].pinstance = ++assigncnt;
						else 
							codeArr[j].pinstance = assigncnt;
					}
				}
			}
		}	

		//counting the process having actions
		ArrayList<Byte> pinstance_count = new ArrayList<Byte>() ;
		if (Generate.isGenTestProgram()) {
			for (int i=0; i<top; i++) {	
				if (codeArr[i] == null) 
					continue ;
				if (codeArr[i].pid == -1 || codeArr[i].pid == 255) 
					continue ;
				for (int j=pinstance_count.size(); j <= codeArr[i].pcnt.size() ; j++) {
					pinstance_count.add((byte) 0) ; //set cnt = 0 first
				}
				if (pinstance_count.get(codeArr[i].pid) < codeArr[i].pinstance) 
					pinstance_count.set(codeArr[i].pid, (byte) codeArr[i].pinstance) ;
			}
		}
		
		//replace pid, pinstance and pname
		for (int i = 0 ; i < top ; i++) {
			if (codeArr[i] != null) {
				if (codeArr[i].pid != -1) { 
					codeArr[i].gencode.code =
						codeArr[i].gencode.code
		//					.replace("getStep()", i + 1 + "")
		//					.replace("getTotalStep()", top + 1 + "")
							.replace("<PID>", codeArr[i].pid + "")
							.replace("<InstanceID>", codeArr[i].pinstance + "")	;
					if (codeArr[i].pid==255)
						codeArr[i].gencode.code = 
							codeArr[i].gencode.code.replace("<PName>", "scheduler_sporadic") ;
					else
						codeArr[i].gencode.code = 
							codeArr[i].gencode.code.replace("<PName>", SchedulerPanModel.scheduler.processList.get(codeArr[i].pid)) ;
				}
			}
		}
		
		//test generation
		String testgeneration = "" ;
		String codebehavior= "";
		
		if (Generate.isGenTestCase() || Generate.isGenTestData()) {
			//export test case & test data
			for (int i = 0 ; i < top ; i++) {
				codebehavior += codeArr[i].gencode.code
						.replace("getStep()", i+1+"")
						.replace("getTotalStep()", top +  "")
						;
				//collect code component
				for (int j=0; j < codeCompSize; j++) {
					if (codeComp[j] != null) {
						codeComp[j] += codeArr[i].gencode.component[j]
								.replace("getStep()", i+1+"")
								.replace("getTotalStep()", top + 1+"") 
								;
					} else {
						codeComp[j] = codeArr[i].gencode.component[j]
								.replace("getStep()", i+1+"")
								.replace("getTotalStep()", top + 1 + "") 
								;				
					}
				}
			}			
		} else {
			//export test program
			ArrayList<String> codeList = new ArrayList<String>() ;
			for (int i = 0 ; i <= top ; i++) {
				if (codeArr[i] == null || codeArr[i].pid < 0) {
					codeList.add("") ;
				} else {
					//collect behaviors
					codeList.add(codeArr[i].gencode.code
							.replace("getStep()", i+1+"")
							.replace("getTotalStep()", top + 1 + "")
							)	;
					//collect code component
					for (int j=0; j < codeCompSize; j++) {
						if (codeComp[j] != null) {
							codeComp[j] += codeArr[i].gencode.component[j]
									.replace("getStep()", i+1+"")
									.replace("getTotalStep()", top + 1+"") 
									;
						} else {
							codeComp[j] = codeArr[i].gencode.component[j]
									.replace("getStep()", i+1+"")
									.replace("getTotalStep()", top + 1 + "") 
									;				
						}
					}
				}
			}
			String actionList = "" ;
			
			//generate the processes
			boolean checked [] = new boolean[top+1];		
			for (int i = 0 ; i < top ; i++) {		
				if (checked[i] || codeArr[i] == null) continue;
				checked[i] = true ;
				pid = codeArr[i].pid;			
				
				if (pid < 0 || pid == 255) continue ; //Ignore scheduler tasks
				pinstance = codeArr[i].pinstance;	
				actionList = codeList.get(i);
				
				for (int j=i+1; j<=top; j++) {	
					if (checked[j] || codeArr[j] == null) continue;
					System.out.println(j);
					if (j== 35)
						System.out.println("stop");
					if (codeArr[j].pid == pid && codeArr[j].pinstance == pinstance) { //same process
						actionList += codeList.get(j);
						checked[j] = true;
					}
				}
				codebehavior += Generate.generateProcess(pid, pinstance, SchedulerPanModel.scheduler.processList.get(pid), actionList);
			}
			
			if (Generate.isGenTestProgram()) {
				//insert empty process (no behavior)
				//last state performs no action (use top - 1)
				int idcnt ;
				if (codeArr[top] != null) 
					idcnt = codeArr[top].getPcnt().size();
				else
					idcnt = codeArr[--top].getPcnt().size();
				for (int id = 0 ; id < idcnt ; id++) {
					if (id < pinstance_count.size()) { // && id < codeArr[top].getPcnt().size()) {
						for (int ins = pinstance_count.get(id); ins < codeArr[top].getPcnt().get(id); ins++) {
							codebehavior += Generate.generateProcess(id, ins + 1, SchedulerPanModel.scheduler.processList.get(id), "");
						}
					} else {
						for (int ins = 0; ins < codeArr[top].getPcnt().get(id); ins++) {
							codebehavior += Generate.generateProcess(id, ins + 1, SchedulerPanModel.scheduler.processList.get(id),"");
						}
					}
				}
			}
		}
		
		//create test			
		int index = 0 ;
		int errorposition = Generate.getErrorPosition() ;
		int actioncodeposition = Generate.getActionsPosition();
		
		for (int i=0; i<codeTempSize; i++) {
			testgeneration = testgeneration + Generate.tempParts[i][0]; //prefix
			
			if (i == actioncodeposition) { //test code
				testgeneration += codebehavior ;
			} else {
				if (i == errorposition) {
					testgeneration +=  Generate.errorMsg ;
				} else {
					testgeneration += Generate.generateComponent(codeComp[index++], i) ;
				}
			}
			testgeneration+= Generate.tempParts[i][1] ; //posfix			
		}
		return testgeneration;
	}
/*		
	private String stack_exportTestCase() {   
		if (codelisttop==0)	return "";
		
		//re-index the process instance
		int top = stack.top() ;
		
		
		int pid, pinstance, assigncnt ;
		
		assigncnt = 1 ;
		for (int i = 0 ; i < top ; i++) {
			if (codeArr[i].pinstance == 0) {
				assigncnt = 1;
				codeArr[i].pinstance = assigncnt;
			} else {
				assigncnt = codeArr[i].pinstance;
			}
			
			
			pid = codeArr[i].pid;			
			if (pid < 0) continue ;
			pinstance = codeArr[i].pcnt.get(pid);
			for (int j = i+1 ; j <= top ; j++) {				
				if (codeArr[j].pid == pid) {
					if(codeArr[j].pcnt.get(pid) > pinstance)					
						codeArr[j].pinstance = ++assigncnt;
					else 
						codeArr[j].pinstance = assigncnt;
				}
			}
		}
		
		
		
		//export test case
		String result = "";
		String actionList = "" ;
		
		//for (int i = 0 ; i <= codelisttop ; i++) {		
		GenerateCode gcode ;		
		boolean checked [] = new boolean[top+1];
		
		for (int i = 0 ; i < top ; i++) {
			//gcode = codelist.get(i);
			if (checked[i]) continue;
			checked[i] = true ;
			
			gcode = codeArr[i];
			pid = gcode.pid;			
			
			if (pid < 0) continue ;
			pinstance = gcode.pinstance;
			
			actionList =  gcode.gencode.code;
			
			for (int j=i+1; j<=top; j++) {	
				if (checked[j]) continue;
				gcode = codeArr[j];
				if (gcode.pid == pid && gcode.pinstance == pinstance) { //same process				
					actionList +=  gcode.gencode.code;
					checked[j] = true;
				}
			}
			result += SchedulerPanModel.scheduler.generateProcess(pid, pinstance, actionList) + "\n";
		}		
		
		return result;
	}
*/
	
	private int count(String text, String find) {
        int index = 0, count = 0, length = find.length();
        while( (index = text.indexOf(find, index)) != -1 ) {                
                index += length; count++;
        }
        return count;
	}
	
	protected void exportTestData() {
		int testcnt = 0 ;
//			int totalOrder = 0 ;
		for (String testprogram : testprogramlist) { //testcase.keySet()) {
			PrintWriter out  ;
			//System.out.println(testprogram);
			String filename = "testgenerate/" + SchedulerPanModel.scheduler.getSchedulerName() + "_" + testcnt++;
			try {
				out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".in")));
				int num = count(testprogram, "TAKE") ;
				String pcode = testprogram ;
														
				pcode = pcode.replace("TAKE_NEWP", "1");
				pcode = pcode.replace("TAKE_NEWQ", "2");
				pcode = pcode.replace("TAKE_END", "3");
				pcode = pcode.replace("TAKE_", "0");					
				pcode += " 4" ; //FINISH
				
				//out.append(Gen.header  + num + "\n" + pcode + "\n" + testprogram + " FINISH") ;
				out.append(num + "\n" + pcode + "\n" + testprogram + " FINISH") ;
				out.flush();
				out.close();
				System.out.println("------------------");
				System.out.println("sspinja: wrote testcase to " + filename);
//					Log.out.printf("sspinja: wrote testcase to " + filename);
//					System.out.println(pcode) ;
//					System.out.println(num + " : " + testprogram);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
//				try {
//					out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".out")));
//					executionTrans = testcase.get(testprogram);
////					int i = 0 ;
////					for (Transition t : executionTrans) 
////						System.out.println((i++) + t.toString());
////					System.out.println("------------------");
//										
////					if (testcnt == 9)
////						System.out.print("Stop to view");
//					
//					String tp = testprogram ;
//					
//					int index = 0 ;
//					actlist.clear();
//					while (index != -1) {
//						index = tp.indexOf(" TAKE_") ;
//						tp = tp.substring(index + 1) ;
//						index = tp.indexOf(" TAKE_") ;
//						if (index != -1)
//							actlist.add(tp.substring(0, index)) ;
//						else
//							actlist.add(tp) ;												
//					}
//					
////					executionOrder.clear();
//					realExec.clear();
//					for (SchedulerState stSchedulerState : verifyStatesList) {
//						order.clear(); //used as stack
//						//getExecutionOrder(stSchedulerState, 0, executionTrans.size());
//						getExecutionOrder(stSchedulerState,executionTrans);
//					}					
//					
//					HashSet<String> order = new HashSet<String>() ;
//					String pOrder ;
//					for (ArrayList<Integer> exec : realExec) {
//						//System.out.println(exec);						
//						pOrder = resetProcessID(exec) ;
//						//System.out.println(pOrder);
//						order.add(pOrder);						
//					}
//					for (String exec : order)
//						out.append(exec + "\n") ;
//					out.flush();
//					out.close();	
//					totalOrder += order.size();
//					System.out.println("sspinja: wrote test output to " + filename + ", number of execution order: " + order.size());
//					Log.out.printf("sspinja: wrote test output to " + filename + ", number of execution order: " + order.size() + "\n");
//				} catch (IOException e) {
//					e.printStackTrace();
//				}				
		}
		//Log.out.printf("total running order: " + totalOrder + "\n");
	}
	
	ArrayList<String> actlist = new ArrayList<String>() ;	
//	ArrayList<String> executionOrder = new ArrayList<String>() ;
	ArrayList<ArrayList<Integer>> realExec = new ArrayList<ArrayList<Integer>>() ;
	
	ArrayList<Transition> executionTrans  = new ArrayList<Transition>() ;
	ArrayList<Integer> order = new ArrayList<Integer>();
	
	private void addExecutionOrder(ArrayList<Integer> newExec){
		//only add the different execution
		ArrayList<Integer> oldExec ;
		
		if (realExec.size()==0) {
			realExec.add((ArrayList<Integer>) newExec.clone()) ;			
		}	else {
			boolean diff = true ; //newExec differ from all of realExec
			boolean perdiff ;			
			for (int i = 0; i < realExec.size() ; i++) {
				oldExec = realExec.get(i);
				if (newExec.size() != oldExec.size()) continue ;
				perdiff = false ;
				 
				for (int j = 0 ; j < oldExec.size(); j++) {					
					if (newExec.get(j) != oldExec.get(j)) {
						perdiff = true ;
						break ;
					} 
				}
				if (!perdiff) {
					diff = false ;
					break ;
				}
			}
			if (diff)
				realExec.add((ArrayList<Integer>) newExec.clone()) ;
		}		
	}
	
	private void getExecutionOrder(SchedulerState state, ArrayList<Transition> executionTrans){
		ArrayList<SchedulerState> listState = new ArrayList<SchedulerState> () ;
		ArrayList<Integer> listID = new ArrayList<Integer>() ;
		ArrayList<Integer> listtransID = new ArrayList<Integer>() ;
		
		
		int total = executionTrans.size();
		int tstep = 0 ;
		int transid = 0 ;		
					
		Transition execnext ;
		Transition curtrans = null ;
		int transize ;
		
		String s_curtrans, s_execnext;
//		int k = 0 ;
//		for (Transition t : executionTrans) 
//			System.out.println((k++) + t.toString());
//		System.out.println("------------------");
		
		boolean foundtrans;		
		while (true) {
			//exploring the graph?
			if (tstep == total) {
				for(int i = 0 ; i < total;i++) {
					order.add(listID.get(i)) ;
				}				
				addExecutionOrder(order) ;
				//System.out.println("Add: " + order);
				order.clear();
				tstep--;				
				if (tstep < 0)
					break ;
				else
					state = listState.get(tstep);
			} else {
				if (listState.size() < tstep + 1) {
					listState.add(state) ;
					listID.add(state.runinstance) ;
				}
				execnext = executionTrans.get(tstep) ; //tstep same as top of the stack?
				
				if (listtransID.size() <= tstep) {
					transid = 0 ;
					foundtrans = false ; //start with the beginning transition
				} else {
					transid = listtransID.get(tstep) + 1;
					foundtrans = true ; //already found a suitable transition
				}
				transize = state.trans.size() ;
				
				s_execnext = execnext.toString().trim() ;
				s_execnext = s_execnext.substring(s_execnext.indexOf("):")) ;
				
				while (transid < transize){
					curtrans = state.trans.get(transid) ;
					if (curtrans == null) 
						break ; //can not find suitable transition
					//if(curtrans.getId() != execnext.getId())
					s_curtrans = curtrans.toString().trim() ;
					s_curtrans = s_curtrans.substring(s_curtrans.indexOf("):")) ;
					
					//System.out.println(s_curtrans + " ? " + s_execnext);
					if(!s_curtrans.equals(s_execnext))
						transid++;
					else {
						foundtrans = true ;
						break ; //found suitable transition
					}
				}
				
				if (!foundtrans) {
					//System.out.println("Can not find suitable transition");
					//record the steps until the current one
					for(int i = 0 ; i < tstep;i++) {
						order.add(listID.get(i)) ;
					}			
					if (order.size() > 0) {
						addExecutionOrder(order) ;
						//System.out.println("Add: " + order + " partial");
						order.clear();
					}
//					tstep--;				
//					if (tstep < 0)
//						break ; //finish
//					else
//						state = listState.get(tstep);
					
					listState.remove(tstep) ;
					if (listtransID.size() > tstep )
						listtransID.remove(tstep) ;
					
					listID.remove(tstep);
					tstep-- ;
					if (tstep < 0) break ; 
					else state = listState.get(tstep) ;
				} else {				
					if (transid == transize) {
						//search all transitions done
						listState.remove(tstep) ;
						if (listtransID.size() > tstep )
							listtransID.remove(tstep) ;
						
						listID.remove(tstep);
						tstep-- ;
						if (tstep < 0) break ;
						else state = listState.get(tstep) ;
					} else {
						//found transition
						if (listtransID.size() < tstep + 1) {
							listtransID.add(transid) ; //addnew
						} else {
							listtransID.set(tstep, transid) ; //replace
						}
						if (transid < state.next.size() ) { 
							state = state.next.get(transid) ;
						}
						tstep++ ;
						//else tstep--;
					}	
				}
			}
		}
	}
	
	protected void getExecutionOrder( SchedulerState state, int num, int total) {
		if (num == total) {
			addExecutionOrder(order) ;
			
//			String pOrder = resetProcessID(order) ;
//			//String pOrder = order ;
//			if (!executionOrder.contains(pOrder)) {
//				executionOrder.add(pOrder) ;
//				System.out.println(pOrder);
//			}
		} else {
			Transition t = executionTrans.get(num) ;
		
			int index = 0 ;
			for (Transition tr : state.trans) {
				if (tr != null) {
					if (checkTrans(tr, t)) {	
						SchedulerState next = state.next.get(index) ;
						order.add(state.runinstance) ;
						getExecutionOrder(next,num+1,total) ;
						order.remove(order.size()-1) ;
						//order.remove(state.runinstance) ;
					}
				}
				index++;
			}
		}			
	}
	
	int pinstance [] = new int [128] ;
	private String resetProcessID(ArrayList<Integer> order) {		
		String result = "" ;
		
		for (int i = 0 ; i < 128 ; i ++) pinstance[i] = -2 ;
		
//		ArrayList<Integer> pidlist = new ArrayList<Integer>() ;
		//int index = order.indexOf(" ") ;
		
		//System.out.println("Actlist: " + actlist);
		
//		String tp = order ;		
//		int pid ;
//		while (index != -1) {
//			pid = Integer.parseInt(tp.substring(0, index)) ;
//			//if (pid > max) max = pid;
//			pidlist.add(pid) ;
//			tp = tp.substring(index + 1) ;
//			index = tp.indexOf(" ") ;
//		}
		
		for (int i = 0; i < SchedulerPanModel.scheduler.get_init_process_count(); i++)
			pinstance[order.get(i)] = order.get(i);
		//pinstance[order.get(1)] = order.get(1); //for 2nd process at starting time
			
		int instance = 0 ;		
		int pid ;		
		for (int i = 0 ; i < order.size(); i ++) {
			String act = actlist.get(i) ;
			pid = order.get(i) ;
			if (instance < pid) instance = pid ;
			switch (act) {
				case "TAKE_END" :
					if (pinstance[pid] == -1) {
						result += pid + " ";
					} else {
						result += pinstance[pid] + " ";
						pinstance[pid] = -1 ;
					}						
					
					break ;					
				case "TAKE_NEWP" :
				case "TAKE_NEWQ" :
					if (pinstance[pid] == -1) {
						result += pid + " ";						
					} else {
						result += pinstance[pid] + " ";						
					}			
					int j = 0 ;
					while (pinstance[j] >= 0) j++ ; //always stop?
					pinstance[j] = ++instance ; //wrong
					break ;
				default:
					if (pinstance[pid] == -1) {
						result += pid + " ";
					} else {
						result += pinstance[pid] + " ";					
					}
			}
		}		
	
		return result ;
	}
	private boolean checkTrans(Transition trans1, Transition trans2) {	
		if (trans1.getId() == trans2.getId())
			return true ;
		
//		int pos = trans1.toString().indexOf(":");
//		String t1 = trans1.toString().substring(pos + 1).trim() ;
//		pos = trans2.toString().indexOf(":");
//		String t2 = trans2.toString().substring(pos + 1).trim() ;
//				
//		if (t1.equals(t2))
//			return true ;
		return false ;
	}
		
	
	protected void writeTest() { //write test
		int testcnt = 0 ;
		for (String testprogram : testcase.keySet()) {			
			PrintWriter out  ;
			try {
				String filename = Generate.getGenerateDirectory() + "/"
						+ Generate.getGenerateFileName() 
						+ "_" + (testcnt++) + "." + Generate.getGenerateFileExtension();
				out = new PrintWriter(new BufferedWriter(new FileWriter(filename)));					
//					out.append(Gen.header.replace("getTotalStep()", stack.top() + "")  + testcode) ;
					out.append(testprogram) ;
				out.flush();
				out.close();		
				System.out.println("sspinja: wrote test to " + filename);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
//	private void relocateGenCode(int top) {
//		codelisttop = top ; //~ stack.getSize()-1
//		if (codelisttop >= 0) { 
//			//generatecode = codelist.get(codelisttop) ;
//			generatecode = codeArr[codelisttop] ;
//			SchedulerObject.setPcnt(generatecode.pcnt) ;
//			generatecode.clearCode();
//		}
//	}
	protected void stateDone() {
//		System.out.println("------------ state done");
		super.stateDone(); //restore
		generatecode.clearCode();
		int top = stack.top();
		
//		System.out.println(SchedulerPromelaModel.scheduler.pcnt);
		if (top >= 0) {
			codelisttop = top ;
//			codeArr[codelisttop] = generatecode ;
			generatecode = codeArr[codelisttop];
			SchedulerObject.setPcnt(codeArr[top].pcnt) ;
		}
//		System.out.println(SchedulerPromelaModel.scheduler.pcnt);
//		relocateGenCode(stack.top()) ;
//		if (stack.getSize() > 0) {
//			codelisttop = stack.top() ;
//			generatecode.pcnt = 
//			SchedulerPanModel.scheduler.pcnt = stack.pcnt[stack.top()].clone() ;
////			SchedulerPromelaModel._pcount = stack.pcount[stack.top()-1];
//			stack.clearGenCode();
//		}		
	}
	protected void undoTransition() {	
//		System.out.println("------------undo transition");
		super.undoTransition();
		generatecode.clearCode();
		int top = stack.top();
//		System.out.println(SchedulerPromelaModel.scheduler.pcnt);
		if (top > 0) {
			SchedulerObject.setPcnt(codeArr[top -1].pcnt) ;
		} else { //top == 0
//			generatecode = initCode.clone() ;
//			int lastBeginSchedulerStatePos = startSchedulerState.generatecodes.size() ; 
//			SchedulerObject.setPcnt(startSchedulerState.generatecodes.get(lastBeginSchedulerStatePos - 1).pcnt) ;
			SchedulerObject.setPcnt(startSchedulerState.generatecodes.get(0).pcnt) ; //??
		}
//		System.out.println(SchedulerPromelaModel.scheduler.pcnt);
//		if (stack.getSize() > 0) {
//			SchedulerPanModel.scheduler.pcnt = stack.pcnt[stack.top()].clone() ;
////			SchedulerPromelaModel._pcount = stack.pcount[stack.top()-1];
//			stack.clearGenCode();
//		}		
	}

 	protected void put_schedulerState(int identifier, int depth, Transition trans) {
		SchedulerState schState = new SchedulerState() ;
		schState.results = ((SchedulerPromelaModel) model).init_atomicf() ;
		schState.checked = ((SchedulerPromelaModel) model).init_sf() ;
		
		schState.identifier = identifier ;
		//schState.father = currentSchedulerState ;
		
		if (currentSchedulerState != null) {
			currentSchedulerState.next.add(schState) ;
			currentSchedulerState.trans.add(trans) ;
		}
		schedulerstatehashmap.put(identifier, schState); //if hash table is over
		state_count ++ ;
		if (((SchedulerPromelaModel) model).stateCheck()) {
			verifyStatesList.add(schState);
		}
	}	
	private void getCyclicSchedulerStateID(ArrayList<Integer> listID) {
		for (int i = 0 ; i < listID.size(); i++)
			if (!cyclicSchedulerStateIDList.contains(listID.get(i))){
				cyclicSchedulerStateIDList.add(listID.get(i)) ;
			}
	}
	private void updateSchedulerState(int stateid, int depth, boolean isCycle, boolean isCurrentState) {
		SchedulerState schState = schedulerstatehashmap.get(stateid) ;
		schState.duplicate = isCycle ; //????
		schState.update(depth, isCycle, isCurrentState) ;
	}
	
	
	protected void outputTest(final String text, PrintWriter out) throws IOException {
		out.println(text);
		for (int i = 0; i < stack.getSize(); i++) {
			if (stack.getTransition(i) != null) {
				out.println(i + "." + stack.getTransition(i).toString());
			} else {
				break;
			}
		}		
		out.println("------------------------------------------------");
	}
	private void PrintGraph() {		
		ArrayList<SchedulerState> schStateList = new ArrayList<SchedulerState>() ;
		for (SchedulerState stSchedulerState : verifyStatesList) {
			System.out.println("+");
			stSchedulerState.print(schStateList, "",false);			
		}
	}
	private void LabelGraph() {		
//		System.out.println("Graph before label");
//		PrintGraph();
//		verifyStatesList.addAll(startSchedulerState.next) ;
		for (SchedulerState s : verifyStatesList) {
			for (int fi=formula.length-1; fi >= 0; fi --) {	
//				System.out.println(formula.opcode[fi]);
				if (formula.opcode[fi] != "atomic") {
					int n = formula.sn[fi] ;
					labelgraph(fi, s, n) ;
//					PrintGraph();
				}
			}
//			System.out.println("Graph result");
//			PrintGraph();

			if (s.results[0]) {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Satisfied") ;
				Log.out.println(formula.toString() + " : Satisfied");
				Log.analysisresult = true ;
			} else {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Unsatisfied") ;
				Log.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Unsatisfied");
				Log.analysisresult = false ;
			}
		}
//		System.out.println("Graph result");
//		PrintGraph();
	}
	private void labelgraph(int fi, SchedulerState s, int n){
//		System.out.println("--------------------------------") ;
//		System.out.println("label [" + fi + "]:" +  formula.opcode[fi] + " for " + s.identifier); s.print(); s.printchildlist();
		switch (formula.opcode[fi]) {
			case "atomic" :
				break ; //already labeled	
			case "not" :
				label_not(fi,s);
				break ;	
			case "or" :
				label_or(fi,s) ;
				break;
			case "implies" :
				label_implies(fi,s) ;
				break;
				
			case "AX" :
				label_ax(fi,s);
				break ;
			case "AF" :				
				label_af(fi,s,n);
				break ;
			case "AG" :
				label_ag(fi,s, n);
				break ;
				
			case "EX" :
				label_ex(fi,s);
				break ;
			case "EF" :
				label_ef(fi,s,n);
				break ;
			case "EG" :
				label_eg(fi,s, n);
				break ;			
			case "AU" :
				label_au(fi,s, n);
				break ;				
			case "EU" :
				label_eu(fi,s, n);
				break ;
		}
//		System.out.println("-> result labeled [" + fi + "] " + formula.opcode[fi] + " for " + s.identifier); s.print(); s.printchildlist();
	}
	
	private void label_not(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		s.results[fi] = !s.results[s1];
		s.checked[fi] = true ;
	}
	private void label_or(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		byte s2 = formula.sf[fi][1] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		if (!s.checked[s2]) labelgraph(s2,s,-1);
		s.results[fi] = s.results[s1] || s.results[s2];
		s.checked[fi] = true ;
//		for (SchedulerState child : s.next) { //check all
//			label_or(fi,child) ;					
//		}
	}
	private void label_implies(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		
		byte s1 = formula.sf[fi][0] ;
		byte s2 = formula.sf[fi][1] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		if (!s.checked[s2]) labelgraph(s2,s,-1);
		s.results[fi] = ! s.results[s1] || s.results[s2];		
		s.checked[fi] = true ;
//		for (SchedulerState child : s.next) { //check all
//			label_implies(fi,child) ;					
//		}
	}
	
	private void label_ax(int fi, SchedulerState s) {
		//for all path starting at s, next time fi -> s1 (fi == AX s1)
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		boolean result = true ;
		for (SchedulerState child : s.next) {
			if (!child.checked[s1])
				labelgraph(s1, child, -1) ;
			if (! child.results[s1]) {
				result = false ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	private void label_af(int fi, SchedulerState s, int n) {
		//for all paths starting at s, eventually fi	
//		s.print();
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula -> s1
		s.checked[fi] = true ;
					
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;		
		
		if (s.results[s1]) {	//check node		
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ;
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop ????????????????????
						if (child.results[fi]) {
						} else {							
							noderesult = false ;							
							break ;
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (!child.results[fi]) {
							noderesult = false ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}
//		s.print();
	}
	private void label_ag(int fi, SchedulerState s, int n) {
		//for all paths starting at s, always fi
		if (s.checked[fi]) return ;
		s.checked[fi] = true ;
		
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1	
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
//		System.out.println("Before:");
//		s.print() ;
		
		if (!s.results[s1]) {	//check node			
			s.results[fi] = false ;
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop																			
						if (child.results[s1]) {
						} else {		
							child.results[fi] = false ;
							noderesult = false ;
							break ;
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (!child.results[s1]) {
							noderesult = false ;
							break ;
						}
					}
					 
				}
				s.results[fi] = noderesult ;			
			}
		}
//		System.out.println("After:");
//		s.print() ;
	}

	private void label_ex(int fi, SchedulerState s) {
		//exist path starting at s, next time fi -> s1
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		boolean result = false ;
		for (SchedulerState child : s.next) {
			if (!child.checked[s1])
				labelgraph(s1, child, -1) ;
			if (child.results[s1]) {
				result = true ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	private void label_ef(int fi, SchedulerState s, int n) {
		//exist a path starting at s, eventually fi
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula -> s1
		s.checked[fi] = true ;
					
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		
		if (s.results[s1]) {	//check node		
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ; //s1 = false
			else {
				boolean noderesult = false ; //exist true -> true
				
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[fi]) {				
							noderesult = true ;
							break ;
						} else {				
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}		
	}
	private void label_eg(int fi, SchedulerState s, int n) {
		//exists a path starting at s, always fi		
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1
		s.checked[fi] = true ;
			
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		
		s.checked[fi] = true ;
		if (!s.results[s1]) {	//check node		
			s.results[fi] = false ;
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = false ; //exist true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[s1]) {
							child.results[fi] = true ; //update
							noderesult = true ;
							break ;
						} else {							
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;			
			}
		}
	}
	
	private void label_au(int fi, SchedulerState s, int n) {
		//all path starting at s, s1 until s2
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		if (!s.checked[s2])
			labelgraph(s2, s, n) ;
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = true ; //exist path false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (!child.results[s1] && !child.results[s2]) {							
							noderesult = false ;
							break ;
						} else {
							child.results[fi] = true ;
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (!child.results[fi]) {						
						noderesult = false ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}			
	}
	private void label_eu(int fi, SchedulerState s, int n) {
		//exist path starting at s, s1 until s2
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		if (!s.checked[s2])
			labelgraph(s1, s, n) ;
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = false ; //exist path true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (!child.results[s1] && !child.results[s2]) {
							//false -> ignore
							child.results[fi] = false ;
						} else {
							child.results[fi] = true ;
							noderesult = true ;
							break ;
						} 
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0								
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (child.results[fi]) {						
						noderesult = true ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}
	}


	
	
	protected void outputTrace(final String text, ArrayList<Transition> trace, PrintWriter out) throws IOException {					
		if (trace.size() == 0) {
			out.println(". No trace");
			System.out.println(". No trace");
		} else {
			out.println("------------------------------------------------");
			System.out.println("------------------------------------------------");
			out.println(text);
			System.out.println(text);
			for (int i=0; i<trace.size();i++) {
				out.println(i + ". " + trace.get(i));
				System.out.println(i + ". " + trace.get(i));
			}				
			out.println("------------------------------------------------");
			System.out.println("------------------------------------------------");
		}
	}
	protected void PrintTrace(int id, boolean expectedValue, ArrayList<Transition> trace, ArrayList<GenerateCode> gencodelist, SchedulerState s, int fi, int length, int n) {
		//PrintTrace(true,0,visitedStates, trace, schedulerstate, 0 (fi) , formula.length - 1, formula.sn[0]);
		int index;
		byte s1, s2 ;
		Transition trans ;
		
		if (s.results[fi] != expectedValue) return ;
		if (!s.checked[fi]) {
			try {
				outputTrace(formula.toString(),trace,Log.out) ;
				genTestFollowingProperty(id, trace,gencodelist);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return ;
		}
		
		switch (formula.opcode[fi]) {
			case "atomic" :
				try {
					outputTrace(formula.toString(),trace,Log.out) ;
					genTestFollowingProperty(id, trace,gencodelist);
				} catch (IOException e) {
					e.printStackTrace();
				}
				break ;
			
			case "not" :
				s1 = formula.sf[fi][0];											
				PrintTrace(id, !expectedValue, trace, gencodelist, s, s1, length, n); //do not care super script n	
				break ;
			
			case "implies" :
				s1 = formula.sf[fi][0];
				s2 = formula.sf[fi][1];
				
				if (expectedValue) { //true: F -> (T,F) & T -> T
					if (s.results[s1]) { //s1 true, must s.checked[s1]
						PrintTrace(id, true, trace,gencodelist, s, s2, length, n); //follow s2
					} else { //s1 false or true (don't care)
						PrintTrace(id, false,trace,gencodelist, s, s1, s2, n);
					}
				} else { //false: T(s1)->F(s2)
					PrintTrace(id, false, trace, gencodelist,s, s1, s2, n);
				}
				break ;
				
			case "or" :
				s1 = formula.sf[fi][0];
				s2 = formula.sf[fi][1];
				
				if (expectedValue) { //expected true					
					if (s.results[s1]) { //s1 true (checked)
						PrintTrace(id, true, trace, gencodelist,s, s1, s2, n);					
					} else { //s2 true
						PrintTrace(id, true, trace,gencodelist, s, s2, length, n); //follow s2
					}			
				} else { //expected false s1 & s2 -> false					
					if (formula.opcode[s1] == "atomic") {
						PrintTrace(id, false, trace, gencodelist,s, s2, length, -1) ;
					} else {
						if (formula.opcode[s2] == "atomic") {
							PrintTrace(id, false, trace,gencodelist, s, s1, s2, -1) ;
						} else {
							if (!visitedStates.contains(s)) {
								visitedStates.add(s) ;	//for first adding
							}
							index = 0 ;
							for  (SchedulerState child : s.next) {
								trace.add(s.trans.get(index)) ;
								gencodelist.add(s.generatecodes.get(index));
								if (child.checked[s1] && child.checked[s2]) {
									if (!visitedStates.contains(child)) {
										visitedStates.add(child);
										PrintTrace(id, expectedValue, trace,gencodelist, child, fi, length, -1) ;											
										//visitedStates.remove(visitedStates.size()-1) ;
									} else { //loop found -> print out
										try {
											outputTrace(formula.toString(),trace,Log.out) ;
											genTestFollowingProperty(id, trace,gencodelist);
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
									index ++ ;
									trace.remove(trace.size()-1) ;
									gencodelist.remove(gencodelist.size()-1);
								}
							}
						}
					}
				}
				break ;					
				
			case "AX" : //all (next node) children must be true
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;		
					gencodelist.add(s.generatecodes.get(index));
					PrintTrace(id, expectedValue,trace,gencodelist, child, s1, length, n); //do not care super script n
					trace.remove(trace.size()-1) ;	
					gencodelist.remove(gencodelist.size()-1);
					index ++ ;
				}
				break ;
			
				
				
			case "AF" : //all children future true (with supper script)				
				s1 = formula.sf[fi][0];
								
				if (s.results[s1] == expectedValue) { //ok current state has expectedValue				
					if (n == -1) { //no superscript
						PrintTrace(id, expectedValue, trace,gencodelist, s, s1, length, -1) ;					
					} else { 
						if (n > 1) {
							PrintTrace(id, expectedValue, trace,gencodelist, s, s1, length, n-1);
						} else {//n == 0
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestFollowingProperty(id, trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}							
					}
				} else { //consider next state
					if (!visitedStates.contains(s)) {
						visitedStates.add(s) ;	//for first adding
					}
					index = 0 ;
					for  (SchedulerState child : s.next) {
						trace.add(s.trans.get(index)) ;
						gencodelist.add(s.generatecodes.get(index));
						if (!visitedStates.contains(child)) {
							visitedStates.add(child);							
							if (n == -1) { //no superscript
								PrintTrace(id, expectedValue,trace,gencodelist, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(id, expectedValue,trace,gencodelist, child, fi, length, n-1);
								} else {//n == 0
									try {
										outputTrace(formula.toString(),trace,Log.out) ;
										genTestFollowingProperty(id, trace,gencodelist);
									} catch (IOException e) {
										e.printStackTrace();
									}
								}							
							}								
							//visitedStates.remove(visitedStates.size()-1) ;
						} else { //loop found -> print out
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestFollowingProperty(id, trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						index ++ ;
						trace.remove(trace.size()-1) ;
						gencodelist.remove(gencodelist.size()-1);
					}
				}
				break ;
				
			case "AG" :				
				s1 = formula.sf[fi][0];
								
				//consider every state
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;
					gencodelist.add(s.generatecodes.get(index));
					if (!visitedStates.contains(child)) {
						visitedStates.add(child);						
						if (n == -1) { //no superscript
							PrintTrace(id, expectedValue,trace, gencodelist,child, fi, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(id, expectedValue,trace,gencodelist, child, fi, length, n-1);
							} else {//n == 0
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestFollowingProperty(id, trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}							
						}							
						//visitedStates.remove(visitedStates.size()-1) ;
					} else { //already visited -> print out (detect a loop)
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestFollowingProperty(id, trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					trace.remove(trace.size()-1) ;
					gencodelist.remove(gencodelist.size()-1);
					index ++ ;
				}				
				break ;
				
			case "EX" :		
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					if (s.checked[fi] && s.results[fi]== expectedValue) {
						trace.add(s.trans.get(index)) ;			
						gencodelist.add(s.generatecodes.get(index));
						PrintTrace(id, expectedValue,trace,gencodelist, child, s1, length, n); //do not care super script n
						trace.remove(trace.size()-1) ;
						gencodelist.remove(gencodelist.size()-1);
//						break;
					}									
					index ++ ;
				}
				break ;				
				
			case "EF" :				
				s1 = formula.sf[fi][0];
				
				if (s.results[s1] == expectedValue) { //ok current state has expectedValue				
					if (n == -1) { //no superscript
						PrintTrace(id, expectedValue, trace,gencodelist, s, s1, length, -1) ;					
					} else { 
						if (n > 1) {
							PrintTrace(id, expectedValue, trace,gencodelist, s, s1, length, n-1);
						} else {//n == 0
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestFollowingProperty(id, trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}							
					}
				} else { //consider next state
					if (!visitedStates.contains(s)) {
						visitedStates.add(s) ;	//for first adding
					}
					index = 0 ;
					for  (SchedulerState child : s.next) {
						if (child.checked[fi] && child.results[fi] == expectedValue) {
							trace.add(s.trans.get(index)) ;
							gencodelist.add(s.generatecodes.get(index));
							if (!visitedStates.contains(child)) {
								visitedStates.add(child);							
								if (n == -1) { //no superscript
									PrintTrace(id, expectedValue,trace,gencodelist, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(id, expectedValue,trace, gencodelist,child, fi, length, n-1);
									} else {//n == 0
										try {
											outputTrace(formula.toString(),trace,Log.out) ;
											genTestFollowingProperty(id, trace,gencodelist);
										} catch (IOException e) {
											e.printStackTrace();
										}
									}							
								}
							} else { //loop found -> print out
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestFollowingProperty(id, trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
							trace.remove(trace.size()-1) ;
							gencodelist.remove(gencodelist.size()-1);
						}
						index ++ ;						
					}
				}
				break ;
				
				
				
			case "EG" :				
				s1 = formula.sf[fi][0];
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				index = 0 ;	
				for  (SchedulerState child : s.next) {
					if (child.checked[fi] && child.results[fi] == expectedValue) {
						trace.add(s.trans.get(index)) ;
						gencodelist.add(s.generatecodes.get(index));
						if (!visitedStates.contains(child)) {
							visitedStates.add(child);						
							if (n == -1) { //no superscript
								PrintTrace(id, expectedValue,trace,gencodelist, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(id, expectedValue,trace,gencodelist, child, fi, length, n-1);
								} else {//n == 0
									try {
										outputTrace(formula.toString(),trace,Log.out) ;
										genTestFollowingProperty(id, trace,gencodelist);
									} catch (IOException e) {
										e.printStackTrace();
									}
								}							
							}
						} else { //already visited -> print out (detect a loop)
							try {
								outputTrace(formula.toString(),trace,Log.out) ;
								genTestFollowingProperty(id, trace,gencodelist);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						trace.remove(trace.size()-1) ;
						gencodelist.remove(gencodelist.size()-1);
					}
					index ++ ;
				}				
				break ;
			
			case "AU" :				
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				
				index = 0 ;
				for  (SchedulerState child : s.next) { //check all children					
					trace.add( s.trans.get(index) ) ;			
					gencodelist.add(s.generatecodes.get(index));
					if (! visitedStates.contains(child)) { //loop
						visitedStates.add(child) ;
						if (n == -1) { //no superscript
							PrintTrace(id, expectedValue,  trace,gencodelist, child, fi, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(id, expectedValue,  trace,gencodelist, child, fi, length, n-1);
							} else {//n == 0
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestFollowingProperty(id, trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							}							
						}
					} else {						
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestFollowingProperty(id, trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}					
					trace.remove(trace.size()-1) ;
					gencodelist.remove(gencodelist.size()-1);
					index ++ ;
				}
				break ;
				
				
			case "EU" :
				if (s.results[fi] != expectedValue) return ;
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				
				if (s.results[s2]) { //s2 = true -> ok
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestFollowingProperty(id, trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
					break ;
				}
					
				if (s.next.size() == 0) { //no child
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,Log.out) ;
							genTestFollowingProperty(id, trace,gencodelist);
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
				} else {
					index = 0 ;
					for  (SchedulerState child : s.next) { //check all children
						if (child.results[fi]) {
							trans = s.trans.get(index) ;
							gencodelist.add(s.generatecodes.get(index));
							if (visitedStates.contains(child)) { //loop
								try {
									outputTrace(formula.toString(),trace,Log.out) ;
									genTestFollowingProperty(id, trace,gencodelist);
								} catch (IOException e) {
									e.printStackTrace();
								}
							} else {
								trace.add(trans) ;	
								visitedStates.add(child) ;
								if (n == -1) { //no superscript
									PrintTrace(id, expectedValue,  trace,gencodelist, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(id, expectedValue,  trace,gencodelist, child, fi, length, n-1);
									} else {//n == 0
										if (trace.size() > 0)
											try {
												outputTrace(formula.toString(),trace,Log.out) ;
												genTestFollowingProperty(id, trace,gencodelist);
											} catch (IOException e) {
												e.printStackTrace();
											}
										else
											s.print();
									}							
								}
								trace.remove(trace.size()-1) ;
								gencodelist.remove(gencodelist.size()-1);
								//visitedStates.remove(visitedStates.size()-1) ;
							}
							break ;
						}
						index ++ ;
					}
				}
				break ;
			
		}
	}
}