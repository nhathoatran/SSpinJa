// Copyright 2010, University of Twente, Formal Methods and Tools group
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package sspinja.scheduler.search;

import static spinja.search.Message.DUPLICATE_STATE;
import static spinja.search.Message.EXCEED_DEPTH_ERROR;
import static spinja.search.Message.EXCEED_DEPTH_WARNING;
import static spinja.search.Message.LIVELOCK;
import static spinja.search.Message.TRANS_ERROR;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import spinja.exceptions.SpinJaException;
import spinja.exceptions.ValidationException;
import spinja.model.Condition;
import spinja.model.Model;
import spinja.model.SchedulerTransition;
import spinja.model.Transition;
import spinja.search.TransitionCalculator;
import spinja.store.StateStore;
import spinja.util.Log;
import spinja.util.Util;
import sspinja.CTLFormula;
import sspinja.Config;
import sspinja.Generate;
import sspinja.GenerateCode;
import sspinja.SchedulerObject;
import sspinja.SchedulerPanModel;
import sspinja.SchedulerState;
import sspinja.scheduler.promela.model.SchedulerPromelaModel;

public class SchedulerMulticoreCTLGenSearch<M extends Model<T>, T extends Transition> extends SchedulerSearchAlgorithm<M, T> {	
	private static final long serialVersionUID = 1L;
	
	HashMap<Integer, SchedulerState> schedulerstatehashmap ;	
	
	private int state_count = 0 ;
	private SchedulerState startSchedulerState = null ;
	private SchedulerState currentSchedulerState = null ;
	private ArrayList<SchedulerState> verifyStatesList ;
	private CTLFormula formula;
	private ArrayList<Integer> cyclicSchedulerStateIDList;
	ArrayList<Transition> starttrace;	
	HashSet<SchedulerState> visitedStates ;
	ArrayList<Transition> trace ;
	ArrayList<Integer> corelist;
	
	private GenerateCode generatecode ;
//	private ArrayList<GenerateCode> codelist = new ArrayList<GenerateCode> () ;
	private GenerateCode [] codeArr = new GenerateCode[10000] ;
	private int codelisttop = -1 ;
	HashMap<String, ArrayList<Transition>> testcase = new HashMap<String, ArrayList<Transition>>() ;
	ArrayList<String> testprogramlist = new ArrayList<String>() ;
	
	InstanceStack instanceStack = new InstanceStack();
	
	public SchedulerMulticoreCTLGenSearch(M model, StateStore store, int stackSize, boolean errorExceedDepth,
			boolean checkForDeadlocks, int maxErrors, TransitionCalculator<M, T> nextTransition) {
		super(model, store, stackSize, errorExceedDepth, checkForDeadlocks, maxErrors, nextTransition);
		
		schedulerstatehashmap = new HashMap<Integer, SchedulerState>();
		cyclicSchedulerStateIDList = new ArrayList<Integer>() ;
		verifyStatesList = new ArrayList<SchedulerState>() ;
		formula = new CTLFormula() ;
		starttrace = new ArrayList<Transition> ();
		Log.initLog(SchedulerPanModel.scheduler.getSchedulerName());
	}

	@Override
	protected Transition nextTransition() {		
		return model.nextTransition(null) ;
	}

	@Override
	protected Transition nextTransition(Transition last) {	
		return model.nextTransition((T) last) ;
	}	
	
	@Override
	protected void takeTransition(final Transition next) throws SpinJaException {		
		stack.takeTransition(next);
	}
	
	private void add_exist_child(int identifier, Transition trans) {
		if (trans == null) return ;
		boolean isExist = false ;
		for (SchedulerState node : currentSchedulerState.next) {
			if (node.identifier == identifier) isExist = true ;
		}
		SchedulerState child = schedulerstatehashmap.get(identifier) ;
		if (! isExist) {
			currentSchedulerState.next.add(child) ;
			currentSchedulerState.trans.add(trans);
			currentSchedulerState.newID.add(SchedulerObject.getnewP()) ;
			currentSchedulerState.endID.add(SchedulerObject.getendP()) ;
		} else { //reset
			SchedulerObject.getnewP() ;
			SchedulerObject.getendP() ;
		}
	}
	
	private void put_schedulerState(int identifier, int depth, int runid, int current_core) {
		SchedulerState schState = new SchedulerState() ;
		if (SchedulerPanModel.panmodel.modelCheck()) {
			schState.results = SchedulerPanModel.panmodel.init_atomicf() ;
			schState.checked = SchedulerPanModel.panmodel.init_sf() ;
		} else {
			SchedulerPromelaModel.scheduler.initSchedulerState(schState, depth);
		}	
		schState.identifier = identifier ;		
		schState.runid = runid ;
		
		if (currentSchedulerState != null) {
			Transition lastTrans = stack.getLastTransition() ;
			if (lastTrans == swprocessTrans || lastTrans == swcoreTrans) {
				int index = 0 ;				
				for (SchedulerState state : currentSchedulerState.father){
					state.next.add(schState) ;
					state.trans.add(state.trans.get(index));	
					state.core.add(state.core.get(index));
					schState.father.add(state) ;
					schState.apptrans.add(state.trans.get(index++));
				}
			} else {
				if (firstSchedulerState == null) firstSchedulerState = schState ; //check?
				currentSchedulerState.core.add(current_core);
				currentSchedulerState.next.add(schState) ;
				currentSchedulerState.trans.add(lastTrans) ;
				currentSchedulerState.newID.add(SchedulerObject.getnewP()) ;
				currentSchedulerState.endID.add(SchedulerObject.getendP()) ;
				schState.father.add(currentSchedulerState) ;
				schState.apptrans.add(lastTrans);
			}
		} else {
			currentSchedulerState = schState ;
		}
		schedulerstatehashmap.put(identifier, schState); 
		state_count ++ ;
		if (SchedulerPanModel.panmodel.stateCheck() || SchedulerPanModel.scheduler.stateCheck()) {
			verifyStatesList.add(schState);
		}		
	}
		
	
	public void execute() {		
		ExploreSpace() ;
		if (verifyStatesList.size() == 0)
			verifyStatesList.add(firstSchedulerState) ;
//		PrintGraph() ;
//		exportTestCase3();
		//exportTestCase();
		
//		checkAcceptance() ;
			
		if (SchedulerPanModel.panmodel.modelCheck() || SchedulerPromelaModel.scheduler.schedulerCheck()) {
			if (verifyStatesList.size() == 0) {
				System.out.println("No state to be verified");
			} else {
//			PrintGraph() ;
//			if (verifyStatesList.size() == 0 &&
//				(SchedulerPanModel.panmodel.stateCheck() || SchedulerPanModel.scheduler.stateCheck()))
//				verifyStatesList.add(startSchedulerState);
				if (!Config.processLimit) {
					LabelGraph() ;
//					PrintGraph() ;
					visitedStates = new HashSet<SchedulerState>() ;
					trace = new ArrayList<Transition>() ;
					corelist = new ArrayList<Integer>() ;
					for (SchedulerState schedulerstate : verifyStatesList) {
						PrintTrace(true,corelist,trace, schedulerstate, 0, formula.length - 1, formula.sn[0]);
					}
					
					SchedulerPromelaModel.scheduler.printAnalysisResult(Log.out);
				} else {
					Log.out.println(formula.toString() + " : Not determined") ;
					Log.out.println("Search incomplete") ;
					System.out.println("Search incomplete") ;
					System.out.println(formula.toString() + " : Not determined") ;
					Log.analysisresult = true ;
				}
			}
			
			freeMemory();
		} else {
			Util.print("Not found CTL formula");
		}
//		flushOutputTest(model.getName());
//		flushOutputTest(SchedulerPanModel.scheduler.getSchedulerName());
	}	
	
	private void addGenCode() {		
		int oldcodelisttop = codelisttop ;
		codelisttop = stack.top(); ;
		
		if (codeArr[codelisttop] == null)  {	//new gen code		
			generatecode = new GenerateCode() ;			
			codeArr[codelisttop] = generatecode ;
		}		
		generatecode = codeArr[codelisttop] ;
		//System.out.println("Step = " + codelisttop + " code: " + generatecode.gencode.code);
		generatecode.clearCode(); 
				
		if (oldcodelisttop < codelisttop && oldcodelisttop >= 0) {
			generatecode.pcnt = (ArrayList<Byte>) codeArr[oldcodelisttop].getPcnt().clone() ; //copy pcnt
			SchedulerObject.setPcnt(generatecode.pcnt) ;
		} else {
			generatecode.pcnt = SchedulerObject.getPcnt() ;
		}
	}
	
	
	private void setProcessID(int pid) {
		generatecode.pid = pid ;
//		generatecode.pcnt = (ArrayList<Byte>) pcnt.clone() ;
	}
	private void updateGenCode(String addcode, String part) { //update in generatecode
		if (addcode == null) return ;
		String code = addcode.replace("getStep()", codelisttop+1+"") ;
		switch (part) {
			case "clock": 
				generatecode.gencode.setClock(code); break ;
			case "select_process": 
				generatecode.gencode.setSelect(code); break;		
			case "new_process" : 
				generatecode.gencode.setNew(code); break;
			case "preTake" : 
				generatecode.gencode.setPre(code); break;
			case "postTake" : 
				generatecode.gencode.setPost(code); break;
			case "Take" :
				generatecode.gencode.setTake(code); break;
		}	
		Gen.out.clear();
	}
	
	Transition last = null ;
	Transition next = null;
	Transition clockTrans = new SchedulerTransition(0) ;
	Transition swprocessTrans = new SchedulerTransition(1) ;
	Transition swcoreTrans = new SchedulerTransition(2) ;
	Transition selcoreTrans = new SchedulerTransition(3) ;
	
	SchedulerState firstSchedulerState ;
	byte[] state ;				
	int identifier ;
	
	int lastschopt ;
	int nextschopt ;
	
	int lastcore;
	int nextcore;
	int current_core;
	
	int livelockCount;	
	boolean startCheckLiveLock; 
	boolean isTimer;
	int runid ;
	
	private void outputValidationException(ValidationException e) {
		e.printStackTrace();
		report(TRANS_ERROR, e.getMessage());
		try {
			outputTest(e.getMessage(), Log.out);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		Log.out.println(e.toString()) ;
	}
	private boolean clock() {
		try {
			System.out.println("==> Next: Clock");
			SchedulerPromelaModel.scheduler.clock();
			stack.pushSchTrans(clockTrans);	
			updateGenCode(Gen.out.toString(), "clock");							
			Gen.out.clear();						
			if (SchedulerPromelaModel.scheduler.running_process == null) {							
				SchedulerPromelaModel.scheduler.select_process(-1);
				updateGenCode(Gen.out.toString(), "select_process");	
				Gen.out.clear();
			}
			return true ;
		} catch (ValidationException e) {
			outputValidationException(e) ;
			return false;
		}
	}	
	
	private void addState2stateSpace() { //record state & identifier
		state  = storeModel();
		if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
			identifier = store.addState(state); //to state space
		} else {
			identifier = hash.hash(state, 0);			
			atomicSteps++;
		}				
	}
	
	private boolean addState2stack_graph(int current_core) { //also build the graph		
		put_schedulerState(identifier, 0, SchedulerPromelaModel.scheduler.getRunningID(),current_core) ;
		if (!addState(state, identifier)) { //to stack (core = schopt = -1)
			return false ;						
		} else {
//			if (current_core >= 0)	stack.pushCore(current_core);
			return true ;
		}
	}
	
	private boolean addState(int current_core) {
		addState2stateSpace();		
		return addState2stack_graph(current_core);		
	}
	private boolean checkDuplicate(Transition trans) {
		state = storeModel() ;
		identifier = store.addState(state);						
		SchedulerPanModel.scheduler.setGenCode(generatecode);
		codeArr[stack.top()] = generatecode ;
			
		if (identifier < 0) { //duplicate state (visited)
			if (trans != null && trans != swcoreTrans) {
				genTestCase();								
				add_exist_child(-(identifier + 1), next);
				getCyclicSchedulerStateID(stack.getCyclicID(-(identifier + 1))) ; //if exist the identifier in stack
				if (cyclicSchedulerStateIDList.size() > 0)
					for (int id : cyclicSchedulerStateIDList)
						updateSchedulerState(id,-1,true, -(identifier + 1) == id) ;
				else 
					updateSchedulerState(-(identifier + 1),stack.top(),false, true);
				
				report(DUPLICATE_STATE.withState(state));
				nextTransition.duplicateState((M) model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
				statesMatched++;											
				if (startCheckLiveLock) { 
					if (SchedulerPromelaModel.scheduler.running_process != null) {
						report(LIVELOCK) ; //turn around
						livelockCount ++ ;												
					}
				}
			}
//			System.out.println("--> State Duplicated: " + (-identifier - 1));
			return true ;
		}		
		return false ;
	}
	
	private void addGraphNode(int current_core){		
		put_schedulerState(identifier, stack.top() + 1,SchedulerPromelaModel.scheduler.getRunningID(), current_core) ; //new scheduler state
	}
	private boolean switchProcess(int current_core) {
//		if (stack.top() < 3){
//			Util.print("------------------------------------");		
//			SchedulerPromelaModel.scheduler.print_all();
//			print_trace() ;
//		}
		
//		System.out.print("--> SWITCH PROCESS: ");		
		if (getOtherProcessfromRunningSet()) {
//			System.out.println("success");
			
//			if (stack.top() < 3){
//				Util.print("------------------------------------");		
//				SchedulerPromelaModel.scheduler.print_all();
//				print_trace() ;
//			}
			
			if (checkDuplicate(swprocessTrans)) {					
				undoTransition();	
				return false ;
			} else {
				//continue (still keep new transition & state in the stack
				//addState() ;
				stack.pushSchTrans(swprocessTrans);
//				SchedulerPromelaModel.scheduler.print_all();
//				stack.print();
				addGraphNode(current_core) ;
				addState(state, identifier); //identifier > 0 based on checkDuplicate				
				addRunningSetState();				
				//replaceState(state, identifier) ;
				//runInstance = SchedulerPromelaModel.scheduler.getRunningInstance();				
				return true ;
			}			
		}
//		System.out.println("fail");
		return false ;
	}
	private int switchCore(int fromcore) {
		System.out.print("--> SWITCH CORE: ");
		int toCore = -1;
		try {
			toCore = SchedulerPromelaModel.scheduler.switchCore(fromcore); 
			if (toCore >= 0) {
//				System.out.println("success");
				//stack.pushCore(toCore);
				stack.pushSchTrans(swcoreTrans);
				SchedulerPromelaModel.scheduler.print_all();
				stack.print();
			} else {
//				System.out.println("fail");
//				return false ;
			}
		} catch (ValidationException e) {			
			e.printStackTrace();
		}
		return toCore ;
	}
	
	private int selCore(int fromcore) {
//		System.out.print("--> SELECT CORE: ");
		int toCore = -1;
		try {
			toCore = SchedulerPromelaModel.scheduler.selCore(fromcore); 
			if (toCore >= 0) {
//				System.out.println("To core: " + toCore + " success");
				stack.pushCore(toCore);
				stack.pushSchTrans(selcoreTrans);
//				SchedulerPromelaModel.scheduler.print_all();
//				stack.print();
			} else {
//				System.out.println(" fail");				
			}
		} catch (ValidationException e) {			
			e.printStackTrace();
		}
		return toCore ;
	}
		
	private void ExploreSpace() {
		Util.print("Begin execute");
		Util.print(SchedulerPromelaModel.scheduler.getSchedulerName());
		
		Config.processInit = false ;				
		try {
			SchedulerPromelaModel.scheduler.init_order();
		} catch (final SpinJaException ex) {
			report(TRANS_ERROR, ex.getMessage());
		}	
		
		livelockCount = 0 ;		
		startCheckLiveLock = false ; 
		isTimer = false ;		
		
		if (!addState(-1)) throw new RuntimeException("Could not even add the first state."); //no core, no process selected
		addRunningSetState(); //empty		
		instanceStack.init();
		
		int step = 0;
		System.out.println("\nINITIAL STATE");
		Util.print("------------------------------------");
		System.out.println("+ STEP: " + (step++));
		SchedulerPromelaModel.scheduler.print_all();
		print_trace() ;
		
		current_core = nextcore = selCore(-1);		
		stack.pushSchTrans(selcoreTrans);
		SchedulerPromelaModel.scheduler.init() ;		
		
		if (SchedulerPromelaModel.scheduler.running_process == null) {		
			try {
				running_processID = SchedulerPromelaModel.scheduler.select_process(-1) ;
			} catch (final SpinJaException ex) {
				report(TRANS_ERROR, ex.getMessage());
			}
		}				
		//starting with first core
		if (!addState(0)) throw new RuntimeException("Could not init system state.");
		
		addRunningSetState();	
//		firstSchedulerState = currentSchedulerState ;
		
		while ((nrErrors < maxErrors) && !Thread.currentThread().isInterrupted() && restoreState() && !Config.processLimit) {
			currentSchedulerState = stack.getTopIdentifer() < 0 ? null : schedulerstatehashmap.get(stack.getTopIdentifer()) ;
//			if (identifier == 387996) {
				Util.print("------------------------------------");
				System.out.println("+ STEP: " + (step++));
				SchedulerPromelaModel.scheduler.print_all();
				print_trace() ;
//			}
			isTimer = SchedulerPromelaModel.scheduler.isTimer();
			if (outOfMemory) {				
				throw new OutOfMemoryError();
			}
	
		
			if (state.length > maxSize) {
				maxSize = state.length;
			}
					
			if (getDepth() - 1 > maxDepth) {
				maxDepth = getDepth() - 1;
			}
			
			last = stack.getLastTransition() ;			
			lastschopt = stack.getLastSchOption();
			lastcore = stack.getLastCore();
			addGenCode();
			
			
			if (last == null) {	//new state				
				nextschopt = 0;
				next = nextTransition(null) ; //last				
			} else {	
				if (last == selcoreTrans) {	
					int toCore = selCore(lastcore); 
					if (toCore != -1) {						
						if (checkDuplicate(selcoreTrans)){
							continue ;
						}
						current_core = toCore;
						addState(state,identifier); //identifier > 0 based on checkDuplicate
						addRunningSetState();
						addGraphNode(current_core) ;
						continue;
					} else break ; //finish
				}
				nextschopt = SchedulerPromelaModel.scheduler.nextSchedulerOption(lastschopt);
				if (nextschopt == -1) {	//no more scheduler option					
					if (last == clockTrans || last == swcoreTrans 
							|| last == swprocessTrans || last == selcoreTrans)						
						next = null ;
					else {
						next = nextTransition(last) ;
						if (next != null) nextschopt = 0 ;
					}
				} else {
					if (last == swcoreTrans) {
						stateDone() ;
						continue ;
					} else
						next = last ;
				}
			}	
			
			System.out.println("==> Last: " + last);
			System.out.println("==> Next: " + next);			
			
			if (next == null)
				SchedulerPromelaModel.scheduler.setAction("null") ;
			else 
				SchedulerPromelaModel.scheduler.setAction(next.toString()) ;
			
		
			
			if (next == null) {			
				if (isTimer) {
					if (last == null) {	//new state //check last = clock action, check isTimer for core!
						//clock
						next = clockTrans ;
//						stack.pushSchOpt(nextschopt);
//						stack.pushCore(nextcore);
						if (!clock()) continue ;
						if (Config.isCheckLiveLock) if (!startCheckLiveLock) startCheckLiveLock = true ;

						//check duplicate	
						if (checkDuplicate(clockTrans)) {
							if (!(nrErrors < maxErrors)) { //check all errors
								break ; //too many errors
							}
							undoTransition() ;
						}						
						continue ;
					} else { //last != null undoing							
						if (nextschopt == -1) { //duplicate with no more scheduler option
							//switch process
							next = swprocessTrans ;
							if (switchProcess(current_core)) { //get other process in poset
								continue;								
							} else {
								//switch core
								next = swcoreTrans ;
								if ((current_core = switchCore(current_core)) < 0){ //fail: no more core to switch
									stateDone() ;									
//									System.out.println("State done");
									if (stack.top()==0) {
										System.out.println("Init next core from: " + current_core);
										if ((current_core = switchCore(current_core)) < 0) 
											break ; //finish exploring
//										stack.pushSchOpt(nextschopt);
//										stack.pushCore(nextcore);
										continue ;
									} 
								} else {	
									if (checkDuplicate(swcoreTrans)) {					
										undoTransition();
										continue; //switch to another core
									} else {
//										if (lastcore >= 0) {
//											addState(state, identifier); //identifier > 0 based on checkDuplicate
//											addRunningSetState();
//										}
//										stack.pushSchTrans(swcoreTrans);
										addGraphNode(current_core) ;
//										stack.pushSchTrans(null); //for continue searching
										//??
										addState(state, identifier); //identifier > 0 based on checkDuplicate
										addRunningSetState();
									}									
								}								
							}
						}
					}
				} else { //not timer & next = null -> check deadlock?		
					//switch processs
					next = swprocessTrans ;
					if (switchProcess(current_core)) { //get other process
						continue ;
					} else { 
						//switch core	
						next = swcoreTrans ;						
						if ((current_core = switchCore(current_core))<0){
							stateDone() ;
//							System.out.println("State done");
							continue;
//							if (stack.top()==0) {
//								undoTransition();
//								SchedulerPromelaModel.scheduler.print_all();
//								stack.print();
//								lastcore = stack.getLastCore();
//								System.out.println("Init next core from: " + lastcore);
//								if (!switchCore(lastcore)) 
//									break ; //finish exploring
//								continue ;
//							} 
						} else {
							if (checkDuplicate(swcoreTrans)) {					
								undoTransition();
								continue; //switch to another core
							} else {
//								if (lastcore >= 0) {
//									addState(state, identifier); //identifier > 0 based on checkDuplicate
//									addRunningSetState();
//								}
//								stack.pushSchTrans(swcoreTrans);
								addGraphNode(current_core) ;
//								stack.pushSchTrans(null); //for continue searching
								//??
								addState(state, identifier); //identifier > 0 based on checkDuplicate
								addRunningSetState();
							}							
						}
					}						
				}	
			} else  { //next != null -> take
				runid = SchedulerPromelaModel.scheduler.getRunningID() ;				
				try {
					SchedulerPromelaModel.scheduler.preTake();
					updateGenCode(Gen.out.toString(), "preTake");
					
//					if (nextschopt == 0)
//						nextschopt = SchedulerPromelaModel.scheduler.firstSchedulerOption();
					takeTransition(next);		
					updateGenCode( Gen.out.toString(), "Take");
					stack.pushSchOpt(nextschopt);
					//stack.pushCore(lastcore);
					if (current_core < 0)
						stack.pushCore(0);
					else
						stack.pushCore(current_core);
					
					if (SchedulerPromelaModel.scheduler._runningSet != null)
						SchedulerPromelaModel.scheduler._runningSet.dataSet.clear();
					startCheckLiveLock = false ;
					SchedulerPromelaModel.scheduler.postTake();
					updateGenCode(Gen.out.toString(), "postTake");			
					setProcessID(runid) ;
				} catch (SpinJaException e) {					
					e.printStackTrace();
					report(TRANS_ERROR, e.getMessage());
					try {
						if (current_core < 0)
							stack.pushCore(0);
						else
							stack.pushCore(current_core);
						outputTest(e.getMessage(), Log.out);
					} catch (IOException ex) {
						ex.printStackTrace();
					}
					continue ;
				}
				
				if (isTimer) {
					if (clock()) continue ;					
				} else {				
					if (SchedulerPromelaModel.scheduler.running_process == null) {
						try {
							running_processID = SchedulerPromelaModel.scheduler.select_process(-1);
							updateGenCode(Gen.out.toString(), "select_process") ;							
						} catch (ValidationException e) {
							e.printStackTrace();
						}
					}
				}
				

				if (checkDuplicate(next)) {									
					undoTransition();					
					continue;									
				} else { // otherwise count it
					atomicSteps++;
//					identifier = hash.hash(state, 0); //? wrong!
				}	
				addGraphNode(current_core);
//				runid = SchedulerPromelaModel.scheduler.getRunningID();
//				if (runid < 0)
//					put_schedulerState(identifier, stack.top() + 1,-1) ; //new scheduler state
//				else
//					put_schedulerState(identifier, stack.top() + 1,runid) ; //new scheduler state
								
				if (!addState(state, identifier) ){			//identifier >0			
					if (errorExceedDepth) {
						report(EXCEED_DEPTH_ERROR);
					} else if (!printedDepthWarning) {
						report(EXCEED_DEPTH_WARNING);
						printedDepthWarning = true;
					}
					
					undoTransition();
					continue;
				}				
				addRunningSetState();
			} 
		}		
	}
	
	protected void genTestCase() {
//		System.out.println("\n gen test case");
		if (SchedulerPanModel.scheduler.isGenCode()) {	
			String testprogram = stack_exportTestCase2() ;
			if (testprogram == "" || testcase.containsKey(testprogram)) return ;
			
			for (String tp : testcase.keySet()) {				
				if (tp.contains(testprogram)) return ;
				if (testprogram.contains(tp)) { 
					testcase.remove(tp) ;
					testprogramlist.remove(tp) ;
					break ;
				}
			}			
			ArrayList<Transition> listtrans = stack.exportTrans() ;
			//remove unnecessary transitions.
			while(listtrans.remove(selcoreTrans));
			while(listtrans.remove(swcoreTrans));
			while(listtrans.remove(swprocessTrans));
			testcase.put(testprogram, listtrans) ;
			testprogramlist.add(testprogram);
		}
	}
	
	private String stack_exportTestCase2() {   
		if (codelisttop==0)	return "";
		String actionList = "" ;
		GenerateCode gcode ;
		//for (int i = 0 ; i <= codelisttop ; i++) {
		int top = stack.top() ;
		for (int i = 0 ; i <= top ; i++) {
			//gcode = codelist.get(i);
			gcode = codeArr[i];
			if (gcode == null) continue ;
			if (gcode.pid < 0) continue ;
			if (!gcode.gencode.code.isEmpty()) 
				actionList +=  gcode.gencode.code;
			else
				actionList += " ? " ;
		}		
		return actionList;
	}

	
	private int count(String text, String find) {
        int index = 0, count = 0, length = find.length();
        while( (index = text.indexOf(find, index)) != -1 ) {                
                index += length; count++;
        }
        return count;
	}
	
	protected void exportTestCase2() {		
		if (SchedulerPanModel.scheduler.isGenCode()) {
			int testcnt = 0 ;
			int totalOrder = 0 ;
			for (String testprogram : testprogramlist) { //testcase.keySet()) {
				PrintWriter out  ;
				//System.out.println(testprogram);
				String filename = SchedulerPanModel.scheduler.getSchedulerName() + "_" + testcnt++;
				try {
					out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".in")));
					int num = count(testprogram, "TAKE") ;
					String pcode = testprogram ;
					
					pcode = pcode.replace("TAKE_END", "2");
					pcode = pcode.replace("TAKE_NEW", "1");
					pcode = pcode.replace("TAKE_", "0");
					pcode += " 3" ; //FINISH
					
					//out.append(Gen.header  + num + "\n" + pcode + "\n" + testprogram + " FINISH") ;
					out.append(num + "\n" + pcode + "\n" + testprogram + " FINISH") ;
					out.flush();
					out.close();
					System.out.println("------------------");
					System.out.println("sspinja: wrote testcase to " + filename);
//					Log.out.printf("sspinja: wrote testcase to " + filename);
//					System.out.println(pcode) ;
//					System.out.println(num + " : " + testprogram);
					
					
					
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".out")));
					executionTrans = testcase.get(testprogram);
//					int i = 0 ;
//					for (Transition t : executionTrans) 
//						System.out.println((i++) + t.toString());
//					System.out.println("------------------");
										
//					if (testcnt == 9)
//						System.out.print("Stop to view");
					
					String tp = testprogram ;
					
					int index = 0 ;
					actlist.clear();
					while (index != -1) {
						index = tp.indexOf(" TAKE_") ;
						tp = tp.substring(index + 1) ;
						index = tp.indexOf(" TAKE_") ;
						if (index != -1)
							actlist.add(tp.substring(0, index)) ;
						else
							actlist.add(tp) ;												
					}
					
//					executionOrder.clear();
					realExec.clear();
					for (SchedulerState stSchedulerState : verifyStatesList) {
						order.clear(); //used as stack
						//getExecutionOrder(stSchedulerState, 0, executionTrans.size());
						getExecutionOrder(stSchedulerState,executionTrans);
					}					
					
					HashSet<String> order = new HashSet<String>() ;
					String pOrder ;
					for (ArrayList<Integer> exec : realExec) {
						pOrder = resetProcessID(exec) ;
						order.add(pOrder);						
					}
					for (String exec : order)
						out.append(exec + "\n") ;
					out.flush();
					out.close();	
					totalOrder += order.size();
					//System.out.println("sspinja: wrote test output to " + filename + ", number of execution order: " + order.size());
					Log.out.printf("sspinja: wrote test output to " + filename + ", number of execution order: " + order.size() + "\n");
				} catch (IOException e) {
					e.printStackTrace();
				}				
			}
			Log.out.printf("total running order: " + totalOrder + "\n");
		}
	}
	protected void exportTestCase3() {		
		if (SchedulerPanModel.scheduler.isGenCode()) {
			int testcnt = 0 ;
//			int totalOrder = 0 ;
			for (String testprogram : testprogramlist) { //testcase.keySet()) {
				PrintWriter out  ;
				//System.out.println(testprogram);
				String filename = SchedulerPanModel.scheduler.getSchedulerName() + "_" + testcnt++;
				try {
					out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".in")));
					int num = count(testprogram, "TAKE") ;
					String pcode = testprogram ;
					
					pcode = pcode.replace("TAKE_NEWP", "1");
					pcode = pcode.replace("TAKE_NEWQ", "2");
					pcode = pcode.replace("TAKE_END", "3");
					pcode = pcode.replace("TAKE_", "0");				
					pcode += " 4" ; //FINISH
					
					out.append(num + "\n" + pcode + "\n" + testprogram + " FINISH") ;
					out.flush();
					out.close();
					System.out.println("------------------");
					System.out.println("sspinja: wrote testcase to " + filename);
				} catch (IOException e) {
					e.printStackTrace();
				}			
			}
//			Log.out.printf("total running order: " + totalOrder + "\n");
		}
	}
	private void checkAcceptance(){
		PrintWriter out  = null;
		String filename ;
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter("results.out")));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		if (SchedulerPanModel.scheduler.isGenCode()) {
			int testcnt = 0 ;
			for (String testprogram : testprogramlist) {
				filename = SchedulerPanModel.scheduler.getSchedulerName() + "_" + (testcnt++) + ".out";
				filename = System.getProperty("user.dir") + "\\_out\\" + filename;
								
				File file = new File(filename );
				String st = null ;
		        BufferedReader br;
				try {
					br = new BufferedReader(new FileReader(file));					
			        try {
			        	st=br.readLine() ;
					} catch (IOException e) {						
						e.printStackTrace();
					}
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				ArrayList<Integer> instancelist = new ArrayList<Integer>() ;
				
				System.out.println("\n*** Checking file: " + filename);				
		        st = st.trim() + " ";
		        int index = 0;
		        while ((index = st.indexOf(' '))>0){
		        	instancelist.add(Integer.parseInt(st.substring(0, index)));
		        	st = st.substring(index+1);		        	
		        }
				
		        executionTrans = testcase.get(testprogram);		        
//		        System.out.println("Real running: " + instancelist);
		        
//		        if (testcnt==317){
//		        	System.out.println("Stop");
//		        }
				for (SchedulerState stSchedulerState : verifyStatesList) {
					instanceStack.reset();
					order.clear(); //used as stack				
					if (checkExecutionOrder(stSchedulerState,executionTrans,instancelist)) {
						System.out.println(filename + ": Satisfied");
						out.println(filename + ": Satisfied");
					} else {
						System.out.println(filename + ": Unsatisfied");
						out.println(filename + ": Unsatisfied");
					}
				}					
			}
		}
		out.flush();
		out.close();
		Log.out.printf("sspinja: wrote test output to result.out\n");
	}
	
	
	ArrayList<String> actlist = new ArrayList<String>() ;
	ArrayList<ArrayList<Integer>> realExec = new ArrayList<ArrayList<Integer>>() ;
	
	ArrayList<Transition> executionTrans  = new ArrayList<Transition>() ;
	ArrayList<Integer> order = new ArrayList<Integer>();
	
	private void addExecutionOrder(ArrayList<Integer> newExec){
		ArrayList<Integer> oldExec ;
		if (realExec.size()==0) {
			realExec.add((ArrayList<Integer>) newExec.clone()) ;			
		}	else {
			for (int i = 0; i < realExec.size() ; i++) {
				oldExec = realExec.get(i);				
				for (int j = 0 ; j < oldExec.size(); j++) {					
					if (newExec.get(j) != oldExec.get(j)) {
						realExec.add((ArrayList<Integer>) newExec.clone()) ;						
						return ;
					}
				}
			}
		}		
	}
	
	private void getExecutionOrder(SchedulerState state, ArrayList<Transition> executionTrans){
		//search the graph to explore acceptance executions
		ArrayList<SchedulerState> listState = new ArrayList<SchedulerState> () ;
		ArrayList<Integer> listID = new ArrayList<Integer>() ;
		ArrayList<Integer> listtransID = new ArrayList<Integer>() ;
		
		
		int total = executionTrans.size();
		int tstep = 0 ;
		int transid = 0 ;		
					
		Transition execnext ;
		Transition curtrans = null ;
		int transize ;
		
//		int k = 0 ;
//		for (Transition t : executionTrans) 
//			System.out.println((k++) + t.toString());
//		System.out.println("------------------");
			
		while (true) {
			if (tstep == total) {
				for(int i = 0 ; i < total;i++) {
					order.add(listID.get(i)) ;
				}				
				addExecutionOrder(order) ;
				//System.out.println("Add: " + order);
				order.clear();
				tstep--;				
				if (tstep < 0)
					break ;
				else
					state = listState.get(tstep);
			} else {
				if (listState.size() < tstep + 1) {
					listState.add(state) ;
					listID.add(state.runid) ;
				}
				execnext = executionTrans.get(tstep) ;
				if (listtransID.size() <= tstep)
					transid = 0 ;
				else
					transid = listtransID.get(tstep) + 1;
				transize = state.trans.size() ;
				
				while (transid < transize){
					curtrans = state.trans.get(transid) ;
					if (curtrans == null) break ;
					if(curtrans.getId() != execnext.getId())			
						transid++;
					else 
						break ;
				}
				
				if (transid == transize) {
					//done
					listState.remove(tstep) ;
					if (listtransID.size() > tstep )
						listtransID.remove(tstep) ;
					
					listID.remove(tstep);
					tstep-- ;
					if (tstep < 0) break ;
					else state = listState.get(tstep) ;
				} else {
					//found transition
					if (listtransID.size() < tstep + 1) {
						listtransID.add(transid) ; //addnew
					} else {
						listtransID.set(tstep, transid) ; //replace
					}
					if (transid < state.next.size() ) { 
						state = state.next.get(transid) ;
					}
					tstep++ ;
					//else tstep--;
				}	
			}
		}
	}
	
	private boolean checkExecutionOrder(SchedulerState startState, ArrayList<Transition> executionTrans, ArrayList<Integer> realExecution){
		//search the graph to check each acceptance executions
		ArrayList<SchedulerState> listState = new ArrayList<SchedulerState> () ; //use as stack		
		ArrayList<Integer> listtransID = new ArrayList<Integer>() ; //use as stack
				
		SchedulerState state = startState ;
		
		int total = realExecution.size() ; //executionTrans.size();
		int tstep = 0 ;		
		int transid = 0 ;	//count for transition	
		int realinstance ; //at each step
		//int pinstance ; //at each state
		
		Transition execnext ;
		Transition curtrans = null ;		
		int transize ;
		
		
		String s_curtrans, s_execnext;
		boolean foundInstance = false ;
		
		while (true) {
			//explore the graph & check
			if (tstep == total) {
				return true ;				
			} else {
				execnext = executionTrans.get(tstep) ; //next transition
				realinstance = realExecution.get(tstep) ; //next process instance
				
//				System.out.println("\n+ State: " + state.identifier + ", run id: " + state.runid);
//				System.out.println("+ Test case trans: " + execnext + ", Real Instance: " + realinstance);				
//				instanceStack.print();
				if (listState.size() < tstep + 1) {
					listState.add(state) ; //add to stack					
				}				
				
				if (listtransID.size() <= tstep) {
					transid = 0 ; //start at first transition
				} else {
					transid = listtransID.get(tstep) + 1;
				}
				transize = state.trans.size() ;
				
				s_execnext = execnext.toString().trim() ;
				s_execnext = s_execnext.substring(s_execnext.indexOf("):")) ;
				
				//find action
				foundInstance = false ;
				
				while (transid < transize){
//					System.out.println("- Next Transid: " + transid + " " + state.trans.get(transid) + ", Stack Instance: " + instanceStack.getInstance(state.runid));
					if (realinstance == instanceStack.getInstance(state.runid))	{ //found instance
						curtrans = state.trans.get(transid) ;
						s_curtrans = curtrans.toString().trim() ;
						s_curtrans = s_curtrans.substring(s_curtrans.indexOf("):")) ;
						
						if(s_curtrans.equals(s_execnext)) { //found suitable transition
							//update instance id														
							instanceStack.updateNewID(state.newID.get(transid));
							instanceStack.updateEndID(state.endID.get(transid));
							
							if (listtransID.size() < tstep + 1) {
								listtransID.add(transid) ; //record transition id to stack								
							} else {
								listtransID.set(tstep, transid) ; //replace transid
							}
							instanceStack.push();							
							
							if (transid < state.next.size() ) { 
								state = state.next.get(transid) ;
							}
							tstep++ ;//	continue ;	
							foundInstance = true ;
							break ;
						}
						transid++;
					} else {
						break ;
					}		
				}
									
				if (!foundInstance) {			
					//not ok -> state done
					listState.remove(tstep) ; //recover
					if (listtransID.size() > tstep )
						listtransID.remove(tstep) ;
					instanceStack.doneInstance();
//					System.out.println("Done instance");
//					instanceStack.print();
					tstep-- ;
					if (tstep < 0) break ;
					else state = listState.get(tstep) ;
				}
			}
		}
		return false ;
	}
	
	protected void getExecutionOrder( SchedulerState state, int num, int total) {
		if (num == total) {
			addExecutionOrder(order) ;
			
//			String pOrder = resetProcessID(order) ;
//			//String pOrder = order ;
//			if (!executionOrder.contains(pOrder)) {
//				executionOrder.add(pOrder) ;
//				System.out.println(pOrder);
//			}
		} else {
			Transition t = executionTrans.get(num) ;
		
			int index = 0 ;
			for (Transition tr : state.trans) {
				if (tr != null) {
					if (checkTrans(tr, t)) {	
						SchedulerState next = state.next.get(index) ;
						order.add(state.runid) ;
						getExecutionOrder(next,num+1,total) ;
						order.remove(order.size()-1) ;
						//order.remove(state.runinstance) ;
					}
				}
				index++;
			}
		}			
	}
	
	int pinstance [] = new int [128] ;
	private String resetProcessID(ArrayList<Integer> order) {		
		String result = "" ;
		
		for (int i = 0 ; i < 128 ; i ++) pinstance[i] = -1 ;
		
//		ArrayList<Integer> pidlist = new ArrayList<Integer>() ;
		//int index = order.indexOf(" ") ;
		
		//System.out.println("Actlist: " + actlist);
		
//		String tp = order ;		
//		int pid ;
//		while (index != -1) {
//			pid = Integer.parseInt(tp.substring(0, index)) ;
//			//if (pid > max) max = pid;
//			pidlist.add(pid) ;
//			tp = tp.substring(index + 1) ;
//			index = tp.indexOf(" ") ;
//		}
		
		for (int i = 0; i < SchedulerPanModel.scheduler.get_init_process_count(); i++)
			pinstance[order.get(i)] = order.get(i);
		//pinstance[order.get(1)] = order.get(1); //for 2nd process at starting time
			
		int instance = 0 ;		
		int pid ;		
		for (int i = 0 ; i < order.size(); i ++) {
			String act = actlist.get(i) ;
			pid = order.get(i) ;
			if (instance < pid) instance = pid ;
			switch (act) {
				case "TAKE_END" :
					if (pinstance[pid] == -1) {
						result += pid + " ";
					} else {
						result += pinstance[pid] + " ";
						pinstance[pid] = -1 ;
					}						
					
					break ;					
				case "TAKE_NEW" :					
					if (pinstance[pid] == -1) {
						result += pid + " ";						
					} else {
						result += pinstance[pid] + " ";						
					}			
					int j = 0 ;
					while (pinstance[j] >= 0) j++ ; //always stop?
					pinstance[j] = ++instance ;
					break ;
				default:
					if (pinstance[pid] == -1) {
						result += pid + " ";
					} else {
						result += pinstance[pid] + " ";					
					}
			}
		}		
	
		return result ;
	}
	private boolean checkTrans(Transition trans1, Transition trans2) {	
		if (trans1.getId() == trans2.getId())
			return true ;
		
//		int pos = trans1.toString().indexOf(":");
//		String t1 = trans1.toString().substring(pos + 1).trim() ;
//		pos = trans2.toString().indexOf(":");
//		String t2 = trans2.toString().substring(pos + 1).trim() ;
//				
//		if (t1.equals(t2))
//			return true ;
		return false ;
	}
	protected void exportTestCase() {		
		if (SchedulerPanModel.scheduler.isGenCode()) {
			int testcnt = 0 ;
			for (String testprogram : testcase.keySet()) {			
				PrintWriter out  ;
				try {
					String filename = SchedulerPanModel.scheduler.getSchedulerName() + "_" + testcnt++;
					out = new PrintWriter(new BufferedWriter(new FileWriter(filename + ".c")));					
//					out.append(Gen.header.replace("getTotalStep()", stack.top() + "")  + testcode) ;
					out.append(Gen.header  + testprogram) ;
					out.flush();
					out.close();		
					System.out.println("sspinja: wrote testcase to " + filename);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
//	private void relocateGenCode(int top) {
//		codelisttop = top ; //~ stack.getSize()-1
//		if (codelisttop >= 0) { 
//			//generatecode = codelist.get(codelisttop) ;
//			generatecode = codeArr[codelisttop] ;
//			SchedulerObject.setPcnt(generatecode.pcnt) ;
//			generatecode.clearCode();
//		}
//	}
	protected void stateDone() {
		super.stateDone();
//		relocateGenCode(stack.top()) ;
//		if (stack.getSize() > 0) {
//			codelisttop = stack.top() ;
//			generatecode.pcnt = 
//			SchedulerPanModel.scheduler.pcnt = stack.pcnt[stack.top()].clone() ;
////			SchedulerPromelaModel._pcount = stack.pcount[stack.top()-1];
//			stack.clearGenCode();
//		}		
	}
	protected void undoTransition() {		
		super.undoTransition();			
		generatecode.clearCode();
//		if (stack.getSize() > 0) {
//			SchedulerPanModel.scheduler.pcnt = stack.pcnt[stack.top()].clone() ;
////			SchedulerPromelaModel._pcount = stack.pcount[stack.top()-1];
//			stack.clearGenCode();
//		}		
	}

// 	protected void put_schedulerState(int identifier, int depth, Transition trans, int current_core) {
//		SchedulerState schState = new SchedulerState() ;
//		schState.results = ((SchedulerPromelaModel) model).init_atomicf() ;
//		schState.checked = ((SchedulerPromelaModel) model).init_sf() ;
//		
//		schState.identifier = identifier ;
//		//schState.father = currentSchedulerState ;
//		
//		if (currentSchedulerState != null) {
//			currentSchedulerState.next.add(schState) ;
//			currentSchedulerState.trans.add(trans) ;
//		}
//		schedulerstatehashmap.put(identifier, schState); //if hash table is over
//		state_count ++ ;
//		if (((SchedulerPromelaModel) model).stateCheck()) {
//			verifyStatesList.add(schState);
//		}
//	}	
	private void getCyclicSchedulerStateID(ArrayList<Integer> listID) {
		for (int i = 0 ; i < listID.size(); i++)
			if (!cyclicSchedulerStateIDList.contains(listID.get(i))){
				cyclicSchedulerStateIDList.add(listID.get(i)) ;
			}
	}
	private void updateSchedulerState(int stateid, int depth, boolean isCycle, boolean isCurrentState) {
		SchedulerState schState = schedulerstatehashmap.get(stateid) ;
		if (schState != null) {
			schState.duplicate = isCycle ; //????
			schState.update(depth, isCycle, isCurrentState) ;
		}
	}
	
	
	protected void outputTest(final String text, PrintWriter out) throws IOException {
		out.println(text);
		int index = 0 ;
		Transition trans ;
		for (int i = 0; i < stack.getSize(); i++) {
			trans = stack.getTransition(i);
			if (trans != null && trans != selcoreTrans && trans != swprocessTrans && trans != swcoreTrans) {
				index++;
				out.println(index + ". core = " + stack.getCore(i) + ":" + trans.toString());
			} else {
				//break;
			}
		}		
		out.println("------------------------------------------------");
	}
	private void PrintGraph() {		
		ArrayList<SchedulerState> schStateList = new ArrayList<SchedulerState>() ;
		for (SchedulerState stSchedulerState : verifyStatesList) {
			System.out.println("+");
			stSchedulerState.print(schStateList, "",false);
		}
	}
	private void LabelGraph() {		
//		System.out.println("Graph before label");
//		PrintGraph();

		for (SchedulerState s : verifyStatesList) {
			for (int fi=formula.length-1; fi >= 0; fi --) {	
//				System.out.println(formula.opcode[fi]);
				if (formula.opcode[fi] != "atomic") {
					int n = formula.sn[fi] ;
					labelgraph(fi, s, n) ;
//					PrintGraph();
				}
			}
//			System.out.println("Graph result");
//			PrintGraph();

			if (s.results[0]) {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Satisfied") ;
				Log.out.println(formula.toString() + " : Satisfied");
				Log.analysisresult = true ;
			} else {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Unsatisfied") ;
				Log.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Unsatisfied");
				Log.analysisresult = false ;
			}
		}
//		System.out.println("Graph result");
//		PrintGraph();
	}
	private void labelgraph(int fi, SchedulerState s, int n){
//		System.out.println("--------------------------------") ;
//		System.out.println("label [" + fi + "]:" +  formula.opcode[fi] + " for " + s.identifier); s.print(); s.printchildlist();
		switch (formula.opcode[fi]) {
			case "atomic" :
				break ; //already labeled	
			case "not" :
				label_not(fi,s);
				break ;	
			case "or" :
				label_or(fi,s) ;
				break;
			case "implies" :
				label_implies(fi,s) ;
				break;	
			case "AX" :
				label_ax(fi,s);
				break ;
			case "AF" :				
				label_af(fi,s,n);
				break ;
			case "AG" :
				label_ag(fi,s, n);
				break ;
				
			case "EX" :
				label_ex(fi,s);
				break ;
			case "EF" :
				label_ef(fi,s,n);
				break ;
			case "EG" :
				label_eg(fi,s, n);
				break ;			
			case "AU" :
				label_au(fi,s, n);
				break ;				
			case "EU" :
				label_eu(fi,s, n);
				break ;
		}
//		System.out.println("-> result labeled [" + fi + "] " + formula.opcode[fi] + " for " + s.identifier); s.print(); s.printchildlist();
	}
	
	private void label_not(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		s.results[fi] = !s.results[s1];
		s.checked[fi] = true ;
	}
	private void label_or(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		byte s2 = formula.sf[fi][1] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		if (!s.checked[s2]) labelgraph(s2,s,-1);
		s.results[fi] = s.results[s1] || s.results[s2];
		s.checked[fi] = true ;
//		for (SchedulerState child : s.next) { //check all
//			label_or(fi,child) ;					
//		}
	}
	private void label_implies(int fi, SchedulerState s) {
		if (s.checked[fi]) return ;
		
		byte s1 = formula.sf[fi][0] ;
		byte s2 = formula.sf[fi][1] ;
		if (!s.checked[s1]) labelgraph(s1,s,-1);
		if (!s.checked[s2]) labelgraph(s2,s,-1);
		s.results[fi] = ! s.results[s1] || s.results[s2];		
		s.checked[fi] = true ;
//		for (SchedulerState child : s.next) { //check all
//			label_implies(fi,child) ;					
//		}
	}
	
	private void label_ax(int fi, SchedulerState s) {
		//for all path starting at s, next time fi -> s1 (fi == AX s1)
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		boolean result = true ;
		for (SchedulerState child : s.next) {
			if (!child.checked[s1])
				labelgraph(s1, child, -1) ;
			if (! child.results[s1]) {
				result = false ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	private void label_af(int fi, SchedulerState s, int n) {
		//for all paths starting at s, eventually fi	
//		s.print();
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula -> s1
		s.checked[fi] = true ;
					
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;		
		
		if (s.results[s1]) {	//check node		
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ;
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop ????????????????????
						if (child.results[fi]) {
						} else {							
							noderesult = false ;							
							break ;
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (!child.results[fi]) {
							noderesult = false ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}
//		s.print();
	}
	private void label_ag(int fi, SchedulerState s, int n) {
		//for all paths starting at s, always fi
		if (s.checked[fi]) return ;
		s.checked[fi] = true ;
		
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1	
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
//		System.out.println("Before:");
//		s.print() ;
		
		if (!s.results[s1]) {	//check node			
			s.results[fi] = false ;
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop																			
						if (child.results[s1]) {
						} else {		
							child.results[fi] = false ;
							noderesult = false ;
							break ;
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (!child.results[s1]) {
							noderesult = false ;
							break ;
						}
					}
					 
				}
				s.results[fi] = noderesult ;			
			}
		}
//		System.out.println("After:");
//		s.print() ;
	}

	private void label_ex(int fi, SchedulerState s) {
		//exist path starting at s, next time fi -> s1
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;
		boolean result = false ;
		for (SchedulerState child : s.next) {
			if (!child.checked[s1])
				labelgraph(s1, child, -1) ;
			if (child.results[s1]) {
				result = true ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	private void label_ef(int fi, SchedulerState s, int n) {
		//exist a path starting at s, eventually fi
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula -> s1
		s.checked[fi] = true ;
					
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		
		if (s.results[s1]) {	//check node		
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ; //s1 = false
			else {
				boolean noderesult = false ; //exist true -> true
				
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[fi]) {				
							noderesult = true ;
							break ;
						} else {				
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}		
	}
	private void label_eg(int fi, SchedulerState s, int n) {
		//exists a path starting at s, always fi		
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1
		s.checked[fi] = true ;
			
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		
		s.checked[fi] = true ;
		if (!s.results[s1]) {	//check node		
			s.results[fi] = false ;
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = false ; //exist true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[s1]) {
							child.results[fi] = true ; //update
							noderesult = true ;
							break ;
						} else {							
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;			
			}
		}
	}
	
	private void label_au(int fi, SchedulerState s, int n) {
		//all path starting at s, s1 until s2
		if (s.checked[fi]) return ;
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		if (!s.checked[s2])
			labelgraph(s2, s, n) ;
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = true ; //exist path false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (!child.results[s1] && !child.results[s2]) {							
							noderesult = false ;
							break ;
						} else {
							child.results[fi] = true ;
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (!child.results[fi]) {						
						noderesult = false ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}			
	}
	private void label_eu(int fi, SchedulerState s, int n) {
		//exist path starting at s, s1 until s2
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		if (!s.checked[s1])
			labelgraph(s1, s, n) ;
		if (!s.checked[s2])
			labelgraph(s1, s, n) ;
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = false ; //exist path true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (!child.results[s1] && !child.results[s2]) {
							//false -> ignore
							child.results[fi] = false ;
						} else {
							child.results[fi] = true ;
							noderesult = true ;
							break ;
						} 
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0								
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (child.results[fi]) {						
						noderesult = true ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}
	}


	protected void outputTrace(final String text, ArrayList<Integer> corelist, ArrayList<Transition> trace, PrintWriter out) throws IOException {					
		if (trace.size() == 0) {
			out.println(". No trace");
//			System.out.println(". No trace");
		} else {
			out.println("------------------------------------------------");
//			System.out.println("------------------------------------------------");
			out.println(text);
//			System.out.println(text);
			for (int i=0; i<trace.size();i++) {
				out.println(i + ". core=" + corelist.get(i) + ":"+ trace.get(i));
//				System.out.println(i + ". " + trace.get(i));
			}				
			out.println("------------------------------------------------");
//			System.out.println("------------------------------------------------");
		}
	}
	protected void PrintTrace(boolean expectedValue, ArrayList<Integer> corelist, ArrayList<Transition> trace, SchedulerState s, int fi, int length, int n) {
		//PrintTrace(true,0,visitedStates, trace, schedulerstate, 0 (fi) , formula.length - 1, formula.sn[0]);
		int index;
		byte s1, s2 ;
		Transition trans ;
		
		if (s.results[fi] != expectedValue) return ;
		if (!s.checked[fi]) {
			try {
				outputTrace(formula.toString(),corelist,trace,Log.out) ;
			} catch (IOException e) {
				e.printStackTrace();
			}
			return ;
		}
		
		switch (formula.opcode[fi]) {
			case "atomic" :
				try {
					outputTrace(formula.toString(),corelist,trace,Log.out) ;
				} catch (IOException e) {
					e.printStackTrace();
				}
				break ;
			
			case "not" :
				s1 = formula.sf[fi][0];											
				PrintTrace(!expectedValue, corelist, trace, s, s1, length, n); //do not care super script n	
				break ;
			
			case "implies" :
				s1 = formula.sf[fi][0];
				s2 = formula.sf[fi][1];
				
				if (expectedValue) { //true: F -> (T,F) & T -> T
					if (s.results[s1]) { //s1 true, must s.checked[s1]
						PrintTrace(true, corelist, trace, s, s2, length, n); //follow s2
					} else { //s1 false or true (don't care)
						PrintTrace(false,corelist,trace, s, s1, s2, n);
					}
				} else { //false: T(s1)->F(s2)
					PrintTrace(false, corelist,trace, s, s1, s2, n);
				}
				break ;
				
			case "or" :
				s1 = formula.sf[fi][0];
				s2 = formula.sf[fi][1];
				
				if (expectedValue) { //expected true					
					if (s.results[s1]) { //s1 true (checked)
						PrintTrace(true, corelist,trace, s, s1, s2, n);					
					} else { //s2 true
						PrintTrace(true, corelist,trace, s, s2, length, n); //follow s2
					}			
				} else { //expected false s1 & s2 -> false					
					if (formula.opcode[s1] == "atomic") {
						PrintTrace(false, corelist,trace, s, s2, length, -1) ;
					} else {
						if (formula.opcode[s2] == "atomic") {
							PrintTrace(false, corelist,trace, s, s1, s2, -1) ;
						} else {
							if (!visitedStates.contains(s)) {
								visitedStates.add(s) ;	//for first adding
							}
							index = 0 ;
							for  (SchedulerState child : s.next) {
								trace.add(s.trans.get(index)) ;
								corelist.add(s.core.get(index));
								if (child.checked[s1] && child.checked[s2]) {
									if (!visitedStates.contains(child)) {
										visitedStates.add(child);
										PrintTrace(expectedValue,corelist, trace, child, fi, length, -1) ;											
										//visitedStates.remove(visitedStates.size()-1) ;
									} else { //loop found -> print out
										try {
											outputTrace(formula.toString(),corelist,trace,Log.out) ;
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
									index ++ ;
									trace.remove(trace.size()-1) ;
									corelist.remove(corelist.size()-1);
								}
							}
						}
					}
				}
				break ;					
				
			case "AX" : //all (next node) children must be true
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;		
					corelist.add(s.core.get(index));
					PrintTrace(expectedValue,corelist,trace, child, s1, length, n); //do not care super script n
					trace.remove(trace.size()-1) ;	
					corelist.remove(corelist.size()-1);
					index ++ ;
				}
				break ;
			
				
				
			case "AF" : //all children future true (with supper script)				
				s1 = formula.sf[fi][0];
								
				if (s.results[s1] == expectedValue) { //ok current state has expectedValue				
					if (n == -1) { //no superscript
						PrintTrace(expectedValue, corelist,trace, s, s1, length, -1) ;					
					} else { 
						if (n > 1) {
							PrintTrace(expectedValue, corelist,trace, s, s1, length, n-1);
						} else {//n == 0
							try {
								outputTrace(formula.toString(),corelist,trace,Log.out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						}							
					}
				} else { //consider next state
					if (!visitedStates.contains(s)) {
						visitedStates.add(s) ;	//for first adding
					}
					index = 0 ;
					for  (SchedulerState child : s.next) {
						trace.add(s.trans.get(index)) ;
						corelist.add(s.core.get(index));
						if (!visitedStates.contains(child)) {
							visitedStates.add(child);							
							if (n == -1) { //no superscript
								PrintTrace(expectedValue,corelist,trace, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(expectedValue,corelist,trace, child, fi, length, n-1);
								} else {//n == 0
									try {
										outputTrace(formula.toString(),corelist,trace,Log.out) ;
									} catch (IOException e) {
										e.printStackTrace();
									}
								}							
							}								
							//visitedStates.remove(visitedStates.size()-1) ;
						} else { //loop found -> print out
							try {
								outputTrace(formula.toString(),corelist,trace,Log.out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						index ++ ;
						trace.remove(trace.size()-1) ;
						corelist.remove(corelist.size()-1);
					}
				}
				break ;
				
			case "AG" :				
				s1 = formula.sf[fi][0];
								
				//consider every state
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;
					corelist.add(s.core.get(index));
					if (!visitedStates.contains(child)) {
						visitedStates.add(child);						
						if (n == -1) { //no superscript
							PrintTrace(expectedValue,corelist,trace, child, fi, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(expectedValue,corelist,trace, child, fi, length, n-1);
							} else {//n == 0
								try {
									outputTrace(formula.toString(),corelist,trace,Log.out) ;
								} catch (IOException e) {
									e.printStackTrace();
								}
							}							
						}							
						//visitedStates.remove(visitedStates.size()-1) ;
					} else { //already visited -> print out (detect a loop)
						try {
							outputTrace(formula.toString(),corelist,trace,Log.out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					trace.remove(trace.size()-1) ;
					corelist.remove(corelist.size()-1);
					index ++ ;
				}				
				break ;
				
			case "EX" :		
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					if (s.checked[fi] && s.results[fi]== expectedValue) {
						trace.add(s.trans.get(index)) ;	
						corelist.add(s.core.get(index));
						PrintTrace(expectedValue,corelist,trace, child, s1, length, n); //do not care super script n
						trace.remove(trace.size()-1) ;
						corelist.remove(corelist.size()-1);
//						break;
					}									
					index ++ ;
				}
				break ;				
				
			case "EF" :				
				s1 = formula.sf[fi][0];
				
				if (s.results[s1] == expectedValue) { //ok current state has expectedValue				
					if (n == -1) { //no superscript
						PrintTrace(expectedValue, corelist,trace, s, s1, length, -1) ;					
					} else { 
						if (n > 1) {
							PrintTrace(expectedValue, corelist,trace, s, s1, length, n-1);
						} else {//n == 0
							try {
								outputTrace(formula.toString(),corelist,trace,Log.out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						}							
					}
				} else { //consider next state
					if (!visitedStates.contains(s)) {
						visitedStates.add(s) ;	//for first adding
					}
					index = 0 ;
					for  (SchedulerState child : s.next) {
						if (child.checked[fi] && child.results[fi] == expectedValue) {
							trace.add(s.trans.get(index)) ;
							corelist.add(s.core.get(index));
							if (!visitedStates.contains(child)) {
								visitedStates.add(child);							
								if (n == -1) { //no superscript
									PrintTrace(expectedValue,corelist,trace, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(expectedValue,corelist,trace, child, fi, length, n-1);
									} else {//n == 0
										try {
											outputTrace(formula.toString(),corelist,trace,Log.out) ;
										} catch (IOException e) {
											e.printStackTrace();
										}
									}							
								}
							} else { //loop found -> print out
								try {
									outputTrace(formula.toString(),corelist,trace,Log.out) ;
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
							trace.remove(trace.size()-1) ;
							corelist.remove(corelist.size()-1);
						}
						index ++ ;						
					}
				}
				break ;
				
				
				
			case "EG" :				
				s1 = formula.sf[fi][0];
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				index = 0 ;	
				for  (SchedulerState child : s.next) {
					if (child.checked[fi] && child.results[fi] == expectedValue) {
						trace.add(s.trans.get(index)) ;
						corelist.add(s.core.get(index));
						if (!visitedStates.contains(child)) {
							visitedStates.add(child);						
							if (n == -1) { //no superscript
								PrintTrace(expectedValue,corelist,trace, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(expectedValue,corelist,trace, child, fi, length, n-1);
								} else {//n == 0
									try {
										outputTrace(formula.toString(),corelist,trace,Log.out) ;
									} catch (IOException e) {
										e.printStackTrace();
									}
								}							
							}
						} else { //already visited -> print out (detect a loop)
							try {
								outputTrace(formula.toString(),corelist,trace,Log.out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						trace.remove(trace.size()-1) ;
						corelist.add(s.core.get(index));
					}
					index ++ ;
				}				
				break ;
			
			case "AU" :				
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				if (!visitedStates.contains(s)) {
					visitedStates.add(s) ;	//for first adding
				}
				
				index = 0 ;
				for  (SchedulerState child : s.next) { //check all children					
					trace.add( s.trans.get(index) ) ;
					corelist.add(s.core.get(index));
					if (! visitedStates.contains(child)) { //loop
						visitedStates.add(child) ;
						if (n == -1) { //no superscript
							PrintTrace(expectedValue, corelist, trace, child, fi, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(expectedValue,corelist,  trace, child, fi, length, n-1);
							} else {//n == 0
								try {
									outputTrace(formula.toString(),corelist,trace,Log.out) ;
								} catch (IOException e) {
									e.printStackTrace();
								}
							}							
						}
					} else {						
						try {
							outputTrace(formula.toString(),corelist,trace,Log.out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					}					
					trace.remove(trace.size()-1) ;
					corelist.remove(corelist.size()-1);
					index ++ ;
				}
				break ;
				
				
			case "EU" :
				if (s.results[fi] != expectedValue) return ;
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				
				if (s.results[s2]) { //s2 = true -> ok
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),corelist,trace,Log.out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
					break ;
				}
					
				if (s.next.size() == 0) { //no child
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),corelist,trace,Log.out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
				} else {
					index = 0 ;
					for  (SchedulerState child : s.next) { //check all children
						if (child.results[fi]) {
							trans = s.trans.get(index) ;
							corelist.add(s.core.get(index));
							if (visitedStates.contains(child)) { //loop
								try {
									outputTrace(formula.toString(),corelist,trace,Log.out) ;
								} catch (IOException e) {
									e.printStackTrace();
								}
							} else {
								trace.add(trans) ;	
								visitedStates.add(child) ;
								if (n == -1) { //no superscript
									PrintTrace(expectedValue, corelist, trace, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(expectedValue, corelist, trace, child, fi, length, n-1);
									} else {//n == 0
										if (trace.size() > 0)
											try {
												outputTrace(formula.toString(),corelist,trace,Log.out) ;
											} catch (IOException e) {
												e.printStackTrace();
											}
										else
											s.print();
									}							
								}
								trace.remove(trace.size()-1) ;
								corelist.remove(corelist.size()-1);
								//visitedStates.remove(visitedStates.size()-1) ;
							}
							break ;
						}
						index ++ ;
					}
				}
				break ;
			
		}
	}
}