// Copyright 2010, University of Twente, Formal Methods and Tools group
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package sspinja.scheduler.search;

import java.util.ArrayList;
import java.util.Arrays;

import spinja.exceptions.SpinJaException;
import spinja.model.Transition;
import spinja.search.SearchableStack;
import spinja.store.hash.HashAlgorithm;

public class SchedulerStack implements SearchableStack  {
	private final HashAlgorithm hash;

	public int top;
	private final int size;

	public final Transition[] lastTransition;
		
	private final byte[][] encoded;
	public final int[] identifiers;	
	private final int[] hashTable;
	private long bytes;
	
	public final byte[][] runningSetEncoded ;
	public int[] runningSetIdentifiers ;
	private final int[] runningSetHashTable;
	private long runningSetBytes ;
	
	
	private final int hashMask;	
		
	
	public SchedulerStack(int size) {
		top = -1;
		this.size = size;
		lastTransition = new Transition[size];
		
		encoded = new byte[size][];
		identifiers = new int[size];
		
		runningSetEncoded = new byte[size][] ;
		runningSetIdentifiers = new int[size];

		int hashSize = 0;
		while (size > 0) {
			size >>= 1;
			hashSize++;
		}
		hashSize = 1 << hashSize; 
		
		hashTable = new int[hashSize];		
		for(int i= 0; i < hashSize; i++) {
			hashTable[i] = Integer.MIN_VALUE;
		}
		
		
		runningSetHashTable = new int[hashSize];
		for(int i= 0; i < hashSize; i++) {
			runningSetHashTable[i] = Integer.MIN_VALUE;
		}
		
		hashMask = hashSize - 1;

		//initial size
		bytes = 128 + 12 * size + 4 * hashSize;	
		runningSetBytes = 128 + 12 * size + 4 * hashSize;
		
		hash = HashAlgorithm.getDefaultAlgorithm();
	}

	public void clearStack() {
		while (top >= 0) {
			pop();
		}
	}
	
	public int getTopIdentifer() {
		if (top >=0)
			return identifiers[top] ;
		else
			return -1;
	}
	
	public boolean containsState(final byte[] state) {
		for (int i = top; i >= 0; i--) {
			if (Arrays.equals(encoded[i], state)) {
				return true;
			}
		}
		return false;		
	}

	public boolean containsState(final byte[] state, int identifier) {
		int index = identifier & hashMask;
		int incr = identifier | 1;
		int value = 0;
		while((value = hashTable[index]) >= 0) {
			if(Arrays.equals(encoded[value], state)) {
				return true;
			}
			index = (index + incr) & hashMask;
		}
		return false;
	}

	public long getBytes() {
		double memory = bytes / (1024.0 * 1024.0);
		System.out.printf("%7g process memory usage (Mbyte)\n", memory);		
		
		double memory1 = runningSetBytes / (1024.0 * 1024.0);
		System.out.printf("%7g running set memory usage (Mbyte)\n", memory1);
		
		return bytes + runningSetBytes;
	}

	public Transition getLastTransition() {
		if (top < 0) return null ;
		return lastTransition[top];
	}

	public int getSize() {
		return top + 1;
	}
	
	public boolean isFull() {
		return top == size ;
	}
	
	public void setTop(byte[] bytes,int identifier) {
		encoded[top] = bytes;
		identifiers[top] = identifier ;
		lastTransition[top] = null ;
	}
	
	public byte[] getTop() {
		return encoded[top];
	}
		
	public byte[] getRunningSetTop(){
		return runningSetEncoded[top] ;
	}

	public byte[] popRunningSet() {
		if (top == -1) {			
			throw new IndexOutOfBoundsException();
		}

		bytes -= 19 + encoded[top].length >> 3 << 3;
		byte[] res = encoded[top];
		encoded[top] = null;
						
		int index = runningSetIdentifiers[top] & hashMask;
		int incr = runningSetIdentifiers[top] | 1;
		while(hashTable[index] != top) {
			index = (index + incr) & hashMask;
		}
		hashTable[index] = Integer.MIN_VALUE;			
		if (runningSetEncoded[top] != null) {
			removeLastRunningSet();			
		}
		
		top--;		
		return res;
	}
	
	public Transition getTransition(final int depth) {
		return lastTransition[depth];
	}

	public byte[] getState(final int depth) {
		return encoded[depth];
	}

	public byte[] pop() {
		if (top == -1) {			
			throw new IndexOutOfBoundsException();
		}

		bytes -= 19 + encoded[top].length >> 3 << 3;
		byte[] res = encoded[top];
		encoded[top] = null;
		
		lastTransition[top] = null;
				
		int index = identifiers[top] & hashMask;
		int incr = identifiers[top] | 1;
		while(hashTable[index] != top) {
			index = (index + incr) & hashMask;
		}
		hashTable[index] = Integer.MIN_VALUE;			
		if (runningSetEncoded[top] != null) {
			if (runningSetIdentifiers[top] >= 0) {
				removeLastRunningSet();			
			}
		}
		
		top--;		
		return res;
	}
	
	public boolean pushRunningSet(final byte[] runningSet, int runningSetIdentifier) {
		if (top == size) {
			return false;
		}		
		
		this.runningSetEncoded[top] = runningSet;
		this.runningSetIdentifiers[top] = runningSetIdentifier;
		if (runningSetIdentifier > 0){	
			runningSetBytes += 19 + runningSet.length >> 3 << 3;
			
			int index = runningSetIdentifier & hashMask;
			int incr = runningSetIdentifier | 1;
			while(runningSetHashTable[index] >= 0) {
				index = (index + incr) & hashMask;
			}
			runningSetHashTable[index] = top;
		} 		
			
		return true;
	}
		
	public void removeLastRunningSet(){		
		runningSetBytes -= 19 + runningSetEncoded[top].length >> 3 << 3;
		runningSetEncoded[top] = null;
						
		int runningSetIndex = runningSetIdentifiers[top] & hashMask;
		int runningSetIncr = runningSetIdentifiers[top] | 1;
		while(runningSetHashTable[runningSetIndex] != top) {
			runningSetIndex = (runningSetIndex + runningSetIncr) & hashMask;
		}
		runningSetHashTable[runningSetIndex] = Integer.MIN_VALUE;
	}
		
	public ArrayList<Integer> getCyclicID(int start_duplicateID) {
		ArrayList<Integer> resultList = new ArrayList<Integer>() ;
		boolean startCopy = false ;
		for (int i = 0; i<= top; i ++) {			
			if (identifiers[i] == start_duplicateID) {
				startCopy = true ;				
			}
				
			if (startCopy)				
				resultList.add(identifiers[i]);
		}				
		return resultList ;
	}
	
	public void resetLastTransition(){
		lastTransition[top] = null ;
	}
	
	public void replaceLastState(byte[] state, int identifier) {
		pop() ;
		push(state, identifier) ;
	}
	
	public void print(){
		System.out.println("-- ------------------------ --");			
		if (top >=0) {			
			for (int i = top; i >= 0; i--) {
				System.out.printf("%s %12d %s %8d", "System state:", identifiers[i], "RunningSet state:", runningSetIdentifiers[i]);
				if (lastTransition[i] != null)
					System.out.printf("%8d%s %s",i,")",lastTransition[i].toString());		
				else
					System.out.printf("%8d%s %s",i,")"," - ?? -");
				System.out.println();
				
			}
			System.out.println("Top = " + top + ", size = " + getSize());
		}
		else
			System.out.println("Empty");
		System.out.println("-- ------------------------ --");
	}
	
	public void takeTransition(final Transition transition) throws SpinJaException {
		if (transition != null) {
			lastTransition[top] = transition;
			transition.take();
		}
	}

	public boolean push(byte[] state, int identifier) {
		if (top == size - 1) {
			return false;
		}
		top++;
		this.encoded[top] = state;
		this.identifiers[top] = identifier;
		bytes += 19 + state.length >> 3 << 3;
				
		int index = identifier & hashMask;
		int incr = identifier | 1;
		while(hashTable[index] >= 0) {
			index = (index + incr) & hashMask;
		}
		hashTable[index] = top;
		return true;
	}	
}
