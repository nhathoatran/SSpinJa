// Copyright 2010, University of Twente, Formal Methods and Tools group
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package sspinja.scheduler.search;

import static spinja.search.Message.DEADLOCK;
import static spinja.search.Message.DUPLICATE_STATE;
import static spinja.search.Message.EXCEED_DEPTH_ERROR;
import static spinja.search.Message.EXCEED_DEPTH_WARNING;
import static spinja.search.Message.NO_MORE_TRANSITIONS;
import static spinja.search.Message.TRANS_ERROR;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import spinja.exceptions.SpinJaException;
import spinja.model.Condition;
import spinja.model.Model;
import spinja.model.Transition;
import spinja.promela.model.PromelaModel;
import spinja.search.DepthFirstSearch;
import spinja.search.TransitionCalculator;
import spinja.store.StateStore;
import spinja.util.DummyStdOut;
import spinja.util.Util;
import sspinja.CTLFormula;
import sspinja.Run;
import sspinja.SchedulerState;

public class CTLSearch<M extends Model<T>, T extends Transition> extends DepthFirstSearch<M, T> {	
	private static final long serialVersionUID = 1L;

	protected PrintWriter out  ;
	protected HashMap<Integer, SchedulerState> schedulerstatehashmap = new HashMap<Integer, SchedulerState>();
	protected HashMap<Integer, ArrayList<Transition>> inittracehashmap = new HashMap<Integer, ArrayList<Transition>>();	
	protected int state_count = 0 ;
	protected SchedulerState startSchedulerState = null ;
	protected SchedulerState currentSchedulerState = null ;
	protected ArrayList<SchedulerState> verifyStatesList = new ArrayList<SchedulerState>() ;
	protected CTLFormula formula = new CTLFormula() ;
	protected ArrayList<Integer> cyclicSchedulerStateIDList = new ArrayList<Integer>() ;
	ArrayList<Transition> starttrace = new ArrayList<Transition> ();
	
	public CTLSearch(M model, StateStore store, int stackSize, boolean errorExceedDepth,
			boolean checkForDeadlocks, int maxErrors, TransitionCalculator<M, T> nextTransition) {
		super(model, store, stackSize, errorExceedDepth, checkForDeadlocks, maxErrors, nextTransition);
		// TODO Auto-generated constructor stub
		
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter(model.getName() + ".test.result")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void execute() {
		InitGraph() ;		
		if (((PromelaModel) model).modelCheck()) {
//			Util.print("Graph result");
//			PrintGraph() ;
			LabelGraph() ;			
//			Util.print("Labeled graph");
//			PrintGraph() ;
			
			ArrayList<SchedulerState> childList = new ArrayList<SchedulerState>() ;
			ArrayList<Transition> trace = new ArrayList<Transition>() ;
			for (SchedulerState schedulerstate : verifyStatesList) {
				trace.clear();
				trace.addAll(inittracehashmap.get(schedulerstate.identifier)) ;
				PrintTrace(childList, trace, schedulerstate, 0, formula.length - 1, formula.sn[0]);
			}
			freeMemory();
		} else {
			Util.print("Not found CTL formula");
		}
//		if (Run.testDepth != -1)
			flushOutputTest(model.getName());
	}
	
	
	
	protected void put_schedulerState(int identifier, int depth, Transition trans) {
		SchedulerState schState = new SchedulerState() ;
		schState.results = ((PromelaModel) model).init_atomicf() ;
		schState.checked = ((PromelaModel) model).init_sf() ;
		
		schState.identifier = identifier ;
		//schState.father = currentSchedulerState ;
		
		if (currentSchedulerState != null) {
			currentSchedulerState.next.add(schState) ;
			currentSchedulerState.trans.add(trans) ;
		}
		schedulerstatehashmap.put(identifier, schState); //if hash table is over
		state_count ++ ;
		if (((PromelaModel) model).stateCheck()) {
			verifyStatesList.add(schState);
		}
	}
	
	protected void getCyclicSchedulerStateID(ArrayList<Integer> listID) {
		for (int i = 0 ; i < listID.size(); i++)
			if (!cyclicSchedulerStateIDList.contains(listID.get(i))){
				cyclicSchedulerStateIDList.add(listID.get(i)) ;
			}
	}
	protected void updateSchedulerState(int stateid, int depth, boolean isCycle, boolean isCurrentState) {
		SchedulerState schState = schedulerstatehashmap.get(stateid) ;
		schState.update(depth, isCycle, isCurrentState) ;
	}
	
	
	
	protected void InitGraph() {
		byte[] state = storeModel();
		int counter=-1;
		int identifier;
		if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
			identifier = store.addState(state);
			if (identifier >= 0) {
			}
		} else { // otherwise count it
			identifier = hash.hash(state, 0);
			atomicSteps++;
		}
		if (!addState(state, identifier)) {
			throw new RuntimeException("Could not even add the first state.");
		}

		put_schedulerState(identifier, 0, null) ; //depth = 0, starting state
		startSchedulerState = schedulerstatehashmap.get(identifier) ;
		
		
		// While there are still more states to explore
		// or the maximum number of errors was not yet found
		while ((nrErrors < maxErrors) && !Thread.currentThread().isInterrupted() && restoreState()) {
			if (outOfMemory) { // If there is too little memory left
				throw new OutOfMemoryError(); // throw a java error
			}
			// Make sure that the state matches the model
			assert checkModelState();
		
			currentSchedulerState = stack.getTopIdentifer() < 0 ? null : schedulerstatehashmap.get(stack.getTopIdentifer()) ;
			
			if (stack.getSize() == 1) {
				starttrace = new ArrayList<Transition> () ; 
			}
			
			if (stack.getSize() == 3) { //initial node of the graph
				if (identifier > 0) {
					if (!verifyStatesList.contains(currentSchedulerState))
						verifyStatesList.add(currentSchedulerState) ;
					inittracehashmap.put(identifier, starttrace) ;
				}
			}
			
			if (state.length > maxSize) {
				maxSize = state.length;
			}

			if (getDepth() > maxDepth) {
				maxDepth = getDepth();
			}			

			final Transition next = nextTransition();
			
			if (stack.getSize() < 3 && next != null) {
				starttrace.add(next) ;
			}
				
				
			if (next == null) {
				if (checkForDeadlocks && !model.conditionHolds(Condition.END_STATE)
					&& getLastTransition() == null) {
					report(DEADLOCK);
					try {
						outputTest("Deadlock", out);
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					report(NO_MORE_TRANSITIONS);
				}
				stateDone();
				storeModel();
				continue;
			}
			try {
				counter++;
				takeTransition(next);
			} catch (final SpinJaException ex) {
				report(TRANS_ERROR, ex.getMessage());
				try {
					outputTest(ex.getMessage(), out);
				} catch (IOException e) {
					e.printStackTrace();
				}
				continue;
			}

			state = storeModel();
			if (model.conditionHolds(Condition.SHOULD_STORE_STATE)) {
				identifier = store.addState(state);
				if (identifier < 0) {
					SchedulerState schState = schedulerstatehashmap.get(-1-identifier) ;
					if (!currentSchedulerState.next.contains(schState)) {
						currentSchedulerState.next.add(schState);
						currentSchedulerState.trans.add(stack.getLastTransition()) ;
					}
					
					
					report(DUPLICATE_STATE.withState(state));
					nextTransition.duplicateState(model, getLastTransition(), state, -(identifier + 1), getSearchableStack());
					statesMatched++;
					undoTransition();
					continue;
				} else {
					put_schedulerState(identifier, stack.getSize(),next) ;					
					if ((store.getStored() & 0xfffff) == 0) {
						printInfo();
					}
				}
			} else { // otherwise count it
				atomicSteps++;
				identifier = hash.hash(state, 0);
			}

			// Push the state onto the stack/queue/...
			if (!addState(state, identifier)) {
				if (errorExceedDepth) {
					report(EXCEED_DEPTH_ERROR);
				} else if (!printedDepthWarning) {
					report(EXCEED_DEPTH_WARNING);
					printedDepthWarning = true;
				}
				undoTransition();
			}
		}
		freeMemory();
	} //end initgraph
	
	protected void flushOutputTest(String name) {
		out.flush();
		out.close();
		DummyStdOut.enableStdOut();
		System.out.println("espinja: wrote " + name + ".test.result\n");
	}
	protected void outputTest(final String text, PrintWriter out) throws IOException {
		out.println(text);
		for (int i = 0; i < stack.getSize(); i++) {
			if (stack.getTransition(i) != null) {
				out.println(i + "." + stack.getTransition(i).toString());
			} else {
				break;
			}
		}		
		out.println("------------------------------------------------");
	}
	
	protected void PrintGraph() {	
		ArrayList<SchedulerState> schStateList = new ArrayList<SchedulerState>() ;
		startSchedulerState.print(schStateList, "",false);
	}
	protected void LabelGraph() {		
		for (SchedulerState s : verifyStatesList) {
			for (int fi=formula.length-1; fi >= 0; fi --) {				
				if (formula.opcode[fi] != "atomic") {
					int n = formula.sn[fi] ;
					labelgraph(fi, s, n) ;
				}
			}
			if (s.results[0]) {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Satisfy") ;
			} else {
				System.out.println("Check state " + s.identifier + " with: " + formula.toString() + " : Unsatisfy") ;
			}
		}
	}
	protected void labelgraph(int fi, SchedulerState s, int n){		
		switch (formula.opcode[fi]) {
			case "atomic" :				
				break ; //already labeled
			case "!" :
				label_not(fi,s);
				break ;	
			case "AX" :
				label_ax(fi,s);
				break ;
			case "AF" :				
				label_af(fi,s,n);
				break ;
			case "AG" :
				label_ag(fi,s, n);
				break ;
				
			case "EX" :
				label_ex(fi,s);
				break ;
			case "EF" :
				label_ef(fi,s,n);
				break ;
			case "EG" :
				label_eg(fi,s, n);
				break ;
			
			case "AU" :
				label_au(fi,s, n);
				break ;
				
			case "EU" :
				label_eu(fi,s, n);
				break ;
		}
	}
	
	private void label_not(int fi, SchedulerState s) {
		byte s1 = formula.sf[fi][0] ;
		s.results[fi] = !s.results[s1];
		s.checked[fi] = true ;
	}
	
	protected void label_ax(int fi, SchedulerState s) {
		//for all path starting at s, next time fi -> s1
		byte s1 = formula.sf[fi][0] ;
		boolean result = true ;
		for (SchedulerState child : s.next) {
			if (! child.results[s1]) {
				result = false ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	protected void label_af(int fi, SchedulerState s, int n) {
		//for all paths starting at s, eventually fi
		byte s1 = formula.sf[fi][0] ;	//formula -> s1	
		
		s.checked[fi] = true ;
		if (s.results[s1]) {	//check node	
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ;
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[s1]) {
						} else {							
							noderesult = false ;
							break ;
						}
					} else {													
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (!child.results[fi]) {
							noderesult = false ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}
	}
	protected void label_ag(int fi, SchedulerState s, int n) {
		//for all paths starting at s, always fi
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1	
		
		s.checked[fi] = true ;
		if (!s.results[s1]) {	//check node
			s.results[fi] = false ;			
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = true ; //exist false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[s1]) {
						} else {							
							noderesult = false ;
							break ;
						}
					} else {			
						if (! child.checked[fi]) {							
							if (n == -1) { //no superscript
								labelgraph(fi,child, -1);						
							} else {
								if (n > 1) {
									labelgraph(fi, child, n-1);									
								} else {//n == 0
									child.results[fi] = child.results[s1] ; //stop the checking	
								}
							}
						}
						if (!child.results[fi]) {
							noderesult = false ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;			
			}
		}
	}

	protected void label_ex(int fi, SchedulerState s) {
		//exist path starting at s, next time fi -> s1
		byte s1 = formula.sf[fi][0] ;
		boolean result = false ;
		for (SchedulerState child : s.next) {
			if (child.results[s1]) {
				result = true ;
				break ;
			}
		}
		s.results[fi] = result ;
		s.checked[fi] = true ;
	}
	protected void label_ef(int fi, SchedulerState s, int n) {
		//exist a path starting at s, eventually fi
		byte s1 = formula.sf[fi][0] ;	//formula -> s1	
		
		s.checked[fi] = true ;
		if (s.results[s1]) {	//check node	
			s.results[fi] = true ;
		} else {
			if (s.next.size() == 0) //empty
				s.results[fi] = false ; //s1 = false
			else {
				boolean noderesult = false ; //exist true -> true
				
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[fi]) {				
							noderesult = true ;
							break ;
						} else {				
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;				
			}
		}
		
	}
	protected void label_eg(int fi, SchedulerState s, int n) {
		//exists a path starting at s, always fi
		byte s1 = formula.sf[fi][0] ;	//formula fi -> result by s1	
		
		s.checked[fi] = true ;
		if (!s.results[s1]) {	//check node	
			s.results[fi] = false ;
		} else {								
			if (s.next.size() == 0) //empty
				s.results[fi] = true ; //= s.results[s1]
			else {
				boolean noderesult = false ; //exist true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop
						if (child.results[fi]) {				
							noderesult = true ;
							break ;
						} else {							
						}
					} else {												
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else {
							if (n > 1) {
								labelgraph(fi, child, n-1);									
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking	
							}
						}	
						if (child.results[fi]) {
							noderesult = true ;
							break ;
						}
					}					
				}
				s.results[fi] = noderesult ;			
			}
		}
	}
	
	protected void label_au(int fi, SchedulerState s, int n) {
		//all path starting at s, s1 until s2
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = true ; //exist path false -> false
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (child.results[s1]) {//result -> ok
							child.results[fi] = true ;
						}else {
							noderesult = false ;
							break ;
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (!child.results[fi]) {						
						noderesult = false ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}		
		
	}
	protected void label_eu(int fi, SchedulerState s, int n) {
		//exist path starting at s, s1 until s2
		byte s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
		byte s2 = formula.sf[fi][1] ;		
		
		s.checked[fi] = true ;
		if (s.results[s2]) { //s2 = true -> ok
			s.results[fi] = true ;			
		} else { //s2 false
			if (!s.results[s1]) { //s1 false, s2 false
				s.results[fi] = false ;				
			} else { //s1 true, s2 false
				boolean noderesult = false ; //exist path true -> true
				for (SchedulerState child : s.next) { //check paths
					if (child.checked[fi]) { //loop 
						if (child.results[s1]) { //result -> ok
							child.results[fi] = true ;							
						} else {
						}
					} else {
						if (n == -1) { //no superscript
							labelgraph(fi,child, -1);						
						} else { 
							if (n > 1) {
								labelgraph(fi, child, n-1);
							} else {//n == 0
								child.results[fi] = child.results[s1] ; //stop the checking
							}							
						}
					}
					if (child.results[fi]) {						
						noderesult = true ;
						break ;
					}			
				}
				s.results[fi] = noderesult ;
			}
		}	
	}

	protected void outputTrace(final String text, ArrayList<Transition> trace, PrintWriter out) throws IOException {
		out.println(text);
		System.out.println(text);		
		for (int i=0; i<trace.size();i++) {
			out.println(i + ". " + trace.get(i));
			System.out.println(i + ". " + trace.get(i));
		}				
		out.println("------------------------------------------------");
		System.out.println("------------------------------------------------");
	}
	protected void PrintTrace(ArrayList<SchedulerState> childList, ArrayList<Transition> trace, SchedulerState s, int fi, int length, int n) {
		int index;
		byte s1, s2 ;
		Transition trans ;
		
		switch (formula.opcode[fi]) {
			case "!" :
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;
					if ((length == fi) || (formula.opcode[s1] == "atomic")) { //print out							
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}						
					} else {
						childList = new ArrayList<SchedulerState>() ;						
						PrintTrace(childList, trace, child, s1, length, n); //do not care super script n						
					}
					trace.remove(trace.size()-1) ;									
					index ++ ;
				}
				break ;
			case "AX" : //all children must be true				
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0];
				index = 0 ;
				for  (SchedulerState child : s.next) {
					trace.add(s.trans.get(index)) ;
					if ((length == fi) || (formula.opcode[s1] == "atomic")) { //print out							
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}						
					} else {
						childList = new ArrayList<SchedulerState>() ;						
						PrintTrace(childList, trace, child, s1, length, n); //do not care super script n						
					}
					trace.remove(trace.size()-1) ;									
					index ++ ;
				}
				break ;
				
			case "AF" : //all children future true
				if (!s.results[fi]) return ;
				index = 0 ;
				s1 = formula.sf[fi][0];
				if (s.results[s1]) { //ok
					if ((length == s1) || (formula.opcode[s1] == "atomic")) {
						if (trace.size() > 0) {
							try {
								outputTrace(formula.toString(),trace,out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						} else
							s.print();
					} else {
						childList = new ArrayList<SchedulerState>() ;
						childList.add(s) ;
						if (n == -1) { //no superscript
							PrintTrace(childList, trace, s, s1, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(childList, trace, s, s1, length, n-1);
							} else {//n == 0
								if (trace.size() > 0) {
									try {
										outputTrace(formula.toString(),trace,out) ;
									} catch (IOException e) {
										e.printStackTrace();
									}
								}else
									s.print();
							}							
						}
					}
				} else { //s.results[s1]) not ok					
					for  (SchedulerState child : s.next) {
						if (!childList.contains(child)) {
							childList.add(child);
							trace.add(s.trans.get(index)) ;
							if (n == -1) { //no superscript
								PrintTrace(childList, trace, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(childList, trace, child, fi, length, n-1);
								} else {//n == 0
									if (trace.size() > 0) {
										try {
											outputTrace(formula.toString(),trace,out) ;
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
									else
										s.print();
								}							
							}
							trace.remove(trace.size()-1) ;	
							childList.remove(childList.size()-1) ;
						}
						index ++ ;
					}
				}
				break ;
				
			case "AG" :
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0];
				
				index = 0 ;				
				if (s.next.size() == 0) {
					if (trace.size() > 0) {
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					else
						s.print();
				}else {
					for  (SchedulerState child : s.next) {
						trans = s.trans.get(index) ;
						if (childList.contains(child)) { //loop
							try {
								outputTrace(formula.toString(),trace,out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						} else {
							trace.add(trans) ;	
							childList.add(child) ;
							if (n == -1) { //no superscript
								PrintTrace(childList, trace, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(childList, trace, child, fi, length, n-1);
								} else {//n == 0
									if (trace.size() > 0) {
										try {
											outputTrace(formula.toString(),trace,out) ;
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
									else
										s.print();
								}							
							}
							trace.remove(trace.size()-1) ;
							childList.remove(childList.size()-1) ;
						}
						index ++ ;
					}
				}
				break ;
				
			case "EX" :
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0];
				index = 0 ;
				
				for  (SchedulerState child : s.next) {
					if (child.results[s1]) { //ok
						trace.add(s.trans.get(index)) ;
						if (s1 == length || formula.opcode[s1] == "atomic") { //print out	
							try {
								outputTrace(formula.toString(),trace,out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
							break ;
						} else {
							childList = new ArrayList<SchedulerState>() ;
							if (n == -1) { //no superscript
								PrintTrace(childList, trace, child, s1, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(childList, trace, child, s1, length, n-1);
								} else {//n == 0
									if (trace.size() > 0)
										try {
											outputTrace(formula.toString(),trace,out) ;
										} catch (IOException e) {
											e.printStackTrace();
										}
									else
										s.print();
								}							
							}
						}
						trace.remove(trace.size()-1) ;
					}					
					index ++ ;
				}
				break ;
				
			case "EF" :
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0];
				index = 0 ;
				
				if (s.results[s1]) {
					if (s1 == length || formula.opcode[s1] == "atomic") { //print out							
						if (trace.size() > 0)
							try {
								outputTrace(formula.toString(),trace,out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						else
							s.print();
						break ;
					} else {
						childList = new ArrayList<SchedulerState>() ;							
						if (n == -1) { //no superscript
							PrintTrace(childList, trace, s, s1, length, -1) ;					
						} else { 
							if (n > 1) {
								PrintTrace(childList, trace, s, s1, length, n-1);
							} else {//n == 0
								if (trace.size() > 0)
									try {
										outputTrace(formula.toString(),trace,out) ;
									} catch (IOException e) {
										e.printStackTrace();
									}
								else
									s.print();
							}							
						}						
					}
				} else {
					for  (SchedulerState child : s.next) {
						if (!childList.contains(child)) {
							if (child.results[fi]) { //ok
								trace.add(s.trans.get(index)) ;
								childList.add(child);
								if (n == -1) { //no superscript
									PrintTrace(childList, trace, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(childList, trace, child, fi, length, n-1);
									} else {//n == 0
										if (trace.size() > 0)
											try {
												outputTrace(formula.toString(),trace,out) ;
											} catch (IOException e) {
												e.printStackTrace();
											}
										else
											s.print();
									}							
								}							
								trace.remove(trace.size()-1) ;
								childList.remove(childList.size()-1); 
							}					
						}
						index ++ ;
					}
				}
				break ;
				
			case "EG" :
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0];
				index = 0 ;				
				
				if (s.next.size() == 0) {
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
				}else {
					for  (SchedulerState child : s.next) {
						if (child.results[fi]) {
							trans = s.trans.get(index) ;
							if (childList.contains(child)) { //loop
								try {
									outputTrace(formula.toString(),trace,out) ;
								} catch (IOException e) {
									e.printStackTrace();
								}
							} else {
								trace.add(trans) ;	
								childList.add(child) ;
								if (n == -1) { //no superscript
									PrintTrace(childList, trace, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(childList, trace, child, fi, length, n-1);
									} else {//n == 0
										if (trace.size() > 0)
											try {
												outputTrace(formula.toString(),trace,out) ;
											} catch (IOException e) {
												e.printStackTrace();
											}
										else
											s.print();
									}							
								}								
								trace.remove(trace.size()-1) ;
								childList.remove(childList.size()-1) ;
							}
						}
						index ++ ;
					}
				}
				break ;
			
			case "AU" :
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				
				if (s.results[s2]) { //s2 = true -> ok
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
					break ;
				}
					
				if (s.next.size() == 0) { //no child
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
				} else {
					index = 0 ;
					for  (SchedulerState child : s.next) { //check all children
						trans = s.trans.get(index) ;
						if (childList.contains(child)) { //loop
							try {
								outputTrace(formula.toString(),trace,out) ;
							} catch (IOException e) {
								e.printStackTrace();
							}
						} else {
							trace.add(trans) ;	
							childList.add(child) ;
							if (n == -1) { //no superscript
								PrintTrace(childList, trace, child, fi, length, -1) ;					
							} else { 
								if (n > 1) {
									PrintTrace(childList, trace, child, fi, length, n-1);
								} else {//n == 0
									if (trace.size() > 0)
										try {
											outputTrace(formula.toString(),trace,out) ;
										} catch (IOException e) {
											e.printStackTrace();
										}
									else
										s.print();
								}							
							}
							trace.remove(trace.size()-1) ;
							childList.remove(childList.size()-1) ;
						}
						index ++ ;
					}
				}
				break ;
				
				
			case "EU" :
				if (!s.results[fi]) return ;
				s1 = formula.sf[fi][0] ;	//formula fi -> determined by s1, s2
				s2 = formula.sf[fi][1] ;		
				
				if (s.results[s2]) { //s2 = true -> ok
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
					break ;
				}
					
				if (s.next.size() == 0) { //no child
					if (trace.size() > 0)
						try {
							outputTrace(formula.toString(),trace,out) ;
						} catch (IOException e) {
							e.printStackTrace();
						}
					else
						s.print();
				} else {
					index = 0 ;
					for  (SchedulerState child : s.next) { //check all children
						if (child.results[fi]) {
							trans = s.trans.get(index) ;
							if (childList.contains(child)) { //loop
								try {
									outputTrace(formula.toString(),trace,out) ;
								} catch (IOException e) {
									e.printStackTrace();
								}
							} else {
								trace.add(trans) ;	
								childList.add(child) ;
								if (n == -1) { //no superscript
									PrintTrace(childList, trace, child, fi, length, -1) ;					
								} else { 
									if (n > 1) {
										PrintTrace(childList, trace, child, fi, length, n-1);
									} else {//n == 0
										if (trace.size() > 0)
											try {
												outputTrace(formula.toString(),trace,out) ;
											} catch (IOException e) {
												e.printStackTrace();
											}
										else
											s.print();
									}							
								}
								trace.remove(trace.size()-1) ;
								childList.remove(childList.size()-1) ;
							}
							break ;
						}
						index ++ ;
					}
				}
				break ;
			
			case "atomic" :
				try {
					outputTrace(formula.toString(),trace,out) ;
				} catch (IOException e) {
					e.printStackTrace();
				}
				break ;
		}
		
		
	}
}