package sspinja.search.error;

import sspinja.VarState;

public class AssertState {
	int processID;
	int location ;
	
	public AssertState(int processID, int location) {
		this.processID = processID ;
		this.location = location ;
	}		

	public void setErrorState(int processID, int location, VarState estate) {
		this.location = location;
		this.processID = processID;
	}

	public int assertDistance(int processID, int location, int errorDistance) {
		if (this.processID == processID)
			return  Math.min(Math.abs(this.location - location), errorDistance);
		else
			return Math.max(this.location, location) ;
	}	
}